import express from 'express';
import type { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import crypto from 'node:crypto';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import {
  SEED_USERS,
  SEED_HOSPITALS,
  SEED_DOCTORS,
  SEED_DOCTOR_VISITS,
  SEED_VACANCIES,
  SEED_HEALTH_CAMPS,
  SEED_BLOOD_BANKS,
  SEED_BLOOD_REQUESTS,
  SEED_BLOOD_DONATIONS,
  SEED_DONOR_LEADERBOARD,
  SEED_BUS_ROUTES,
  SEED_BUS_SCHEDULES,
  SEED_TRANSPORT_ALERTS,
  SEED_GOVERNMENT_RULES,
  SEED_JOBS,
  SEED_EDUCATION,
  SEED_SOCIAL_WELFARE,
  SEED_EMERGENCY_CONTACTS,
  SEED_ANNOUNCEMENTS,
  SEED_COMPLAINTS,
  SEED_WELLBEING_METRICS,
  SEED_POLICE_STATIONS,
  SEED_AMBULANCE_UNITS,
  SEED_ACCIDENT_REPORTS,
  DEMO_TRACKING_CREDENTIALS
} from './src/data/seedData.ts';
import type { 
  Hospital, 
  Doctor, 
  DoctorVisit, 
  HospitalVacancy,
  BloodBank,
  BloodRequest,
  BloodDonationPledge,
  DonorLeaderboardEntry,
  BusRoute, 
  BusSchedule, 
  TransportAlert, 
  GovernmentRule, 
  JobListing, 
  Complaint, 
  Announcement, 
  User,
  PoliceStation,
  AmbulanceUnit,
  AccidentReport,
  AccidentType,
  AccidentSeverity
} from './src/types.ts';
import { processVerificationStatus } from './src/utils/verification.ts';
import { validateBloodDonation, validateBloodRequest } from './src/utils/bloodBank.ts';
import {
  AI_CAUSE_DISCLAIMER,
  VALID_ACCIDENT_SEVERITIES,
  VALID_ACCIDENT_TYPES,
  buildGoogleMapsUrl,
  canRoleAccessAuthorityDashboard,
  canRoleUpdateAgency,
  computeShortestRoute,
  deriveOverallAccidentStatus,
  findNearestAmbulanceUnit,
  findNearestHospitals,
  findNearestPoliceStation,
  formatSafeIncidentDescription,
  validateAccidentSubmission
} from './src/utils/accidentEmergency.ts';
import {
  type EncryptedBlob,
  RETENTION_POLICY_DAYS,
  buildAnonymousAuthorityAlertMessage,
  computeRetentionExpiryIso,
  decryptBuffer,
  encryptBuffer,
  filterActiveRetentionIncidents,
  generateOpaqueMediaId,
  generateSecureReportId,
  generateSecureTrackingToken,
  hashTrackingToken,
  isIncidentRetentionExpired,
  sanitizeEmergencyIncidentRecord,
  stripImageMetadataBuffer,
  verifyTrackingTokenHash
} from './src/utils/accidentPrivacy.ts';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// In-Memory Database Stores
let users: User[] = [...SEED_USERS];
let hospitals: Hospital[] = [...SEED_HOSPITALS];
let doctors: Doctor[] = [...SEED_DOCTORS];
let doctorVisits: DoctorVisit[] = [...SEED_DOCTOR_VISITS];
let vacancies: HospitalVacancy[] = [...SEED_VACANCIES];
let healthCamps = [...SEED_HEALTH_CAMPS];
let bloodBanks: BloodBank[] = [...SEED_BLOOD_BANKS];
let bloodRequests: BloodRequest[] = [...SEED_BLOOD_REQUESTS];
let bloodDonations: BloodDonationPledge[] = [...SEED_BLOOD_DONATIONS];
let donorLeaderboard: DonorLeaderboardEntry[] = [...SEED_DONOR_LEADERBOARD];
let busRoutes: BusRoute[] = [...SEED_BUS_ROUTES];
let busSchedules: BusSchedule[] = [...SEED_BUS_SCHEDULES];
let transportAlerts: TransportAlert[] = [...SEED_TRANSPORT_ALERTS];
let governmentRules: GovernmentRule[] = [...SEED_GOVERNMENT_RULES];
let jobs: JobListing[] = [...SEED_JOBS];
let education = [...SEED_EDUCATION];
let socialWelfare = [...SEED_SOCIAL_WELFARE];
let emergencyContacts = [...SEED_EMERGENCY_CONTACTS];
let announcements: Announcement[] = [...SEED_ANNOUNCEMENTS];
let complaints: Complaint[] = [...SEED_COMPLAINTS];
let wellbeingMetrics = [...SEED_WELLBEING_METRICS];
let policeStations: PoliceStation[] = [...SEED_POLICE_STATIONS];
let ambulanceUnits: AmbulanceUnit[] = [...SEED_AMBULANCE_UNITS];
// Store 1: Emergency Incident Database (ZERO reporter PII — shared only with authorized emergency responders or verified token holders)
let accidentReports: AccidentReport[] = [...SEED_ACCIDENT_REPORTS];

// Store 2: Restricted Reporter Privacy Vault (Isolated, Encrypted at Rest — NEVER exposed to authorities, citizens, or logs)
const VAULT_ENCRYPTION_KEY: Buffer = process.env.ACCIDENT_VAULT_SECRET
  ? crypto.scryptSync(process.env.ACCIDENT_VAULT_SECRET, 'ideal-city-360-privacy-salt', 32)
  : crypto.randomBytes(32);

interface RestrictedPrivacyVaultRecord {
  incidentCode: string;
  trackingTokenHash: string;
  encryptedOptionalCallback?: EncryptedBlob;
  createdAt: string;
  purgeAt: string;
}

interface EncryptedPhotoRecord {
  incidentCode: string;
  mimeType: string;
  encrypted: EncryptedBlob;
  createdAt: string;
  purgeAt: string;
}

const restrictedPrivacyVault = new Map<string, RestrictedPrivacyVaultRecord>();
const securePhotoVault = new Map<string, EncryptedPhotoRecord>();

function seedProtectedAccidentVaults() {
  // Seed demo tracking token hashes into isolated privacy vault
  for (const cred of DEMO_TRACKING_CREDENTIALS) {
    const matched = accidentReports.find((r) => r.incidentCode === cred.incidentCode);
    restrictedPrivacyVault.set(cred.incidentCode, {
      incidentCode: cred.incidentCode,
      trackingTokenHash: hashTrackingToken(cred.trackingToken),
      createdAt: matched?.reportedAt || new Date().toISOString(),
      purgeAt: matched?.retentionExpiresAt || '2027-12-31T23:59:59Z'
    });
  }

  // Encrypt seeded demo accident scene photos into securePhotoVault (EXIF-stripped at startup)
  const seedImages: { photoId: string; incidentCode: string; filePath: string; purgeAt: string }[] = [
    {
      photoId: 'med-seed-bike-car',
      incidentCode: 'ACC-2026-84102',
      filePath: path.resolve(process.cwd(), 'public/assets/accidents/bike-car-collision.jpg'),
      purgeAt: '2027-12-31T23:59:59Z'
    },
    {
      photoId: 'med-seed-car-van',
      incidentCode: 'ACC-2026-83945',
      filePath: path.resolve(process.cwd(), 'public/assets/accidents/car-van-collision.jpg'),
      purgeAt: '2027-12-31T23:59:59Z'
    }
  ];

  for (const item of seedImages) {
    try {
      if (fs.existsSync(item.filePath)) {
        const rawBytes = fs.readFileSync(item.filePath);
        const stripped = stripImageMetadataBuffer(rawBytes, 'image/jpeg');
        securePhotoVault.set(item.photoId, {
          incidentCode: item.incidentCode,
          mimeType: 'image/jpeg',
          encrypted: encryptBuffer(stripped.cleaned, VAULT_ENCRYPTION_KEY),
          createdAt: new Date().toISOString(),
          purgeAt: item.purgeAt
        });
      }
    } catch {
      // Non-fatal if seed file missing in minimal environments
    }
  }
}

seedProtectedAccidentVaults();

function purgeExpiredAccidents() {
  const nowMs = Date.now();
  accidentReports = filterActiveRetentionIncidents(accidentReports, nowMs);

  for (const [code, rec] of restrictedPrivacyVault.entries()) {
    if (isIncidentRetentionExpired(rec.purgeAt, nowMs)) {
      restrictedPrivacyVault.delete(code);
    }
  }
  for (const [photoId, rec] of securePhotoVault.entries()) {
    if (isIncidentRetentionExpired(rec.purgeAt, nowMs)) {
      securePhotoVault.delete(photoId);
    }
  }
}

let auditLogs: {
  id: string;
  timestamp: string;
  entityType: string;
  entityId: string;
  action: string;
  adminEmail: string;
  previousStatus?: string;
  newStatus?: string;
  notes?: string;
}[] = [
  {
    id: 'log-1',
    timestamp: '2026-11-12T05:30:00Z',
    entityType: 'Hospital',
    entityId: 'hosp-1',
    action: 'Verification Audit',
    adminEmail: 'hospital.admin@idealcity360.gov.in',
    previousStatus: 'Pending',
    newStatus: 'Verified',
    notes: 'Bed counts and emergency equipment inspected and validated'
  },
  {
    id: 'log-2',
    timestamp: '2026-11-11T14:00:00Z',
    entityType: 'JobListing',
    entityId: 'job-1',
    action: 'Public Gazetted Notification Check',
    adminEmail: 'verifier@idealcity360.gov.in',
    previousStatus: 'Pending',
    newStatus: 'Verified',
    notes: 'TSPSC gazette number cross-referenced with government press'
  }
];

// Current logged in session user (defaults to Citizen for demo)
let currentUser: User = users[0];

// AI Initialization
const aiApiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (aiApiKey) {
  aiClient = new GoogleGenAI({
    apiKey: aiApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
}

/* ========================================================
   REST API ENDPOINTS
   ======================================================== */

// --- Auth Endpoints ---
app.get('/api/auth/current', (req: Request, res: Response) => {
  res.json({ user: currentUser });
});

app.post('/api/auth/switch-user', (req: Request, res: Response) => {
  const { role, email } = req.body;
  const found = users.find(u => (email && u.email === email) || (role && u.role === role));
  if (found) {
    currentUser = found;
    return res.json({ success: true, user: currentUser });
  }
  res.status(404).json({ error: 'User role not found' });
});

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email } = req.body;
  let user = users.find(u => u.email.toLowerCase() === (email || '').toLowerCase());
  if (!user) {
    // create citizen user if not exists
    user = {
      id: `usr-${Date.now()}`,
      name: email.split('@')[0],
      email,
      role: 'citizen',
      savedItemIds: [],
      subscribedCategories: ['Health', 'Transport', 'Civic']
    };
    users.push(user);
  }
  currentUser = user;
  res.json({ success: true, user });
});

// --- Hospitals & Healthcare ---
app.get('/api/hospitals', (req: Request, res: Response) => {
  const processed = hospitals.map(processVerificationStatus);
  res.json({ hospitals: processed });
});

app.post('/api/hospitals', (req: Request, res: Response) => {
  const newHospital: Hospital = {
    ...req.body,
    id: `hosp-${Date.now()}`,
    verification: {
      sourceName: req.body.sourceName || 'Hospital Administration',
      sourceUrl: req.body.sourceUrl || 'https://idealcity.gov.in',
      createdDate: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      verificationStatus: req.body.verificationStatus || 'Verified',
      verifiedBy: currentUser.name,
      isDemoData: true,
      updateHistory: [{
        timestamp: new Date().toISOString(),
        action: 'Created hospital profile',
        user: currentUser.email
      }]
    }
  };
  hospitals.unshift(newHospital);
  res.status(201).json({ success: true, hospital: newHospital });
});

app.put('/api/hospitals/:id', (req: Request, res: Response) => {
  const idx = hospitals.findIndex(h => h.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Hospital not found' });
  
  hospitals[idx] = {
    ...hospitals[idx],
    ...req.body,
    verification: {
      ...hospitals[idx].verification,
      lastUpdated: new Date().toISOString(),
      verifiedBy: currentUser.name,
      updateHistory: [
        ...(hospitals[idx].verification.updateHistory || []),
        {
          timestamp: new Date().toISOString(),
          action: 'Updated hospital details',
          user: currentUser.email
        }
      ]
    }
  };
  res.json({ success: true, hospital: hospitals[idx] });
});

app.delete('/api/hospitals/:id', (req: Request, res: Response) => {
  hospitals = hospitals.filter(h => h.id !== req.params.id);
  res.json({ success: true });
});

// --- Doctors Directory ---
app.get('/api/doctors', (req: Request, res: Response) => {
  res.json({ doctors });
});

app.post('/api/doctors', (req: Request, res: Response) => {
  const newDoctor: Doctor = {
    ...req.body,
    id: `doc-${Date.now()}`,
    verification: {
      sourceName: 'Department of Health & Medical Council',
      sourceUrl: 'https://health.idealcity.gov.in',
      createdDate: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      verificationStatus: 'Verified',
      verifiedBy: currentUser.name,
      isDemoData: true,
      updateHistory: [{
        timestamp: new Date().toISOString(),
        action: 'Registered doctor credential',
        user: currentUser.email
      }]
    }
  };
  doctors.unshift(newDoctor);
  res.status(201).json({ success: true, doctor: newDoctor });
});

// --- Doctor Visiting Schedules ---
app.get('/api/doctor-visits', (req: Request, res: Response) => {
  const processed = doctorVisits.map(processVerificationStatus);
  res.json({ visits: processed });
});

app.post('/api/doctor-visits', (req: Request, res: Response) => {
  const newVisit: DoctorVisit = {
    ...req.body,
    id: `visit-${Date.now()}`,
    tokenCapacity: req.body.tokenCapacity || 40,
    bookedTokens: 0,
    status: 'Scheduled',
    verification: {
      sourceName: req.body.sourceName || 'Hospital OPD Roster Management',
      sourceUrl: req.body.sourceUrl || 'https://idealcity.gov.in/opd',
      createdDate: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      verificationStatus: 'Verified',
      validFrom: new Date().toISOString().split('T')[0],
      validUntil: req.body.visitDate,
      verifiedBy: currentUser.name,
      isDemoData: true,
      updateHistory: [{
        timestamp: new Date().toISOString(),
        action: 'Scheduled specialist doctor consultation visit',
        user: currentUser.email
      }]
    }
  };
  doctorVisits.unshift(newVisit);
  res.status(201).json({ success: true, visit: newVisit });
});

app.post('/api/doctor-visits/:id/book-token', (req: Request, res: Response) => {
  const visit = doctorVisits.find(v => v.id === req.params.id);
  if (!visit) return res.status(404).json({ error: 'Visit slot not found' });
  if (visit.bookedTokens >= visit.tokenCapacity) {
    return res.status(400).json({ error: 'Token slots are full for this visiting day' });
  }
  visit.bookedTokens += 1;
  res.json({ 
    success: true, 
    tokenNumber: visit.bookedTokens, 
    message: `Token #${visit.bookedTokens} confirmed for ${visit.doctorName} at ${visit.hospitalName}`,
    visit 
  });
});

// --- Hospital Vacancies ---
app.get('/api/vacancies', (req: Request, res: Response) => {
  const processed = vacancies.map(processVerificationStatus);
  res.json({ vacancies: processed });
});

app.post('/api/vacancies', (req: Request, res: Response) => {
  const newVac: HospitalVacancy = {
    ...req.body,
    id: `vac-${Date.now()}`,
    verification: {
      sourceName: req.body.sourceName || 'Hospital HR Recruitment Cell',
      sourceUrl: req.body.sourceUrl || 'https://idealcity.gov.in/careers',
      createdDate: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      verificationStatus: 'Verified',
      validFrom: new Date().toISOString().split('T')[0],
      validUntil: req.body.deadline,
      verifiedBy: currentUser.name,
      isDemoData: true,
      updateHistory: [{
        timestamp: new Date().toISOString(),
        action: 'Published hospital recruitment notification',
        user: currentUser.email
      }]
    }
  };
  vacancies.unshift(newVac);
  res.status(201).json({ success: true, vacancy: newVac });
});

// --- Health Camps ---
app.get('/api/health-camps', (req: Request, res: Response) => {
  res.json({ camps: healthCamps });
});

// --- Blood Banks, Requests & Donations ---
app.get('/api/blood-banks', (req: Request, res: Response) => {
  const processed = bloodBanks.map(processVerificationStatus);
  res.json({
    bloodBanks: processed,
    requests: bloodRequests,
    donations: bloodDonations,
    leaderboard: donorLeaderboard
  });
});

app.get('/api/blood-banks/leaderboard', (req: Request, res: Response) => {
  res.json({ leaderboard: donorLeaderboard });
});

app.post('/api/blood-banks/donations/:id/complete', (req: Request, res: Response) => {
  const pledge = bloodDonations.find(d => d.id === req.params.id);
  if (!pledge) {
    return res.status(404).json({ error: 'Donation pledge not found' });
  }
  pledge.status = 'Completed';
  res.json({ success: true, donation: pledge });
});

app.post('/api/blood-banks/requests', (req: Request, res: Response) => {
  const validation = validateBloodRequest({
    ...req.body,
    unitsNeeded: Number(req.body.unitsNeeded)
  });
  if (!validation.valid) {
    return res.status(400).json({ error: 'Validation failed', errors: validation.errors });
  }

  const linkedBank = req.body.bloodBankId
    ? bloodBanks.find(b => b.id === req.body.bloodBankId)
    : undefined;

  const newRequest: BloodRequest = {
    id: `breq-${Date.now()}`,
    requestCode: `BLD-REQ-${Math.floor(10000 + Math.random() * 90000)}`,
    patientName: req.body.patientName.trim(),
    bloodGroup: req.body.bloodGroup,
    unitsNeeded: Number(req.body.unitsNeeded),
    urgency: req.body.urgency || 'Urgent',
    hospitalName: req.body.hospitalName.trim(),
    bloodBankId: req.body.bloodBankId,
    zone: req.body.zone || linkedBank?.zone,
    lat: typeof req.body.lat === 'number' ? req.body.lat : linkedBank?.lat,
    lng: typeof req.body.lng === 'number' ? req.body.lng : linkedBank?.lng,
    contactName: req.body.contactName.trim(),
    contactPhone: req.body.contactPhone.trim(),
    notes: req.body.notes?.trim() || undefined,
    status: 'Pending',
    createdAt: new Date().toISOString()
  };
  bloodRequests.unshift(newRequest);
  res.status(201).json({ success: true, request: newRequest });
});

app.post('/api/blood-banks/donations', (req: Request, res: Response) => {
  const validation = validateBloodDonation({
    ...req.body,
    age: Number(req.body.age),
    weightKg: Number(req.body.weightKg)
  });
  if (!validation.valid) {
    return res.status(400).json({ error: 'Eligibility or input validation failed', errors: validation.errors });
  }

  const bank = bloodBanks.find(b => b.id === req.body.preferredBankId);
  const newDonation: BloodDonationPledge = {
    id: `bdon-${Date.now()}`,
    pledgeCode: `BLD-DON-${Math.floor(10000 + Math.random() * 90000)}`,
    donorName: req.body.donorName.trim(),
    bloodGroup: req.body.bloodGroup,
    age: Number(req.body.age),
    weightKg: Number(req.body.weightKg),
    phone: req.body.phone.trim(),
    email: req.body.email?.trim() || currentUser.email,
    preferredBankId: req.body.preferredBankId,
    preferredBankName: bank?.name || req.body.preferredBankName || 'City Verified Blood Bank',
    preferredDate: req.body.preferredDate,
    preferredSlot: req.body.preferredSlot || '10:00 AM - 12:00 PM',
    status: 'Scheduled',
    createdAt: new Date().toISOString()
  };
  bloodDonations.unshift(newDonation);
  res.status(201).json({ success: true, donation: newDonation });
});

// --- Transport & Smart Buses ---
app.get('/api/transport/routes', (req: Request, res: Response) => {
  res.json({ routes: busRoutes });
});

app.post('/api/transport/routes', (req: Request, res: Response) => {
  const newRoute: BusRoute = {
    ...req.body,
    id: `route-${Date.now()}`,
    verification: {
      sourceName: 'Metropolitan Smart Transport Division',
      sourceUrl: 'https://tsrtc.idealcity.gov.in',
      createdDate: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      verificationStatus: 'Verified',
      verifiedBy: currentUser.name,
      isDemoData: true,
      updateHistory: []
    }
  };
  busRoutes.unshift(newRoute);
  res.status(201).json({ success: true, route: newRoute });
});

app.get('/api/transport/schedules', (req: Request, res: Response) => {
  res.json({ schedules: busSchedules });
});

app.get('/api/transport/alerts', (req: Request, res: Response) => {
  res.json({ alerts: transportAlerts });
});

app.post('/api/transport/alerts', (req: Request, res: Response) => {
  const newAlert: TransportAlert = {
    ...req.body,
    id: `talert-${Date.now()}`,
    verification: {
      sourceName: 'Traffic Operations Command Center',
      sourceUrl: 'https://traffic.idealcity.gov.in',
      createdDate: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      verificationStatus: 'Verified',
      verifiedBy: currentUser.name,
      isDemoData: true,
      updateHistory: []
    }
  };
  transportAlerts.unshift(newAlert);
  res.status(201).json({ success: true, alert: newAlert });
});

// --- Government Rules & Services ---
app.get('/api/government/rules', (req: Request, res: Response) => {
  res.json({ rules: governmentRules });
});

app.post('/api/government/rules', (req: Request, res: Response) => {
  const newRule: GovernmentRule = {
    ...req.body,
    id: `gov-rule-${Date.now()}`,
    verification: {
      sourceName: req.body.sourceName || 'Secretariat Gazette Bureau',
      sourceUrl: req.body.officialSourceUrl || 'https://idealcity.gov.in/rules',
      createdDate: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      verificationStatus: 'Verified',
      verifiedBy: currentUser.name,
      isDemoData: true,
      updateHistory: []
    }
  };
  governmentRules.unshift(newRule);
  res.status(201).json({ success: true, rule: newRule });
});

// --- Employment & Opportunities ---
app.get('/api/jobs', (req: Request, res: Response) => {
  res.json({ jobs });
});

app.post('/api/jobs', (req: Request, res: Response) => {
  const newJob: JobListing = {
    ...req.body,
    id: `job-${Date.now()}`,
    verification: {
      sourceName: req.body.sourceName || 'Employment Exchange & Public Service Portal',
      sourceUrl: req.body.applicationLink || 'https://idealcity.gov.in/jobs',
      createdDate: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      verificationStatus: 'Verified',
      validUntil: req.body.deadline,
      verifiedBy: currentUser.name,
      isDemoData: true,
      updateHistory: []
    }
  };
  jobs.unshift(newJob);
  res.status(201).json({ success: true, job: newJob });
});

// --- Education & Social Welfare ---
app.get('/api/education', (req: Request, res: Response) => {
  res.json({ education });
});

app.get('/api/social-welfare', (req: Request, res: Response) => {
  res.json({ socialWelfare });
});

app.get('/api/emergency', (req: Request, res: Response) => {
  res.json({ emergencyContacts });
});

// --- Announcements ---
app.get('/api/announcements', (req: Request, res: Response) => {
  res.json({ announcements });
});

app.post('/api/announcements', (req: Request, res: Response) => {
  const newAnn: Announcement = {
    ...req.body,
    id: `ann-${Date.now()}`,
    publishedAt: new Date().toISOString(),
    verification: {
      sourceName: req.body.officialSource || 'Municipal Information & PR Wing',
      sourceUrl: 'https://idealcity.gov.in/press',
      createdDate: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
      verificationStatus: 'Verified',
      verifiedBy: currentUser.name,
      isDemoData: true,
      updateHistory: []
    }
  };
  announcements.unshift(newAnn);
  res.status(201).json({ success: true, announcement: newAnn });
});

// --- City Well-Being Dashboard Metrics ---
app.get('/api/wellbeing', (req: Request, res: Response) => {
  res.json({ metrics: wellbeingMetrics });
});

// --- Citizen Complaints & Grievances ---
app.get('/api/complaints', (req: Request, res: Response) => {
  // If citizen, return their complaints or all if admin
  if (currentUser.role === 'citizen') {
    const userComplaints = complaints.filter(c => c.citizenId === currentUser.id || c.citizenEmail === currentUser.email);
    return res.json({ complaints: userComplaints });
  }
  res.json({ complaints });
});

app.post('/api/complaints', (req: Request, res: Response) => {
  const { title, category, description, location, imageUrl, priority } = req.body;
  const ticketNumber = `IDC-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
  const newComplaint: Complaint = {
    id: `cmp-${Date.now()}`,
    ticketNumber,
    citizenId: currentUser.id,
    citizenName: currentUser.name,
    citizenEmail: currentUser.email,
    title,
    category,
    description,
    location,
    imageUrl: imageUrl || '',
    status: 'Submitted',
    priority: priority || 'Medium',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    adminNotes: 'Grievance ticket registered in municipal queue. Inspection officer will be assigned shortly.'
  };
  complaints.unshift(newComplaint);
  res.status(201).json({ success: true, complaint: newComplaint });
});

app.patch('/api/complaints/:id/status', (req: Request, res: Response) => {
  const { status, adminNotes } = req.body;
  const cmp = complaints.find(c => c.id === req.params.id);
  if (!cmp) return res.status(404).json({ error: 'Complaint not found' });
  
  cmp.status = status;
  cmp.updatedAt = new Date().toISOString();
  if (adminNotes) {
    cmp.adminNotes = adminNotes;
  }
  if (status === 'Resolved') {
    cmp.resolvedAt = new Date().toISOString();
  }
  res.json({ success: true, complaint: cmp });
});

// --- Verification & Audit Logs Workflow ---
app.get('/api/verification/audit-logs', (req: Request, res: Response) => {
  res.json({ auditLogs });
});

app.post('/api/verification/verify-record', (req: Request, res: Response) => {
  const { entityType, entityId, newStatus, notes } = req.body;
  
  let target: any = null;
  if (entityType === 'hospital') target = hospitals.find(h => h.id === entityId);
  else if (entityType === 'doctorVisit') target = doctorVisits.find(v => v.id === entityId);
  else if (entityType === 'vacancy') target = vacancies.find(v => v.id === entityId);
  else if (entityType === 'rule') target = governmentRules.find(r => r.id === entityId);
  else if (entityType === 'job') target = jobs.find(j => j.id === entityId);
  else if (entityType === 'route') target = busRoutes.find(b => b.id === entityId);

  if (!target) {
    return res.status(404).json({ error: 'Target record not found' });
  }

  const previousStatus = target.verification.verificationStatus;
  target.verification.verificationStatus = newStatus;
  target.verification.lastUpdated = new Date().toISOString();
  target.verification.verifiedBy = currentUser.name;
  target.verification.updateHistory = target.verification.updateHistory || [];
  target.verification.updateHistory.push({
    timestamp: new Date().toISOString(),
    action: `Status changed from ${previousStatus} to ${newStatus}`,
    user: currentUser.email,
    details: notes
  });

  const logEntry = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    entityType,
    entityId,
    action: `Status updated to ${newStatus}`,
    adminEmail: currentUser.email,
    previousStatus,
    newStatus,
    notes: notes || 'Verified in compliance with Smart Information Standards'
  };
  auditLogs.unshift(logEntry);

  res.json({ success: true, record: target, logEntry });
});

// --- Saved Items & Subscriptions ---
app.post('/api/citizen/toggle-save', (req: Request, res: Response) => {
  const { itemId } = req.body;
  if (!itemId) return res.status(400).json({ error: 'Missing itemId' });
  
  const idx = currentUser.savedItemIds.indexOf(itemId);
  if (idx > -1) {
    currentUser.savedItemIds.splice(idx, 1);
  } else {
    currentUser.savedItemIds.push(itemId);
  }
  res.json({ success: true, savedItemIds: currentUser.savedItemIds });
});

app.post('/api/citizen/update-subscriptions', (req: Request, res: Response) => {
  const { categories } = req.body;
  if (Array.isArray(categories)) {
    currentUser.subscribedCategories = categories;
  }
  res.json({ success: true, subscribedCategories: currentUser.subscribedCategories });
});

// ========================================================
// SMART ACCIDENT EMERGENCY ALERT SYSTEM ENDPOINTS (PRIVACY-FIRST & ANONYMOUS)
// ========================================================

// Security, Transport & Zero-Cache Privacy Headers on all /api/accidents/* routes
app.use('/api/accidents', (_req, res, next) => {
  purgeExpiredAccidents();
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cache-Control', 'no-store, private, max-age=0');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  next();
});

// 1. AI Image Analysis for Road Accident Triage (EXIF stripped BEFORE AI vision call; Zero PII logged)
app.post('/api/accidents/analyze-image', async (req: Request, res: Response) => {
  const { imageBase64, mimeType, latitude, longitude } = req.body || {};

  if (!imageBase64 || typeof imageBase64 !== 'string') {
    return res.status(400).json({
      error: 'An accident photograph is required for AI analysis.'
    });
  }

  const allowedMimes = ['image/jpeg', 'image/png', 'image/webp'];
  const cleanMime = allowedMimes.includes(mimeType) ? mimeType : 'image/jpeg';
  const strippedBase64 = imageBase64.includes(',')
    ? imageBase64.split(',')[1]
    : imageBase64;

  if (!strippedBase64 || strippedBase64.length < 32) {
    return res.status(400).json({
      error: 'Invalid or empty image payload provided.'
    });
  }

  // Strip EXIF, GPS, camera, and device metadata server-side BEFORE forwarding to Gemini Vision
  const rawBuffer = Buffer.from(strippedBase64, 'base64');
  const exifResult = stripImageMetadataBuffer(rawBuffer, cleanMime);
  const cleanBase64ForVision = exifResult.cleaned.toString('base64');

  if (!aiClient) {
    return res.status(503).json({
      error:
        'AI image analysis service is unavailable because GEMINI_API_KEY is not configured on the server. You may still manually classify the accident and confirm the emergency report.',
      code: 'AI_KEY_MISSING',
      exifStripped: true,
      strippedMetadataSegments: exifResult.removedSegments
    });
  }

  const latNum = typeof latitude === 'number' && Number.isFinite(latitude) ? latitude : 17.415;
  const lngNum = typeof longitude === 'number' && Number.isFinite(longitude) ? longitude : 78.46;

  try {
    const requestContents = {
      parts: [
        {
          inlineData: {
            data: cleanBase64ForVision,
            mimeType: cleanMime
          }
        },
        {
          text: `Analyze this uploaded photograph for the IDEAL CITY 360 Smart Accident Emergency Alert System.
GPS Coordinates provided by anonymous reporter: ${latNum.toFixed(5)}, ${lngNum.toFixed(5)}.

Instructions:
1. Determine whether the image appears to depict a road traffic accident or collision (isAccidentDetected: true or false).
2. Classify the possible accidentType into one of: ${VALID_ACCIDENT_TYPES.join(', ')}. If no road accident is visible, set accidentType to "No Road Accident Detected".
3. Estimate visible severity strictly as one of: Low, Medium, Critical (use Low when no accident is detected).
4. List 2 to 4 brief factual visibleIndicators observed directly in the photo (e.g., "Visible front bumper damage", "Downed two-wheeler on carriageway").
5. Provide estimatedInjuredHint as a cautious visual note (e.g., "Requires on-site medical triage").
6. Write a concise 2-sentence shortDescription following this style:
   "Possible two-wheeler and car collision detected. Visible vehicle damage. Accident severity requires human assessment. Location: ${latNum.toFixed(5)}, ${lngNum.toFixed(5)}."
7. CRITICAL SAFETY RULE: NEVER claim to know the exact cause of the accident or assign legal fault from a photograph alone.`
        }
      ]
    };

    const sharedSchema = {
      type: Type.OBJECT,
      properties: {
        isAccidentDetected: { type: Type.BOOLEAN },
        accidentType: {
          type: Type.STRING,
          enum: VALID_ACCIDENT_TYPES
        },
        severity: {
          type: Type.STRING,
          enum: VALID_ACCIDENT_SEVERITIES
        },
        confidenceLabel: {
          type: Type.STRING,
          enum: ['High', 'Moderate', 'Low']
        },
        visibleIndicators: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        },
        estimatedInjuredHint: { type: Type.STRING },
        shortDescription: { type: Type.STRING }
      },
      required: [
        'isAccidentDetected',
        'accidentType',
        'severity',
        'confidenceLabel',
        'visibleIndicators',
        'estimatedInjuredHint',
        'shortDescription'
      ]
    };

    const systemInstruction =
      'You are an emergency road-incident visual triage assistant for IDEAL CITY 360. Be accurate, cautious, and factual. Never fabricate details not visible in the image and never claim that AI can determine the exact cause of an accident from a photograph alone.';

    let modelUsed = 'gemini-4-hydrogen';
    let response;
    try {
      response = await aiClient.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: requestContents,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: sharedSchema
        }
      });
    } catch (primaryErr: any) {
      const msg = String(primaryErr?.message || '');
      if (msg.includes('503') || msg.includes('UNAVAILABLE') || msg.includes('high demand') || msg.includes('429')) {
        modelUsed = 'gemini-3.1-flash-lite';
        response = await aiClient.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: requestContents,
          config: {
            systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: sharedSchema
          }
        });
      } else {
        throw primaryErr;
      }
    }

    const rawText = response.text;
    if (!rawText) {
      return res.status(502).json({
        error: 'AI analysis returned an empty response. Please retry or complete manual incident classification.'
      });
    }

    const parsed = JSON.parse(rawText);
    const accidentType: AccidentType = VALID_ACCIDENT_TYPES.includes(parsed.accidentType)
      ? parsed.accidentType
      : parsed.isAccidentDetected
        ? 'Other Road Incident'
        : 'No Road Accident Detected';
    const severity: AccidentSeverity = VALID_ACCIDENT_SEVERITIES.includes(parsed.severity)
      ? parsed.severity
      : 'Medium';

    const analysis = {
      isAccidentDetected: Boolean(parsed.isAccidentDetected),
      accidentType,
      severity,
      confidenceLabel: ['High', 'Moderate', 'Low'].includes(parsed.confidenceLabel)
        ? parsed.confidenceLabel
        : 'Moderate',
      visibleIndicators: Array.isArray(parsed.visibleIndicators)
        ? parsed.visibleIndicators.slice(0, 5).map(String)
        : ['Visual inspection completed'],
      estimatedInjuredHint:
        typeof parsed.estimatedInjuredHint === 'string' && parsed.estimatedInjuredHint.trim()
          ? parsed.estimatedInjuredHint.trim()
          : 'Requires on-site human medical assessment',
      shortDescription: formatSafeIncidentDescription(parsed.shortDescription, latNum, lngNum),
      disclaimer: AI_CAUSE_DISCLAIMER,
      analyzedAt: new Date().toISOString(),
      modelUsed,
      isManualFallback: false
    };

    return res.json({
      success: true,
      analysis,
      exifStripped: true,
      strippedMetadataSegments: exifResult.removedSegments
    });
  } catch (err: any) {
    // Do NOT log request IP, headers, or reporter details
    console.error('[Accident AI Vision] Upstream Gemini analysis failed');
    return res.status(502).json({
      error:
        'AI image analysis could not be completed by the vision service right now. Please retry or use Manual Incident Classification to confirm and submit your emergency alert.'
    });
  }
});

// 2. Get Emergency Accident Feed (STRICT RBAC — Authorized Emergency Personnel Only!)
app.get('/api/accidents', (_req: Request, res: Response) => {
  if (!canRoleAccessAuthorityDashboard(currentUser.role)) {
    return res.status(403).json({
      error:
        'Access denied: Accident locations, photographs, and live emergency dispatch records are restricted to authorized Hospital, 108 Ambulance, Police, and Command personnel. Citizens may track their own submission anonymously using their Report ID and Secure Tracking Token.'
    });
  }

  const safeReports = accidentReports.map((r) => sanitizeEmergencyIncidentRecord(r));
  res.json({
    reports: safeReports,
    policeStations,
    ambulanceUnits,
    demoDispatchMode: true
  });
});

// 3. Anonymous Report Tracking (No Login Required — Verified via Report ID + Secure Tracking Token)
app.post('/api/accidents/track', (req: Request, res: Response) => {
  const { incidentCode, trackingToken } = req.body || {};
  const cleanCode = typeof incidentCode === 'string' ? incidentCode.trim().toUpperCase() : '';
  const cleanToken = typeof trackingToken === 'string' ? trackingToken.trim().toUpperCase() : '';

  if (!cleanCode || !cleanToken) {
    return res.status(400).json({
      error: 'Both Accident Report ID and Secure Tracking Token are required.'
    });
  }

  const vaultRecord = restrictedPrivacyVault.get(cleanCode);
  if (!vaultRecord || !verifyTrackingTokenHash(cleanToken, vaultRecord.trackingTokenHash)) {
    return res.status(401).json({
      error: 'Invalid Accident Report ID or Secure Tracking Token. Please double-check your credentials.'
    });
  }

  const report = accidentReports.find((r) => r.incidentCode.toUpperCase() === cleanCode);
  if (!report) {
    return res.status(404).json({
      error: 'This accident report was not found or has expired under the 30-day automatic data retention policy.'
    });
  }

  return res.json({
    success: true,
    report: sanitizeEmergencyIncidentRecord(report)
  });
});

// 4. Restricted Secure Photo Access (Authorized Responders OR Matching Report ID + Tracking Token ONLY)
app.get('/api/accidents/media/:photoId', (req: Request, res: Response) => {
  const photoId = String(req.params.photoId || '').trim();
  const record = securePhotoVault.get(photoId);

  if (!record) {
    return res.status(404).json({ error: 'Protected media resource not found or expired.' });
  }

  const isAuthorizedResponder = canRoleAccessAuthorityDashboard(currentUser.role);

  const reportCodeCandidate = String(
    req.query.reportCode || req.headers['x-report-code'] || ''
  )
    .trim()
    .toUpperCase();
  const tokenCandidate = String(
    req.query.token || req.headers['x-tracking-token'] || ''
  )
    .trim()
    .toUpperCase();

  let hasValidTokenAccess = false;
  if (reportCodeCandidate && tokenCandidate && reportCodeCandidate === record.incidentCode.toUpperCase()) {
    const vaultEntry = restrictedPrivacyVault.get(record.incidentCode);
    if (vaultEntry && verifyTrackingTokenHash(tokenCandidate, vaultEntry.trackingTokenHash)) {
      hasValidTokenAccess = true;
    }
  }

  if (!isAuthorizedResponder && !hasValidTokenAccess) {
    return res.status(403).json({
      error: 'Forbidden: Accident photographs are encrypted and restricted to authorized emergency personnel or verified anonymous token holders.'
    });
  }

  try {
    const decryptedBytes = decryptBuffer(record.encrypted, VAULT_ENCRYPTION_KEY);
    res.setHeader('Content-Type', record.mimeType || 'image/jpeg');
    res.setHeader('Content-Disposition', 'inline');
    res.setHeader('Cache-Control', 'no-store, private, max-age=0');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    return res.send(decryptedBytes);
  } catch {
    return res.status(500).json({ error: 'Failed to decrypt protected accident media.' });
  }
});

// 5. Submit Anonymous Confirmed Accident Report (NO Login Required, ZERO PII Collected by Default)
app.post('/api/accidents/report', (req: Request, res: Response) => {
  const body = req.body || {};
  const lat = Number(body.latitude);
  const lng = Number(body.longitude);
  const possibleInjuredCount =
    body.possibleInjuredCount === '' ||
    body.possibleInjuredCount === null ||
    body.possibleInjuredCount === undefined
      ? null
      : Number(body.possibleInjuredCount);

  const optionalCallbackConsented = body.optionalCallbackConsented === true;
  const optionalCallbackPhone =
    optionalCallbackConsented &&
    typeof body.optionalCallbackPhone === 'string' &&
    body.optionalCallbackPhone.trim()
      ? body.optionalCallbackPhone.trim()
      : undefined;

  const validation = validateAccidentSubmission({
    photoDataUrl: body.photoDataUrl,
    latitude: lat,
    longitude: lng,
    locationLabel: body.locationLabel,
    accidentType: body.accidentType,
    severity: body.severity,
    possibleInjuredCount,
    reporterConfirmed: body.reporterConfirmed === true,
    sceneNotes: body.sceneNotes,
    optionalCallbackConsented,
    optionalCallbackPhone:
      typeof body.optionalCallbackPhone === 'string'
        ? body.optionalCallbackPhone.trim()
        : undefined
  });

  if (!validation.valid) {
    return res.status(400).json({
      error: validation.errors[0] || 'Invalid emergency accident report',
      errors: validation.errors
    });
  }

  // Decode uploaded photograph, strip EXIF/GPS/device metadata server-side, and encrypt at rest
  let photoBuffer: Buffer;
  let photoMime = 'image/jpeg';
  const rawPhoto = String(body.photoDataUrl || '').trim();
  if (rawPhoto.startsWith('data:image/')) {
    const mimeMatch = rawPhoto.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,/);
    if (mimeMatch) photoMime = mimeMatch[1];
    const base64Part = rawPhoto.includes(',') ? rawPhoto.split(',')[1] : '';
    photoBuffer = Buffer.from(base64Part, 'base64');
  } else {
    // Safe local sample asset fallback if client passed an asset path
    const safeAsset = path.resolve(process.cwd(), 'public', rawPhoto.replace(/^\/+/, ''));
    photoBuffer = fs.existsSync(safeAsset)
      ? fs.readFileSync(safeAsset)
      : Buffer.from([0xff, 0xd8, 0xff, 0xd9]);
  }

  const exifStripped = stripImageMetadataBuffer(photoBuffer, photoMime);

  const now = new Date();
  const nowIso = now.toISOString();
  const retentionExpiresAt = computeRetentionExpiryIso(nowIso, RETENTION_POLICY_DAYS);
  const incidentDate = nowIso.split('T')[0];
  const incidentTime = now.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });
  const googleMapsUrl = buildGoogleMapsUrl(lat, lng);

  // Cryptographically random Report ID, Secure Tracking Token, and opaque Media ID
  const incidentCode = generateSecureReportId(now.getFullYear());
  const trackingToken = generateSecureTrackingToken();
  const securePhotoId = generateOpaqueMediaId();
  const securePhotoUrl = `/api/accidents/media/${securePhotoId}`;

  // Store encrypted photo in isolated securePhotoVault
  securePhotoVault.set(securePhotoId, {
    incidentCode,
    mimeType: photoMime,
    encrypted: encryptBuffer(exifStripped.cleaned, VAULT_ENCRYPTION_KEY),
    createdAt: nowIso,
    purgeAt: retentionExpiresAt
  });

  // Store ONLY token hash + encrypted optional callback (if opted in) in isolated restrictedPrivacyVault
  restrictedPrivacyVault.set(incidentCode, {
    incidentCode,
    trackingTokenHash: hashTrackingToken(trackingToken),
    encryptedOptionalCallback: optionalCallbackPhone
      ? encryptBuffer(Buffer.from(optionalCallbackPhone, 'utf8'), VAULT_ENCRYPTION_KEY)
      : undefined,
    createdAt: nowIso,
    purgeAt: retentionExpiresAt
  });

  // Match nearest connected hospitals, ambulance unit, and police station
  const nearestHospitals = findNearestHospitals(hospitals, lat, lng, 3);
  const nearestAmb = findNearestAmbulanceUnit(ambulanceUnits, lat, lng);
  const nearestPol = findNearestPoliceStation(policeStations, lat, lng);

  const deliveryMode: 'demo_simulated' | 'live_webhook' = 'demo_simulated';
  const notifiedHospitals = nearestHospitals.map(({ hospital, distanceKm }) => ({
    hospitalId: hospital.id,
    hospitalName: hospital.name,
    distanceKm,
    emergencyPhone: hospital.emergencyPhone,
    lat: hospital.location.lat,
    lng: hospital.location.lng,
    status: 'Notified' as const,
    deliveryConfirmed: true,
    deliveryMode,
    notifiedAt: nowIso,
    updatedAt: nowIso
  }));

  const ambUnit = nearestAmb?.unit || ambulanceUnits[0];
  const routePlan = computeShortestRoute(
    { lat: ambUnit.lat, lng: ambUnit.lng },
    { lat, lng }
  );

  const ambulanceDispatch = {
    unitId: ambUnit.id,
    callSign: ambUnit.callSign,
    stationName: ambUnit.stationName,
    vehicleNumber: ambUnit.vehicleNumber,
    phone: ambUnit.phone,
    originLat: ambUnit.lat,
    originLng: ambUnit.lng,
    distanceKm: routePlan.routeDistanceKm,
    etaMinutes: routePlan.estimatedEtaMinutes,
    routeWaypoints: routePlan.waypoints,
    status: 'Dispatched' as const,
    deliveryConfirmed: true,
    deliveryMode,
    notifiedAt: nowIso,
    updatedAt: nowIso,
    notes: `Shortest corridor route (${routePlan.routeDistanceKm} km) shared with ${ambUnit.callSign}.`
  };

  const polStation = nearestPol?.station || policeStations[0];
  const policeDispatch = {
    stationId: polStation.id,
    stationName: polStation.name,
    zone: polStation.zone,
    phone: polStation.phone,
    lat: polStation.lat,
    lng: polStation.lng,
    distanceKm: nearestPol?.distanceKm ?? 1.2,
    status: 'Notified' as const,
    deliveryConfirmed: true,
    deliveryMode,
    notifiedAt: nowIso,
    updatedAt: nowIso
  };

  const rawAi = body.aiAnalysis || {};
  const safeDescription = formatSafeIncidentDescription(
    rawAi.shortDescription ||
      `Possible ${body.accidentType} reported anonymously. Accident severity requires human assessment.`,
    lat,
    lng
  );

  const authorityAlertText = buildAnonymousAuthorityAlertMessage({
    incidentCode,
    accidentType: body.accidentType,
    severity: body.severity,
    latitude: lat,
    longitude: lng,
    googleMapsUrl,
    incidentDate,
    incidentTime,
    securePhotoUrl,
    possibleInjuredCount,
    optionalCallbackPhone
  });

  // Construct strictly zero-PII emergency incident record (NEVER reads currentUser.name, email, phone, IP, or device info)
  const newReport: AccidentReport = sanitizeEmergencyIncidentRecord({
    id: `acc-${crypto.randomBytes(6).toString('hex')}`,
    incidentCode,
    reportedAt: nowIso,
    incidentDate,
    incidentTime,
    latitude: lat,
    longitude: lng,
    locationLabel:
      typeof body.locationLabel === 'string' && body.locationLabel.trim()
        ? body.locationLabel.trim()
        : `Coordinates ${lat.toFixed(5)}, ${lng.toFixed(5)}`,
    locationSource: body.locationSource === 'gps' ? 'gps' : 'manual_map',
    googleMapsUrl,
    securePhotoId,
    securePhotoUrl,
    aiAnalysis: {
      isAccidentDetected: rawAi.isAccidentDetected !== false,
      accidentType: body.accidentType,
      severity: body.severity,
      confidenceLabel: rawAi.confidenceLabel || 'Moderate',
      visibleIndicators: Array.isArray(rawAi.visibleIndicators)
        ? rawAi.visibleIndicators
        : ['Verified accident scene photograph uploaded (EXIF stripped)'],
      estimatedInjuredHint:
        rawAi.estimatedInjuredHint ||
        (possibleInjuredCount !== null
          ? `Reporter noted ~${possibleInjuredCount} possible injured`
          : 'Requires on-site human assessment'),
      shortDescription: safeDescription,
      disclaimer: AI_CAUSE_DISCLAIMER,
      analyzedAt: rawAi.analyzedAt || nowIso,
      modelUsed: rawAi.modelUsed || 'manual-anonymous-classification',
      isManualFallback: Boolean(rawAi.isManualFallback)
    },
    accidentType: body.accidentType,
    severity: body.severity,
    possibleInjuredCount,
    reporterConfirmed: true,
    confirmedAt: nowIso,
    reporterIdentityMode: optionalCallbackPhone ? 'optional_callback_consented' : 'anonymous',
    reporterIdentityLabel: 'Anonymous',
    optionalCallbackConsented: Boolean(optionalCallbackPhone),
    optionalCallbackPhone,
    sceneNotes:
      typeof body.sceneNotes === 'string' && body.sceneNotes.trim()
        ? body.sceneNotes.trim()
        : undefined,
    authorityAlertText,
    overallStatus: 'Response Dispatched',
    demoMode: true,
    retentionExpiresAt,
    privacyCompliance: {
      exifMetadataStripped: true,
      strippedMetadataSegments: exifStripped.removedSegments,
      encryptedAtRest: true,
      noAiTrainingWithoutConsent: true,
      piiCollected: Boolean(optionalCallbackPhone),
      retentionDays: RETENTION_POLICY_DAYS,
      dpdpActCompliant: true
    },
    notifiedHospitals,
    ambulanceDispatch,
    policeDispatch,
    responseHistory: [
      {
        id: `evt-${Date.now()}-1`,
        timestamp: nowIso,
        actor: 'Anonymous Reporter',
        agency: 'Citizen',
        message: `Confirmed & submitted ${body.severity} severity ${body.accidentType} report at ${lat.toFixed(5)}, ${lng.toFixed(5)}. EXIF metadata removed & photo encrypted.`,
        statusBadge: optionalCallbackPhone ? 'Callback Consented' : 'Anonymous'
      },
      {
        id: `evt-${Date.now()}-2`,
        timestamp: nowIso,
        actor: 'IDEAL 360 Emergency Dispatch API',
        agency: 'Command Center',
        message: `Backend confirmed Demo Mode alerts (Reporter Identity: Anonymous) delivered to ${notifiedHospitals.length} nearby hospitals, Ambulance ${ambUnit.callSign} (ETA ~${routePlan.estimatedEtaMinutes} min), and ${polStation.name}.`,
        statusBadge: 'Delivered (Demo Mode)'
      }
    ]
  }) as AccidentReport;

  accidentReports.unshift(newReport);

  return res.status(201).json({
    success: true,
    demoDispatchMode: true,
    report: newReport,
    trackingToken
  });
});

// 6. Authority Response Status Updates (Role-Based Access Control Enforced)
app.patch('/api/accidents/:id/response', (req: Request, res: Response) => {
  const report = accidentReports.find((r) => r.id === req.params.id);
  if (!report) {
    return res.status(404).json({ error: 'Accident report not found' });
  }

  const { agency, status, hospitalId, etaMinutes, bedsReserved, notes, overallStatus } = req.body || {};

  if (!['hospital', 'ambulance', 'police', 'overall'].includes(agency)) {
    return res.status(400).json({ error: 'Invalid authority agency specified' });
  }

  if (!canRoleUpdateAgency(currentUser.role, agency)) {
    return res.status(403).json({
      error: `Role "${currentUser.role}" is not authorized to update ${agency} emergency response status. Switch to an authorized responder role.`
    });
  }

  const nowIso = new Date().toISOString();

  if (agency === 'hospital') {
    const targetHospital =
      (hospitalId
        ? report.notifiedHospitals.find((h) => h.hospitalId === hospitalId)
        : report.notifiedHospitals[0]) || report.notifiedHospitals[0];
    if (!targetHospital) {
      return res.status(404).json({ error: 'No notified hospital record on this incident' });
    }
    if (status) targetHospital.status = status;
    if (typeof bedsReserved === 'number' && Number.isFinite(bedsReserved) && bedsReserved >= 0) {
      targetHospital.bedsReserved = bedsReserved;
    }
    if (typeof notes === 'string') targetHospital.notes = notes.trim();
    targetHospital.updatedAt = nowIso;

    report.responseHistory.unshift({
      id: `evt-${Date.now()}`,
      timestamp: nowIso,
      actor: currentUser.name,
      agency: 'Hospital',
      message: `${targetHospital.hospitalName} updated status to "${targetHospital.status}"${targetHospital.bedsReserved ? ` (${targetHospital.bedsReserved} trauma bed(s) reserved)` : ''}${targetHospital.notes ? ` — ${targetHospital.notes}` : ''}.`,
      statusBadge: targetHospital.status
    });
  } else if (agency === 'ambulance') {
    if (status) report.ambulanceDispatch.status = status;
    if (etaMinutes !== undefined && etaMinutes !== null && etaMinutes !== '') {
      const parsedEta = Number(etaMinutes);
      if (Number.isFinite(parsedEta) && parsedEta >= 0 && parsedEta <= 180) {
        report.ambulanceDispatch.etaMinutes = Math.round(parsedEta);
      }
    }
    if (typeof notes === 'string') report.ambulanceDispatch.notes = notes.trim();
    report.ambulanceDispatch.updatedAt = nowIso;

    report.responseHistory.unshift({
      id: `evt-${Date.now()}`,
      timestamp: nowIso,
      actor: currentUser.name,
      agency: 'Ambulance',
      message: `${report.ambulanceDispatch.callSign} updated status to "${report.ambulanceDispatch.status}"${report.ambulanceDispatch.etaMinutes !== null ? ` (ETA: ${report.ambulanceDispatch.etaMinutes} min)` : ''}${report.ambulanceDispatch.notes ? ` — ${report.ambulanceDispatch.notes}` : ''}.`,
      statusBadge: report.ambulanceDispatch.status
    });
  } else if (agency === 'police') {
    if (status) report.policeDispatch.status = status;
    if (typeof notes === 'string') report.policeDispatch.officerNotes = notes.trim();
    report.policeDispatch.updatedAt = nowIso;

    report.responseHistory.unshift({
      id: `evt-${Date.now()}`,
      timestamp: nowIso,
      actor: currentUser.name,
      agency: 'Police',
      message: `${report.policeDispatch.stationName} updated investigation status to "${report.policeDispatch.status}"${report.policeDispatch.officerNotes ? ` — ${report.policeDispatch.officerNotes}` : ''}.`,
      statusBadge: report.policeDispatch.status
    });
  } else if (agency === 'overall' && overallStatus) {
    report.overallStatus = overallStatus;
    report.responseHistory.unshift({
      id: `evt-${Date.now()}`,
      timestamp: nowIso,
      actor: currentUser.name,
      agency: 'Command Center',
      message: `Incident overall status marked "${overallStatus}"${notes ? ` — ${String(notes).trim()}` : ''}.`,
      statusBadge: overallStatus
    });
  }

  if (agency !== 'overall') {
    report.overallStatus = deriveOverallAccidentStatus(report);
  }

  return res.json({
    success: true,
    report: sanitizeEmergencyIncidentRecord(report)
  });
});

// --- Maps Configuration & Grounding Endpoints ---
app.get('/api/maps/config', (req: Request, res: Response) => {
  res.json({
    apiKey: process.env.VITE_GOOGLE_MAPS_API_KEY || process.env.GOOGLE_MAPS_API_KEY || ''
  });
});

app.post('/api/maps/grounded-facilities', async (req: Request, res: Response) => {
  const { query, lat, lng } = req.body;
  const targetQuery = query || 'tertiary hospitals and emergency trauma centers';
  const latitude = typeof lat === 'number' ? lat : 17.4150;
  const longitude = typeof lng === 'number' ? lng : 78.4600;

  if (aiClient) {
    try {
      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          { role: 'user', parts: [{ text: `Find the top verified ${targetQuery} with their full name, exact street address, current operating status, and why it is recommended for citizens.` }] }
        ],
        config: {
          systemInstruction: 'You are the Smart City Geolocation Assistant for IDEAL CITY 360. Return verified places grounded with Google Maps. Be concise and authoritative.',
          tools: [{ googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: {
                latitude,
                longitude
              }
            }
          }
        }
      });

      const candidate = response.candidates?.[0];
      const chunks = candidate?.groundingMetadata?.groundingChunks || [];
      const places = chunks
        .filter((c: any) => c.maps)
        .map((c: any) => ({
          title: c.maps?.title || '',
          uri: c.maps?.uri || '',
          placeId: c.maps?.placeId || '',
          address: c.maps?.address || '',
          snippets: c.maps?.placeAnswerSources?.reviewSnippets || []
        }));

      return res.json({
        summary: response.text,
        places,
        query: targetQuery
      });
    } catch (err: any) {
      console.warn('Maps grounding facilities search failed:', err?.message);
    }
  }

  // Fallback if API key not available
  const fallbackHospitals = hospitals.slice(0, 3).map(h => ({
    title: h.name,
    uri: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(h.name + ' ' + h.address)}`,
    placeId: h.id,
    address: h.address,
    snippets: [`Verified public facility: ${h.facilities.join(', ')}`]
  }));

  res.json({
    summary: `Verified Municipal Registry Places for "${targetQuery}":`,
    places: fallbackHospitals,
    query: targetQuery
  });
});

// --- AI Citizen Assistant (IDEAL AI with RAG & Google Maps Grounding) ---
app.post('/api/gemini/assistant', async (req: Request, res: Response) => {
  const { question, history, lat, lng } = req.body;
  if (!question) return res.status(400).json({ error: 'Question is required' });

  const userLat = typeof lat === 'number' ? lat : 17.4150;
  const userLng = typeof lng === 'number' ? lng : 78.4600;

  // Build RAG Context from verified database
  const ragContext = `
VERIFIED SMART CITY DATABASE (IDEAL CITY 360):
1. HOSPITALS:
${hospitals.map(h => `- ${h.name} (${h.type}, ${h.address}, Phone: ${h.phone}, Emergency: ${h.emergencyPhone}, ICU Beds: ${h.bedCount.icu}, Available Beds: ${h.bedCount.available}, Facilities: ${h.facilities.join(', ')}). Source: ${h.verification.sourceName}, Verified: ${h.verification.lastUpdated})`).join('\n')}

2. UPCOMING SPECIALIST DOCTOR VISITS:
${doctorVisits.map(v => `- Doctor: ${v.doctorName} (${v.specialization}) at ${v.hospitalName}. Visit Date: ${v.visitDate}, Hours: ${v.consultationHours}, Room: ${v.roomNumber}, Slots: ${v.bookedTokens}/${v.tokenCapacity} booked. Link: ${v.appointmentLink}. Status: ${v.status}. Verified: ${v.verification.lastUpdated}`).join('\n')}

3. RECRUITMENT & HOSPITAL VACANCIES:
${vacancies.map(v => `- ${v.title} at ${v.hospitalName} (${v.positions} positions). Qualifications: ${v.qualifications}. Eligibility: ${v.eligibility}. Deadline: ${v.deadline}. Salary: ${v.salaryRange}. Application Link: ${v.applicationLink}. Source: ${v.verification.sourceName}`).join('\n')}

4. SMART BUS TRANSIT & SCHEDULES:
${busRoutes.map(r => `- Route ${r.routeNumber}: ${r.name} from ${r.source} to ${r.destination}. Stops: ${r.stops.map(s => s.name).join(' -> ')}. Frequency: every ${r.frequencyMinutes} min. First bus: ${r.firstBus}, Last bus: ${r.lastBus}. Fare: ₹${r.fareMin}-₹${r.fareMax}`).join('\n')}
Live Schedules:
${busSchedules.map(s => `- Route ${s.routeNumber} (${s.busRegistrationNumber}): Current at ${s.currentStop}, next ${s.nextStop}. Scheduled: ${s.scheduledTime}, Estimated: ${s.estimatedTime}, Status: ${s.status} (delay: ${s.delayMinutes}m). Is Live GPS: ${s.isLive}`).join('\n')}
Alerts:
${transportAlerts.map(a => `- Alert: ${a.title} (${a.message})`).join('\n')}

5. GOVERNMENT RULES & SCHEMES:
${governmentRules.map(g => `- Scheme: ${g.title} (${g.department}). Summary: ${g.summary}. Eligibility: ${g.eligibility.join('; ')}. Required Docs: ${g.requiredDocuments.join('; ')}. Fee: ${g.applicationFee}. Source: ${g.officialSourceUrl}`).join('\n')}

6. EMPLOYMENT & OPPORTUNITIES:
${jobs.map(j => `- Job: ${j.title} (${j.organization}, ${j.vacancies} vacancies, Deadline: ${j.deadline}, Salary: ${j.salary}, Link: ${j.applicationLink})`).join('\n')}

7. SOCIAL WELFARE & EMERGENCY CONTACTS:
${socialWelfare.map(w => `- Welfare: ${w.title} (${w.category}) by ${w.provider}. Contact: ${w.contactPhone}. Address: ${w.address}. ${w.description}`).join('\n')}
Emergency:
${emergencyContacts.map(e => `- ${e.serviceName}: Phone ${e.phone} (${e.availableHours})`).join('\n')}

8. VERIFIED CITY BLOOD BANKS:
${bloodBanks.map(b => `- ${b.name} (${b.zone}, Phone: ${b.emergencyPhone}, License: ${b.licenseNumber}). Stock: ${Object.entries(b.inventory).map(([g, u]) => `${g}: ${u}u`).join(', ')}`).join('\n')}
`;

  const systemPrompt = `You are IDEAL AI, the official verified AI Citizen Assistant for IDEAL CITY 360.
Tagline: "Smart Information. Better Living."

CRITICAL RULES:
1. Provide accurate information using the verified smart city repository and real-time Google Maps place grounding.
2. If the user asks about doctor visits, cite the exact doctor name, hospital, room, date, and appointment link.
3. If the user asks about bus timings or transit, cite the route number, stops, and clearly state whether the timing is Live GPS tracking or scheduled timetable.
4. If the user asks about government schemes or certificates, cite the official required documents, eligibility, fees, and official links.
5. If the user asks about places, locations, hospitals, clinics, transit stops, or nearby facilities, ground your answer with accurate Google Maps citations.
6. In every response, include a structured CITATION block at the bottom with:
   - Verified Source Name
   - Verification Status (Verified)
   - Last Updated Date
   - Official Reference Link
7. NEVER fabricate doctor availability, job vacancies, bus timings, or government rules. If information is unavailable in the database, clearly say: "This information is not currently recorded in the verified city registry. Please check with the respective department."
8. Keep responses polite, structured with markdown bolding and bullet points, empathetic, and clear.`;

  if (aiClient) {
    try {
      // Check if location or place grounding is relevant
      const isPlaceQuery = /near|where|hospital|clinic|doctor|pharmacy|route|bus|station|address|location|place|road|emergency|center|zone|find|map/i.test(question);

      const genConfig: any = {
        systemInstruction: systemPrompt
      };

      if (isPlaceQuery) {
        genConfig.tools = [{ googleMaps: {} }];
        genConfig.toolConfig = {
          retrievalConfig: {
            latLng: {
              latitude: userLat,
              longitude: userLng
            }
          }
        };
      }

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          { role: 'user', parts: [{ text: `System Context & Database:\n${ragContext}\n\nUser Question:\n${question}` }] }
        ],
        config: genConfig
      });

      const candidate = response.candidates?.[0];
      const chunks = candidate?.groundingMetadata?.groundingChunks || [];
      const groundingPlaces = chunks
        .filter((c: any) => c.maps)
        .map((c: any) => ({
          title: c.maps?.title || '',
          uri: c.maps?.uri || '',
          placeId: c.maps?.placeId || '',
          address: c.maps?.address || '',
          snippets: c.maps?.placeAnswerSources?.reviewSnippets || []
        }));

      return res.json({ 
        answer: response.text, 
        isAiGenerated: true,
        source: isPlaceQuery && groundingPlaces.length > 0 
          ? 'IDEAL AI (Gemini 3.8 Flash with Google Maps Grounding)' 
          : 'IDEAL AI (Gemini 3.8 Flash Grounded RAG)',
        groundingPlaces,
        mapsGroundingUsed: groundingPlaces.length > 0
      });
    } catch (err: any) {
      console.warn('Gemini API call failed, falling back to local deterministic RAG:', err?.message);
    }
  }

  // Deterministic Local RAG Fallback (ensures offline robustness and instant responses)
  const q = question.toLowerCase();
  let localAnswer = '';
  let citation = {
    source: 'IDEAL CITY 360 Central Verified Registry',
    status: 'Verified',
    timestamp: '2026-11-12T06:30:00Z',
    link: 'https://idealcity360.gov.in'
  };

  if (q.includes('cardio') || q.includes('cardiologist') || q.includes('heart') || (q.includes('doctor') && q.includes('visit'))) {
    const visit = doctorVisits[0];
    localAnswer = `### **Specialist Doctor Visit Schedule**

**${visit.doctorName}** (${visit.specialization})
- **Hospital:** ${visit.hospitalName}
- **Date of Visit:** **${visit.visitDate}**
- **Consultation Hours:** ${visit.consultationHours}
- **Room / Location:** ${visit.roomNumber}
- **Token Availability:** ${visit.bookedTokens} of ${visit.tokenCapacity} slots booked
- **Appointment Link:** [Book Online Slot](${visit.appointmentLink})

*Note: Tokens are allocated on first-come, first-served basis.*`;
    citation = {
      source: visit.verification.sourceName,
      status: visit.verification.verificationStatus,
      timestamp: visit.verification.lastUpdated,
      link: visit.verification.sourceUrl
    };
  } else if (q.includes('nurse') || q.includes('vacancy') || q.includes('recruitment') || q.includes('hospital job')) {
    const nurseVac = vacancies.find(v => v.roleType === 'Nurse') || vacancies[0];
    localAnswer = `### **Verified Hospital Recruitment Announcement**

**${nurseVac.title}**
- **Hospital:** ${nurseVac.hospitalName}
- **Positions:** **${nurseVac.positions} Openings**
- **Qualifications:** ${nurseVac.qualifications}
- **Eligibility:** ${nurseVac.eligibility}
- **Salary / Remuneration:** ${nurseVac.salaryRange}
- **Application Deadline:** **${nurseVac.deadline}**
- **Official Application Portal:** [Official Application Link](${nurseVac.applicationLink})`;
    citation = {
      source: nurseVac.verification.sourceName,
      status: nurseVac.verification.verificationStatus,
      timestamp: nurseVac.verification.lastUpdated,
      link: nurseVac.verification.sourceUrl
    };
  } else if (q.includes('bus') || q.includes('next bus') || q.includes('transport') || q.includes('route')) {
    const sched = busSchedules[0];
    localAnswer = `### **Smart Bus Schedule Information**

**Route ${sched.routeNumber}** (Bus Reg: ${sched.busRegistrationNumber})
- **Source to Destination:** ${sched.source} ➔ ${sched.destination}
- **Current Location:** Approaching **${sched.currentStop}**
- **Next Stop:** **${sched.nextStop}**
- **Scheduled Time:** ${sched.scheduledTime}
- **Live GPS Estimated Time:** **${sched.estimatedTime}** (${sched.status})
- **Live Status:** ${sched.isLive ? '🟢 Real-time Telematics Active' : '⚪ Timetable Timings'}
- **Current Occupancy:** ${sched.occupancy}`;
    citation = {
      source: sched.verification.sourceName,
      status: sched.verification.verificationStatus,
      timestamp: sched.verification.lastUpdated,
      link: sched.verification.sourceUrl
    };
  } else if (q.includes('birth certificate') || q.includes('certificate') || q.includes('documents')) {
    const rule = governmentRules[1];
    localAnswer = `### **Citizen Service: ${rule.title}**

**Overview:**
${rule.summary}

**Required Documents:**
${rule.requiredDocuments.map(d => `- ${d}`).join('\n')}

**Step-by-Step Procedure:**
${rule.applicationSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}

**Application Fee:**
${rule.applicationFee}`;
    citation = {
      source: rule.verification.sourceName,
      status: rule.verification.verificationStatus,
      timestamp: rule.verification.lastUpdated,
      link: rule.officialSourceUrl
    };
  } else if (q.includes('scheme') || q.includes('aarogyasri') || q.includes('free health') || q.includes('health service')) {
    const scheme = governmentRules[0];
    localAnswer = `### **Verified Government Health Scheme: ${scheme.title}**

**Coverage & Benefits:**
${scheme.summary}

**Eligibility Criteria:**
${scheme.eligibility.map(e => `- ${e}`).join('\n')}

**Required Documents:**
${scheme.requiredDocuments.map(d => `- ${d}`).join('\n')}

**Application Fee:**
${scheme.applicationFee}`;
    citation = {
      source: scheme.verification.sourceName,
      status: scheme.verification.verificationStatus,
      timestamp: scheme.verification.lastUpdated,
      link: scheme.officialSourceUrl
    };
  } else if (q.includes('blood') || q.includes('donor') || q.includes('plasma') || q.includes('platelet')) {
    const bank = bloodBanks[0];
    localAnswer = `### **Verified City Blood Bank Inventory & Services**

**${bank.name}** (${bank.zone})
- **24x7 Emergency Phone:** ${bank.emergencyPhone}
- **Current Stock Snapshot:** O+: ${bank.inventory['O+']}u | O-: ${bank.inventory['O-']}u | A+: ${bank.inventory['A+']}u | B+: ${bank.inventory['B+']}u | AB-: ${bank.inventory['AB-']}u
- **Component Separation:** ${bank.componentSeparation ? 'PRBC, Platelets & Plasma Available' : 'Whole Blood'}
- **Citizen Actions:** Open **Smart Healthcare -> Blood Bank** to **Request Blood** urgently or **Donate Blood** at any licensed city center.`;
    citation = {
      source: bank.verification.sourceName,
      status: bank.verification.verificationStatus,
      timestamp: bank.verification.lastUpdated,
      link: bank.verification.sourceUrl
    };
  } else {
    localAnswer = `### **IDEAL CITY 360 Information Search**

I searched our verified municipal repository for **"${question}"**. 

Here are top available city services you can explore:
- **Smart Healthcare:** 4 Verified Tertiary Hospitals, 12 OPD Rosters, and Live Bed Tracking.
- **Smart Transport:** Real-time Bus GPS on Routes 100E, 218H, and 5K.
- **Government Services:** Aarogyasri Health Scheme, Birth Certificates, and Rooftop Solar Subsidies.
- **Emergency Helplines:** Ambulance (108), Police (100/112), Women Safety SHE Teams (1091).

If you need a specific doctor schedule, job vacancy deadline, or bus timetable, please specify!`;
  }

  // Append verified citation footer
  localAnswer += `\n\n---\n**Verified Verification Details:**\n- **Source:** ${citation.source}\n- **Verification Status:** [${citation.status}]\n- **Last Updated:** ${citation.timestamp}\n- **Official Reference:** [${citation.link}](${citation.link})`;

  res.json({
    answer: localAnswer,
    isAiGenerated: false,
    source: 'IDEAL CITY 360 Verified Registry RAG'
  });
});

// --- AI Document Explainer (Plain Language Breakdown) ---
app.post('/api/gemini/explain-doc', async (req: Request, res: Response) => {
  const { ruleId, language } = req.body;
  const rule = governmentRules.find(r => r.id === ruleId) || governmentRules[0];

  const prompt = `Explain the following government scheme/document in very simple, jargon-free bullet points for an ordinary citizen.
Language requested: ${language === 'te' ? 'Telugu (తెలుగు)' : 'English'}.

Title: ${rule.title}
Department: ${rule.department}
Summary: ${rule.summary}
Eligibility: ${rule.eligibility.join(', ')}
Required Documents: ${rule.requiredDocuments.join(', ')}
Application Steps: ${rule.applicationSteps.join(', ')}
Fees: ${rule.applicationFee}
Official Source: ${rule.officialSourceUrl}

Format the response into 4 distinct sections:
1. What is this scheme? (2 simple sentences)
2. Who can apply? (clear checklist)
3. What documents to bring?
4. How to get it done step-by-step & fees.`;

  if (aiClient) {
    try {
      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt
      });
      return res.json({ explanation: response.text });
    } catch (err: any) {
      console.warn('AI document explanation failed, using fallback:', err?.message);
    }
  }

  // Fallback summary
  const fallback = language === 'te'
    ? `### ${rule.title} - సులభమైన వివరణ
1. **పథకం వివరాలు:** ${rule.summary}
2. **అర్హత:** ${rule.eligibility.slice(0, 2).join('; ')}
3. **కావలసిన పత్రాలు:** ${rule.requiredDocuments.join(', ')}
4. **రుసుము:** ${rule.applicationFee}`
    : `### ${rule.title} - Simple Plain-Language Guide
1. **What is it?** ${rule.summary}
2. **Who is eligible?** ${rule.eligibility.join('; ')}
3. **What documents are required?** ${rule.requiredDocuments.join(', ')}
4. **Fees & Next Steps:** ${rule.applicationFee}. Follow the 5-step digital process or visit your nearest MeeSeva center.`;

  res.json({ explanation: fallback });
});

// Vite middleware in dev or static files in production
async function startServer() {
  const distPath = path.resolve(process.cwd(), 'dist');
  const hasBuiltDist = fs.existsSync(path.join(distPath, 'index.html'));
  const isProduction = process.env.NODE_ENV === 'production' || (process.env.NODE_ENV !== 'development' && hasBuiltDist);

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[IDEAL CITY 360] Full-stack Server running at http://localhost:${PORT}`);
  });
}

startServer();
