import React, { useState } from 'react';
import { JobListing, User } from '../types';
import { VerificationBadge } from '../components/VerificationBadge';
import { Briefcase, Search, MapPin, ExternalLink, Calendar, PlusCircle, CheckCircle, GraduationCap } from 'lucide-react';

interface Props {
  jobs: JobListing[];
  currentUser: User;
  onAddJob: (job: Partial<JobListing>) => void;
}

export const EmploymentModule: React.FC<Props> = ({ jobs, currentUser, onAddJob }) => {
  const [selectedSector, setSelectedSector] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredJobs = jobs.filter(j => {
    const matchesSector = selectedSector === 'all' || j.sector === selectedSector;
    const matchesType = selectedType === 'all' || j.type === selectedType;
    const matchesSearch = j.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          j.organization.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          j.qualification.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSector && matchesType && matchesSearch;
  });

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-950 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-8 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                <Briefcase className="w-3.5 h-3.5" /> Employment & Public Opportunities
              </span>
              <span className="text-xs text-slate-400">Direct Official Recruitment Links</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Verified Jobs, Internships & Scholarships
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
              Cross-checked public service notifications, municipal technical internships, hospital staff recruitment, and state merit scholarships.
            </p>
          </div>
        </div>

        {/* Sector Tabs */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-slate-800 text-xs">
          {['all', 'Government', 'Hospital', 'Private', 'Education'].map(sec => (
            <button
              key={sec}
              type="button"
              onClick={() => setSelectedSector(sec)}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors capitalize ${
                selectedSector === sec ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
              }`}
            >
              {sec === 'all' ? 'All Sectors' : `${sec} Sector`}
            </button>
          ))}
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by role, organization, or qualifications..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <div className="flex items-center gap-2 text-xs">
          <select
            value={selectedType}
            onChange={e => setSelectedType(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-700 text-xs focus:outline-hidden"
          >
            <option value="all">All Opportunity Types</option>
            <option value="Full-time">Full-time Regular</option>
            <option value="Internship">Internship</option>
            <option value="Scholarship">Scholarship</option>
            <option value="Competitive Exam">Competitive Exam</option>
          </select>
        </div>
      </div>

      {/* Jobs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredJobs.map(job => (
          <div key={job.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between space-y-4 hover:border-amber-400 transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                  {job.type} • {job.vacancies} Positions
                </span>
                <span className="text-xs font-semibold text-rose-600">
                  Deadline: {new Date(job.deadline).toLocaleDateString()}
                </span>
              </div>

              <h3 className="font-bold text-slate-900 text-base leading-snug">{job.title}</h3>
              <div className="text-xs text-slate-600 font-medium mt-1">{job.organization}</div>

              <div className="mt-3 text-xs text-slate-600 space-y-1.5 bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div><strong>Qualification:</strong> {job.qualification}</div>
                <div><strong>Location:</strong> {job.location}</div>
                <div><strong>Remuneration / Pay:</strong> <span className="text-emerald-700 font-bold">{job.salary}</span></div>
              </div>
            </div>

            <div className="space-y-3 pt-3 border-t border-slate-100">
              <VerificationBadge verification={job.verification} />
              <a
                href={job.applicationLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-1.5 text-center shadow-xs"
              >
                Apply on Official Portal <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
