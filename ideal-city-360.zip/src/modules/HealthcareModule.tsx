import React, { useEffect, useState } from 'react';
import {
  Hospital,
  Doctor,
  DoctorVisit,
  HospitalVacancy,
  HealthCamp,
  BloodBank,
  BloodRequest,
  BloodDonationPledge,
  DonorLeaderboardEntry,
  User
} from '../types';
import { VerificationBadge } from '../components/VerificationBadge';
import { InteractiveCityMap } from '../components/InteractiveCityMap';
import { BloodBankSection } from '../components/BloodBankSection';
import { 
  HeartPulse, 
  Search, 
  MapPin, 
  Phone, 
  Calendar, 
  Clock, 
  Briefcase, 
  PlusCircle, 
  Bookmark, 
  BookmarkCheck, 
  CheckCircle2, 
  Filter, 
  Activity,
  Bed,
  Stethoscope,
  ExternalLink,
  ShieldCheck,
  Map as MapIcon,
  LayoutGrid,
  Droplet,
  HeartHandshake
} from 'lucide-react';

interface Props {
  hospitals: Hospital[];
  doctors: Doctor[];
  visits: DoctorVisit[];
  vacancies: HospitalVacancy[];
  camps: HealthCamp[];
  bloodBanks: BloodBank[];
  bloodRequests: BloodRequest[];
  bloodDonations: BloodDonationPledge[];
  donorLeaderboard: DonorLeaderboardEntry[];
  currentUser: User;
  onBookToken: (visitId: string) => void;
  onToggleSave: (itemId: string) => void;
  onAddVisit: (visit: Partial<DoctorVisit>) => void;
  onAddHospital: (hospital: Partial<Hospital>) => void;
  onSubmitBloodRequest: (req: Omit<BloodRequest, 'id' | 'requestCode' | 'status' | 'createdAt'>) => Promise<void> | void;
  onSubmitBloodDonation: (don: Omit<BloodDonationPledge, 'id' | 'pledgeCode' | 'status' | 'createdAt'>) => Promise<void> | void;
  onCompleteDonation: (donationId: string) => void;
  initialSubTab?: 'hospitals' | 'doctors' | 'visits' | 'bloodBank' | 'vacancies' | 'camps';
  onClearInitialSubTab?: () => void;
}

export const HealthcareModule: React.FC<Props> = ({
  hospitals,
  doctors,
  visits,
  vacancies,
  camps,
  bloodBanks,
  bloodRequests,
  bloodDonations,
  donorLeaderboard,
  currentUser,
  onBookToken,
  onToggleSave,
  onAddVisit,
  onAddHospital,
  onSubmitBloodRequest,
  onSubmitBloodDonation,
  onCompleteDonation,
  initialSubTab,
  onClearInitialSubTab
}) => {
  const [activeTab, setActiveTab] = useState<'hospitals' | 'doctors' | 'visits' | 'bloodBank' | 'vacancies' | 'camps'>(initialSubTab || 'hospitals');
  const [bloodModalSignal, setBloodModalSignal] = useState<'request' | 'donate' | null>(null);

  useEffect(() => {
    if (initialSubTab) {
      setActiveTab(initialSubTab);
      onClearInitialSubTab?.();
    }
  }, [initialSubTab, onClearInitialSubTab]);
  const [hospitalViewMode, setHospitalViewMode] = useState<'grid' | 'map'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialization, setSelectedSpecialization] = useState('all');
  const [selectedArea, setSelectedArea] = useState('all');
  const [showAddVisitModal, setShowAddVisitModal] = useState(false);
  const [newVisitData, setNewVisitData] = useState({
    doctorName: '',
    specialization: 'Cardiology',
    hospitalId: hospitals[0]?.id || '',
    hospitalName: hospitals[0]?.name || '',
    visitDate: '2026-11-20',
    consultationHours: '09:00 AM - 01:00 PM',
    appointmentLink: 'https://idealcity.gov.in/opd',
    roomNumber: 'OPD Chamber 101',
    tokenCapacity: 40
  });

  const canManage = currentUser.role === 'super_admin' || currentUser.role === 'hospital_admin';

  // Filtered Hospitals
  const filteredHospitals = hospitals.filter(h => {
    const matchesSearch = h.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          h.facilities.some(f => f.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesArea = selectedArea === 'all' || h.location.area === selectedArea;
    return matchesSearch && matchesArea;
  });

  // Filtered Doctors
  const filteredDoctors = doctors.filter(d => {
    const matchesSearch = d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          d.hospitalName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSpec = selectedSpecialization === 'all' || d.specialization === selectedSpecialization;
    return matchesSearch && matchesSpec;
  });

  // Filtered Visits
  const filteredVisits = visits.filter(v => {
    const matchesSearch = v.doctorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          v.hospitalName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSpec = selectedSpecialization === 'all' || v.specialization.toLowerCase().includes(selectedSpecialization.toLowerCase());
    return matchesSearch && matchesSpec;
  });

  // Filtered Vacancies
  const filteredVacancies = vacancies.filter(v => {
    return v.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
           v.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
           v.roleType.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const handleCreateVisit = (e: React.FormEvent) => {
    e.preventDefault();
    const hosp = hospitals.find(h => h.id === newVisitData.hospitalId);
    onAddVisit({
      ...newVisitData,
      hospitalName: hosp?.name || newVisitData.hospitalName
    });
    setShowAddVisitModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-8 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <HeartPulse className="w-3.5 h-3.5" /> Smart Healthcare Hub
              </span>
              <span className="text-xs text-slate-400">Integrated Medical Registry</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Tertiary Hospitals & Specialist Care
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
              Real-time ICU bed availability, specialist doctor visiting rosters, city blood bank inventory with Request &amp; Donate Blood options, hospital staff vacancies, and free health camps.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0 self-start md:self-auto">
            {activeTab !== 'bloodBank' && (
              <>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('bloodBank');
                    setBloodModalSignal('request');
                  }}
                  className="bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-3.5 py-2.5 rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Droplet className="w-4 h-4 fill-current" />
                  <span>Request Blood</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('bloodBank');
                    setBloodModalSignal('donate');
                  }}
                  className="bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold px-3.5 py-2.5 rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <HeartHandshake className="w-4 h-4" />
                  <span>Donate Blood</span>
                </button>
              </>
            )}
            {canManage && (
              <button
                type="button"
                onClick={() => setShowAddVisitModal(true)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3.5 py-2.5 rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Schedule Specialist Visit</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('hospitals')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors cursor-pointer ${
              activeTab === 'hospitals' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Hospitals Directory ({hospitals.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('visits')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors cursor-pointer ${
              activeTab === 'visits' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Specialist Visits ({visits.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('doctors')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors cursor-pointer ${
              activeTab === 'doctors' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Doctors Directory ({doctors.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('bloodBank')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'bloodBank'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'text-rose-200 hover:bg-rose-500/20 border border-rose-500/30'
            }`}
          >
            <Droplet className="w-3.5 h-3.5 fill-current" />
            <span>Blood Bank ({bloodBanks.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('vacancies')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors cursor-pointer ${
              activeTab === 'vacancies' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Recruitment Vacancies ({vacancies.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('camps')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors cursor-pointer ${
              activeTab === 'camps' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Free Health Camps ({camps.length})
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={
              activeTab === 'bloodBank'
                ? 'Search blood banks, zones or license numbers...'
                : 'Search hospitals, doctors, specialties or jobs...'
            }
            aria-label="Search Smart Healthcare"
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto text-xs">
          {(activeTab === 'hospitals' || activeTab === 'bloodBank') && (
            <select
              value={selectedArea}
              onChange={e => setSelectedArea(e.target.value)}
              aria-label="Filter by Zone"
              className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-700 dark:text-slate-200 text-xs focus:outline-hidden"
            >
              <option value="all">All Zones & Areas</option>
              <option value="Central Zone">Central Zone</option>
              <option value="Cyber Zone">Cyber Zone</option>
              <option value="North Zone">North Zone</option>
              <option value="South Zone">South Zone</option>
            </select>
          )}

          {(activeTab === 'doctors' || activeTab === 'visits') && (
            <select
              value={selectedSpecialization}
              onChange={e => setSelectedSpecialization(e.target.value)}
              aria-label="Filter by Specialization"
              className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-700 dark:text-slate-200 text-xs focus:outline-hidden"
            >
              <option value="all">All Specializations</option>
              <option value="Cardiology">Cardiology</option>
              <option value="Neurology">Neurology</option>
              <option value="Orthopedics">Orthopedics</option>
              <option value="Pediatrics">Pediatrics</option>
              <option value="Oncology">Oncology</option>
            </select>
          )}
        </div>
      </div>

      {/* TAB 1: HOSPITALS */}
      {activeTab === 'hospitals' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Showing {filteredHospitals.length} verified hospitals in municipal directory
            </span>
            <div className="flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1 rounded-xl shadow-xs">
              <button
                type="button"
                onClick={() => setHospitalViewMode('grid')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  hospitalViewMode === 'grid'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                Grid View
              </button>
              <button
                type="button"
                onClick={() => setHospitalViewMode('map')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  hospitalViewMode === 'map'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <MapIcon className="w-3.5 h-3.5" />
                Google Maps View
              </button>
            </div>
          </div>

          {hospitalViewMode === 'map' ? (
            <InteractiveCityMap hospitals={filteredHospitals} routes={[]} selectedCategory="hospitals" />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredHospitals.map(hosp => {
                const isSaved = currentUser.savedItemIds.includes(hosp.id);
                return (
                  <div key={hosp.id} className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between hover:border-emerald-500 transition-all space-y-4">
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                        {hosp.type}
                      </span>
                      <h3 className="font-bold text-slate-900 text-base mt-1.5">{hosp.name}</h3>
                      <p className="text-xs text-slate-500 flex items-center gap-1 mt-1">
                        <MapPin className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                        {hosp.address}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => onToggleSave(hosp.id)}
                      className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                        isSaved ? 'bg-amber-50 border-amber-300 text-amber-600' : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-slate-700'
                      }`}
                      title={isSaved ? 'Remove from saved' : 'Save Hospital'}
                    >
                      {isSaved ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Bed Counts Tracker */}
                  <div className="grid grid-cols-3 gap-2 mt-4 bg-slate-50 p-3 rounded-xl border border-slate-100 text-center">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-medium">Total Beds</span>
                      <span className="text-sm font-bold text-slate-800">{hosp.bedCount.total}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-emerald-600 block font-medium">Available</span>
                      <span className="text-sm font-bold text-emerald-700">{hosp.bedCount.available}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-rose-600 block font-medium">ICU Beds</span>
                      <span className="text-sm font-bold text-rose-700">{hosp.bedCount.icu}</span>
                    </div>
                  </div>

                  {/* Facilities Tags */}
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {hosp.facilities.map((fac, fIdx) => (
                      <span key={fIdx} className="text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-medium">
                        {fac}
                      </span>
                    ))}
                  </div>

                  <div className="mt-3 text-xs text-slate-600 space-y-1">
                    <div><strong>OPD & Emergency:</strong> {hosp.openHours}</div>
                    <div className="text-sky-700 font-semibold flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5" /> Emergency Phone: {hosp.emergencyPhone}
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <VerificationBadge verification={hosp.verification} />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  )}

      {/* TAB 2: SPECIALIST VISITS */}
      {activeTab === 'visits' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredVisits.map(visit => (
            <div key={visit.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between hover:border-emerald-500 transition-all space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                    {visit.specialization}
                  </span>
                  <span className="text-xs font-semibold text-slate-600">
                    Tokens: <strong className="text-slate-900">{visit.bookedTokens}/{visit.tokenCapacity}</strong>
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-base">{visit.doctorName}</h3>
                <div className="text-xs text-teal-700 font-medium mt-0.5 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 shrink-0" /> {visit.hospitalName}
                </div>

                <div className="mt-3 bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs space-y-1.5">
                  <div className="flex items-center justify-between text-slate-700">
                    <span>Date: <strong>{new Date(visit.visitDate).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}</strong></span>
                    <span>Room: <strong>{visit.roomNumber}</strong></span>
                  </div>
                  <div className="text-slate-500 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" /> {visit.consultationHours}
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-1.5 mt-2 overflow-hidden">
                    <div 
                      className="bg-emerald-600 h-1.5 rounded-full"
                      style={{ width: `${(visit.bookedTokens / visit.tokenCapacity) * 100}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-3 pt-3 border-t border-slate-100">
                <VerificationBadge verification={visit.verification} showDetails={false} />
                <button
                  type="button"
                  onClick={() => onBookToken(visit.id)}
                  disabled={visit.bookedTokens >= visit.tokenCapacity}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white text-xs font-bold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  {visit.bookedTokens >= visit.tokenCapacity ? 'Slots Fully Booked' : 'Book Consultation Token'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: DOCTORS DIRECTORY */}
      {activeTab === 'doctors' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDoctors.map(doc => (
            <div key={doc.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between space-y-3">
              <div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-sky-50 text-sky-800 border border-sky-200">
                  {doc.specialization}
                </span>
                <h3 className="font-bold text-slate-900 text-sm mt-1">{doc.name}</h3>
                <p className="text-[11px] text-slate-500">{doc.qualification}</p>

                <div className="mt-3 text-xs text-slate-600 space-y-1">
                  <div><strong>Hospital:</strong> {doc.hospitalName}</div>
                  <div><strong>Experience:</strong> {doc.experienceYears} Years</div>
                  <div><strong>Consultation Fee:</strong> {doc.consultationFee === 0 ? 'Free (Govt Hospital)' : `₹${doc.consultationFee}`}</div>
                  <div><strong>OPD Timings:</strong> {doc.timings} ({doc.availableDays.join(', ')})</div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100">
                <VerificationBadge verification={doc.verification} showDetails={false} />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 4: BLOOD BANK */}
      {activeTab === 'bloodBank' && (
        <BloodBankSection
          bloodBanks={bloodBanks}
          bloodRequests={bloodRequests}
          bloodDonations={bloodDonations}
          donorLeaderboard={donorLeaderboard}
          hospitals={hospitals}
          currentUser={currentUser}
          searchQuery={searchQuery}
          selectedZone={selectedArea}
          onSubmitBloodRequest={onSubmitBloodRequest}
          onSubmitBloodDonation={onSubmitBloodDonation}
          onCompleteDonation={onCompleteDonation}
          openModalSignal={bloodModalSignal}
          onClearModalSignal={() => setBloodModalSignal(null)}
        />
      )}

      {/* TAB 5: VACANCIES */}
      {activeTab === 'vacancies' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredVacancies.map(vac => (
            <div key={vac.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between space-y-4 hover:border-teal-500 transition-all">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-teal-50 text-teal-800 border border-teal-200">
                    {vac.roleType} • {vac.positions} Vacancies
                  </span>
                  <span className="text-xs font-semibold text-rose-600">
                    Deadline: {new Date(vac.deadline).toLocaleDateString()}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-base">{vac.title}</h3>
                <div className="text-xs text-slate-600 font-medium mt-0.5">{vac.hospitalName} • {vac.department}</div>

                <div className="mt-3 text-xs text-slate-600 space-y-1.5 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <div><strong>Required Qualifications:</strong> {vac.qualifications}</div>
                  <div><strong>Eligibility:</strong> {vac.eligibility}</div>
                  <div><strong>Remuneration / Pay:</strong> <span className="text-emerald-700 font-bold">{vac.salaryRange}</span></div>
                </div>
              </div>

              <div className="space-y-3 pt-3 border-t border-slate-100">
                <VerificationBadge verification={vac.verification} />
                <a
                  href={vac.applicationLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-1.5 text-center shadow-xs"
                >
                  Apply on Official Portal <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 5: FREE HEALTH CAMPS */}
      {activeTab === 'camps' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {camps.map(camp => (
            <div key={camp.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                    100% Free Public Camp
                  </span>
                  <span className="text-xs font-semibold text-slate-600">
                    Date: {new Date(camp.date).toLocaleDateString()}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-base">{camp.title}</h3>
                <p className="text-xs text-slate-500 mt-1">Organized by: {camp.organizer}</p>

                <div className="mt-3 text-xs text-slate-600 space-y-1.5 bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <div><strong>Location:</strong> {camp.location}</div>
                  <div><strong>Timings:</strong> {camp.timings}</div>
                  <div><strong>Helpline:</strong> {camp.contactNumber}</div>
                  <div className="pt-1">
                    <strong>Included Services:</strong>
                    <ul className="list-disc list-inside mt-1 space-y-0.5 text-slate-700">
                      {camp.servicesProvided.map((s, idx) => (
                        <li key={idx}>{s}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100">
                <VerificationBadge verification={camp.verification} />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Visit Modal for Hospital Admins */}
      {showAddVisitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-bold text-slate-900 text-base">Schedule Specialist Doctor Visit</h3>
              <button
                type="button"
                onClick={() => setShowAddVisitModal(false)}
                className="text-slate-400 hover:text-slate-700 text-lg leading-none p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateVisit} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Doctor Name & Title</label>
                <input
                  type="text"
                  required
                  value={newVisitData.doctorName}
                  onChange={e => setNewVisitData({ ...newVisitData, doctorName: e.target.value })}
                  placeholder="e.g. Dr. Anand Kumar Swaminathan, MD, DM"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Specialization</label>
                  <select
                    value={newVisitData.specialization}
                    onChange={e => setNewVisitData({ ...newVisitData, specialization: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                  >
                    <option value="Cardiology">Cardiology</option>
                    <option value="Neurology">Neurology</option>
                    <option value="Orthopedics">Orthopedics</option>
                    <option value="Pediatrics">Pediatrics</option>
                    <option value="Surgical Oncology">Surgical Oncology</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Hospital</label>
                  <select
                    value={newVisitData.hospitalId}
                    onChange={e => setNewVisitData({ ...newVisitData, hospitalId: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                  >
                    {hospitals.map(h => (
                      <option key={h.id} value={h.id}>{h.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Visit Date</label>
                  <input
                    type="date"
                    required
                    value={newVisitData.visitDate}
                    onChange={e => setNewVisitData({ ...newVisitData, visitDate: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                  >
                  </input>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Consultation Hours</label>
                  <input
                    type="text"
                    value={newVisitData.consultationHours}
                    onChange={e => setNewVisitData({ ...newVisitData, consultationHours: e.target.value })}
                    placeholder="09:00 AM - 01:00 PM"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Room / Chamber Number</label>
                  <input
                    type="text"
                    value={newVisitData.roomNumber}
                    onChange={e => setNewVisitData({ ...newVisitData, roomNumber: e.target.value })}
                    placeholder="OPD Block A - Chamber 104"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Max Token Capacity</label>
                  <input
                    type="number"
                    value={newVisitData.tokenCapacity}
                    onChange={e => setNewVisitData({ ...newVisitData, tokenCapacity: parseInt(e.target.value, 10) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddVisitModal(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-lg font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white rounded-lg font-semibold hover:bg-emerald-700 shadow-xs"
                >
                  Publish Verified Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
