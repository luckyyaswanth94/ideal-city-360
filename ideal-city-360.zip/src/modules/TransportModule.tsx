import React, { useState } from 'react';
import { BusRoute, BusSchedule, TransportAlert, Hospital, User } from '../types';
import { VerificationBadge } from '../components/VerificationBadge';
import { InteractiveCityMap } from '../components/InteractiveCityMap';
import { BusRouteLeafletMap } from '../components/BusRouteLeafletMap';
import { 
  Bus, 
  Search, 
  MapPin, 
  Clock, 
  AlertTriangle, 
  Radio, 
  PlusCircle, 
  ArrowRight, 
  Zap, 
  Navigation,
  CheckCircle2,
  Calendar,
  Layers,
  Map as MapIcon,
  LayoutGrid
} from 'lucide-react';

interface Props {
  routes: BusRoute[];
  schedules: BusSchedule[];
  alerts: TransportAlert[];
  hospitals: Hospital[];
  currentUser: User;
  onAddAlert: (alert: Partial<TransportAlert>) => void;
}

export const TransportModule: React.FC<Props> = ({
  routes,
  schedules,
  alerts,
  hospitals,
  currentUser,
  onAddAlert
}) => {
  const [activeTab, setActiveTab] = useState<'routes' | 'schedules' | 'alerts' | 'map'>('routes');
  const [routeViewMode, setRouteViewMode] = useState<'both' | 'map' | 'cards'>('both');
  const [selectedRouteForMap, setSelectedRouteForMap] = useState<string>(routes[0]?.id || '');
  const [searchRoute, setSearchRoute] = useState('');
  const [sourceStop, setSourceStop] = useState('');
  const [destStop, setDestStop] = useState('');
  const [timingResults, setTimingResults] = useState<BusRoute[] | null>(null);
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [mapTabEngine, setMapTabEngine] = useState<'leaflet' | 'gmp'>('leaflet');
  const [newAlertData, setNewAlertData] = useState({
    title: '',
    routeNumber: '100E',
    type: 'Delay' as const,
    message: '',
    effectiveFrom: new Date().toISOString().split('T')[0],
    effectiveUntil: '2026-11-20'
  });

  const canManage = currentUser.role === 'super_admin' || currentUser.role === 'transport_admin';

  // Search by stops
  const handleFindBus = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sourceStop && !destStop) {
      setTimingResults(null);
      return;
    }
    const matched = routes.filter(r => {
      const hasSrc = !sourceStop || r.stops.some(s => s.name.toLowerCase().includes(sourceStop.toLowerCase()));
      const hasDst = !destStop || r.stops.some(s => s.name.toLowerCase().includes(destStop.toLowerCase()));
      return hasSrc && hasDst;
    });
    setTimingResults(matched);
  };

  const handleCreateAlert = (e: React.FormEvent) => {
    e.preventDefault();
    onAddAlert(newAlertData);
    setShowAlertModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-sky-950 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-8 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-sky-500/20 text-sky-300 border border-sky-500/30 flex items-center gap-1">
                <Bus className="w-3.5 h-3.5" /> Intelligent Transit System
              </span>
              <span className="text-xs text-slate-400">Zero-Emission Electric & Feeder Network</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Smart Electric Bus Transit & Live Schedules
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
              Access real-time GPS arrival telematics, planned timetables, interactive route maps, and road diversion advisories with verified timestamp telemetry.
            </p>
          </div>

          {canManage && (
            <button
              type="button"
              onClick={() => setShowAlertModal(true)}
              className="bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 self-start md:self-auto"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Broadcast Transit Alert</span>
            </button>
          )}
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('routes')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors ${
              activeTab === 'routes' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Bus Routes & Stops ({routes.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('schedules')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors ${
              activeTab === 'schedules' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Live GPS Telematics vs Timetables ({schedules.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('alerts')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors ${
              activeTab === 'alerts' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Transit Alerts & Diversions ({alerts.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('map')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors ${
              activeTab === 'map' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Interactive Transit Map
          </button>
        </div>
      </div>

      {/* Transit Timing Route Search Engine */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
        <h3 className="font-bold text-slate-900 text-sm mb-1 flex items-center gap-2">
          <Navigation className="w-4 h-4 text-sky-600" />
          Find My Bus & Estimated Timings
        </h3>
        <p className="text-xs text-slate-500 mb-4">Enter your departure bus stop and destination stop to look up synchronized corridors</p>

        <form onSubmit={handleFindBus} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative">
            <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={sourceStop}
              onChange={e => setSourceStop(e.target.value)}
              placeholder="Origin stop (e.g. Secunderabad, Charminar...)"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div className="relative">
            <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={destStop}
              onChange={e => setDestStop(e.target.value)}
              placeholder="Destination (e.g. Cyber Towers, Hospital...)"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div className="flex gap-2">
            <button
              type="submit"
              className="flex-1 bg-sky-600 hover:bg-sky-700 text-white font-bold rounded-xl text-xs py-2.5 shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Search className="w-4 h-4" />
              <span>Search Bus Timings</span>
            </button>
            {timingResults && (
              <button
                type="button"
                onClick={() => {
                  setSourceStop('');
                  setDestStop('');
                  setTimingResults(null);
                }}
                className="px-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold rounded-xl text-xs"
              >
                Reset
              </button>
            )}
          </div>
        </form>

        {timingResults && (
          <div className="mt-4 p-4 rounded-xl bg-sky-50 border border-sky-200 text-xs animate-in fade-in">
            <h4 className="font-bold text-sky-900 mb-2">Search Results: Found {timingResults.length} matching bus route(s)</h4>
            {timingResults.length === 0 ? (
              <p className="text-slate-600">No direct bus route between these two stops. Consider changing at Paradise Metro or Koti.</p>
            ) : (
              <div className="space-y-2">
                {timingResults.map(r => (
                  <div key={r.id} className="p-3 bg-white rounded-lg border border-sky-100 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-slate-900 text-sm">Route {r.routeNumber}</span> - {r.name}
                      <div className="text-[11px] text-slate-500 mt-0.5">Every {r.frequencyMinutes} min • Fare: ₹{r.fareMin}-₹{r.fareMax}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setSearchRoute(r.routeNumber);
                        setActiveTab('routes');
                      }}
                      className="px-3 py-1 bg-sky-600 text-white rounded-md font-semibold text-[11px]"
                    >
                      View Route
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* TAB 1: BUS ROUTES */}
      {activeTab === 'routes' && (
        <div className="space-y-6">
          {/* View Mode & Map Overlay Controls */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm flex items-center gap-2">
                <MapIcon className="w-4 h-4 text-sky-600" />
                Transit Corridors & Visual Path Engine
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Explore real-world bus route polylines and stop sequences on Leaflet OpenStreetMap
              </p>
            </div>

            {/* View Mode Toggle Buttons */}
            <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => setRouteViewMode('both')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  routeViewMode === 'both'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Map + Cards</span>
              </button>

              <button
                type="button"
                onClick={() => setRouteViewMode('map')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  routeViewMode === 'map'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <MapIcon className="w-3.5 h-3.5" />
                <span>Map Only</span>
              </button>

              <button
                type="button"
                onClick={() => setRouteViewMode('cards')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  routeViewMode === 'cards'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>Cards Only</span>
              </button>
            </div>
          </div>

          {/* Leaflet Visual Map Overlay */}
          {routeViewMode !== 'cards' && (
            <div id="bus-route-map-overlay" className="animate-in fade-in zoom-in-98 duration-200">
              <BusRouteLeafletMap 
                routes={routes} 
                initialRouteId={selectedRouteForMap}
              />
            </div>
          )}

          {/* Bus Route Cards Grid */}
          {routeViewMode !== 'map' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {routes.map(route => {
                const isSelectedOnMap = route.id === selectedRouteForMap;
                return (
                  <div 
                    key={route.id} 
                    className={`bg-white dark:bg-slate-900 rounded-2xl p-5 border shadow-xs flex flex-col justify-between space-y-4 transition-all ${
                      isSelectedOnMap 
                        ? 'border-sky-500 ring-2 ring-sky-500/20 dark:ring-sky-500/40' 
                        : 'border-slate-200 dark:border-slate-800 hover:border-sky-400'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-black px-2.5 py-1 rounded-lg bg-sky-100 text-sky-900 dark:bg-sky-950 dark:text-sky-300 border border-sky-200 dark:border-sky-800">
                          Route {route.routeNumber}
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 flex items-center gap-1">
                          <Zap className="w-3 h-3 text-emerald-600 dark:text-emerald-400" /> {route.type}
                        </span>
                      </div>

                      <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">{route.name}</h3>
                      <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        {route.source} ➔ {route.destination}
                      </div>

                      <div className="grid grid-cols-3 gap-2 mt-4 bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-100 dark:border-slate-700/60 text-center text-xs">
                        <div>
                          <span className="text-[10px] text-slate-400 block">Frequency</span>
                          <span className="font-bold text-slate-800 dark:text-slate-200">{route.frequencyMinutes}m</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block">Trip Time</span>
                          <span className="font-bold text-slate-800 dark:text-slate-200">{route.travelTimeMinutes}m</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block">Fare</span>
                          <span className="font-bold text-slate-800 dark:text-slate-200">₹{route.fareMin}-{route.fareMax}</span>
                        </div>
                      </div>

                      {/* Stops Sequence */}
                      <div className="mt-4">
                        <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                          Stops Sequence ({route.stops.length} designated stations):
                        </span>
                        <div className="flex flex-wrap items-center gap-1 text-[11px] text-slate-600 dark:text-slate-300">
                          {route.stops.map((stop, sIdx) => (
                            <React.Fragment key={stop.id}>
                              <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-slate-800 dark:text-slate-200 font-medium">
                                {stop.order}. {stop.name}
                              </span>
                              {sIdx < route.stops.length - 1 && <span className="text-slate-400">➔</span>}
                            </React.Fragment>
                          ))}
                        </div>
                      </div>

                      <div className="mt-3 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                        <span>First Bus: <strong>{route.firstBus}</strong></span>
                        <span>Last Bus: <strong>{route.lastBus}</strong></span>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedRouteForMap(route.id);
                          if (routeViewMode === 'cards') {
                            setRouteViewMode('both');
                          }
                          setTimeout(() => {
                            document.getElementById('bus-route-map-overlay')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                          }, 50);
                        }}
                        className={`text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                          isSelectedOnMap
                            ? 'bg-sky-600 text-white shadow-xs'
                            : 'bg-sky-50 dark:bg-sky-950/70 text-sky-700 dark:text-sky-300 hover:bg-sky-100 dark:hover:bg-sky-900 border border-sky-200 dark:border-sky-800'
                        }`}
                      >
                        <MapIcon className="w-3.5 h-3.5" />
                        <span>{isSelectedOnMap ? 'Active on Map' : 'View Path on Map'}</span>
                      </button>

                      <VerificationBadge verification={route.verification} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: LIVE GPS TELEMATICS VS SCHEDULED */}
      {activeTab === 'schedules' && (
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs text-amber-900 flex items-start gap-2">
            <Radio className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <strong>Information Freshness Protocol:</strong> This platform clearly differentiates between 
              <span className="font-bold text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded ml-1">🟢 Live GPS Tracking</span> 
              (connected to vehicle telematics units) and 
              <span className="font-bold text-slate-800 bg-slate-200 px-1.5 py-0.5 rounded ml-1">⚪ Published Timetables</span>. 
              Live statuses display estimated arrival times and delay minutes.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {schedules.map(sched => (
              <div key={sched.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between space-y-4 hover:border-sky-500 transition-all">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-black px-2.5 py-1 rounded bg-sky-100 text-sky-900">
                      Route {sched.routeNumber}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      sched.isLive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
                    }`}>
                      {sched.isLive ? '🟢 Live GPS Telematics' : '⚪ Scheduled Timetable'}
                    </span>
                  </div>

                  <h3 className="font-bold text-slate-900 text-sm">
                    {sched.source} ➔ {sched.destination}
                  </h3>
                  <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                    Vehicle: {sched.busRegistrationNumber}
                  </div>

                  <div className="mt-4 bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Current Station:</span>
                      <span className="font-bold text-slate-900">{sched.currentStop}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Next Approaching Stop:</span>
                      <span className="font-bold text-teal-700">{sched.nextStop}</span>
                    </div>
                    <div className="flex justify-between pt-1 border-t border-slate-200">
                      <span className="text-slate-500">Timetable Time:</span>
                      <span className="font-semibold text-slate-700">{sched.scheduledTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Live Estimated Arrival:</span>
                      <span className="font-bold text-emerald-700">{sched.estimatedTime}</span>
                    </div>
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-400">Delay Status:</span>
                      <span className={`font-bold ${sched.delayMinutes > 0 ? 'text-amber-700' : 'text-emerald-700'}`}>
                        {sched.delayMinutes > 0 ? `Delayed by ${sched.delayMinutes} mins` : 'On Schedule'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100">
                  <VerificationBadge verification={sched.verification} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: TRANSIT ALERTS & DIVERSIONS */}
      {activeTab === 'alerts' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {alerts.map(alert => (
              <div key={alert.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-rose-100 text-rose-800">
                      {alert.type} Notice
                    </span>
                    <span className="text-xs font-semibold text-slate-500">
                      Routes Impacted: <strong>{alert.routeNumber}</strong>
                    </span>
                  </div>

                  <h3 className="font-bold text-slate-900 text-base">{alert.title}</h3>
                  <p className="text-xs text-slate-700 mt-2 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                    {alert.message}
                  </p>

                  <div className="mt-3 text-xs text-slate-500 flex items-center justify-between">
                    <span>Effective From: <strong>{alert.effectiveFrom}</strong></span>
                    <span>Valid Until: <strong>{alert.effectiveUntil}</strong></span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100">
                  <VerificationBadge verification={alert.verification} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: INTERACTIVE MAP */}
      {activeTab === 'map' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 shadow-xs">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Navigation className="w-4 h-4 text-sky-600" />
              Transit Map Navigation Engine:
            </span>
            <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => setMapTabEngine('leaflet')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  mapTabEngine === 'leaflet'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                🚌 Leaflet Transit Route Overlay
              </button>
              <button
                type="button"
                onClick={() => setMapTabEngine('gmp')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  mapTabEngine === 'gmp'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                🌐 Google Maps Platform
              </button>
            </div>
          </div>

          {mapTabEngine === 'leaflet' ? (
            <BusRouteLeafletMap routes={routes} initialRouteId={selectedRouteForMap} />
          ) : (
            <InteractiveCityMap hospitals={hospitals} routes={routes} selectedCategory="buses" />
          )}
        </div>
      )}

      {/* Add Alert Modal */}
      {showAlertModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-bold text-slate-900 text-base">Broadcast Transit Operational Alert</h3>
              <button
                type="button"
                onClick={() => setShowAlertModal(false)}
                className="text-slate-400 hover:text-slate-700 text-lg leading-none p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateAlert} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Alert Headline</label>
                <input
                  type="text"
                  required
                  value={newAlertData.title}
                  onChange={e => setNewAlertData({ ...newAlertData, title: e.target.value })}
                  placeholder="e.g. Route 100E: Minor Diversion at Panjagutta Flyover"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Impacted Route Number</label>
                  <input
                    type="text"
                    value={newAlertData.routeNumber}
                    onChange={e => setNewAlertData({ ...newAlertData, routeNumber: e.target.value })}
                    placeholder="100E / 5K"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Alert Type</label>
                  <select
                    value={newAlertData.type}
                    onChange={e => setNewAlertData({ ...newAlertData, type: e.target.value as any })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                  >
                    <option value="Delay">Delay</option>
                    <option value="Route Change">Route Change / Diversion</option>
                    <option value="Cancellation">Cancellation</option>
                    <option value="Maintenance">Maintenance</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Detailed Public Advisory Message</label>
                <textarea
                  rows={3}
                  required
                  value={newAlertData.message}
                  onChange={e => setNewAlertData({ ...newAlertData, message: e.target.value })}
                  placeholder="Describe roadwork, detour, and estimated delay for commuters..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAlertModal(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-lg font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-600 text-white rounded-lg font-semibold hover:bg-sky-700 shadow-xs"
                >
                  Publish Verified Transit Alert
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
