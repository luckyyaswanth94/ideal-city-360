import React, { useState } from 'react';
import { 
  Hospital, 
  DoctorVisit, 
  HospitalVacancy, 
  BusRoute, 
  BusSchedule, 
  GovernmentRule, 
  Announcement, 
  CityWellBeingMetric 
} from '../types';
import { VerificationBadge } from '../components/VerificationBadge';
import { InteractiveCityMap } from '../components/InteractiveCityMap';
import { WellBeingChart } from '../components/WellBeingChart';
import { Language, TRANSLATIONS } from '../utils/translations';
import { 
  Search, 
  HeartPulse, 
  Bus, 
  FileText, 
  Briefcase, 
  GraduationCap, 
  Users, 
  BarChart3, 
  Sparkles, 
  Calendar, 
  Clock, 
  ChevronRight, 
  CheckCircle2, 
  ArrowRight,
  MapPin,
  Bot,
  ExternalLink,
  ShieldCheck,
  Siren
} from 'lucide-react';

interface Props {
  hospitals: Hospital[];
  doctorVisits: DoctorVisit[];
  vacancies: HospitalVacancy[];
  busRoutes: BusRoute[];
  busSchedules: BusSchedule[];
  governmentRules: GovernmentRule[];
  announcements: Announcement[];
  wellbeingMetrics: CityWellBeingMetric[];
  setActiveTab: (tab: string) => void;
  onOpenAiAssistant: (q?: string) => void;
  onBookToken: (visitId: string) => void;
  language: Language;
}

export const HomePage: React.FC<Props> = ({
  hospitals,
  doctorVisits,
  vacancies,
  busRoutes,
  busSchedules,
  governmentRules,
  announcements,
  wellbeingMetrics,
  setActiveTab,
  onOpenAiAssistant,
  onBookToken,
  language
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const t = TRANSLATIONS[language];

  const quickAccessCategories = [
    { id: 'healthcare', title: 'Smart Healthcare', desc: 'Hospitals, Doctors, Blood Bank, Specialists & Vacancies', icon: HeartPulse, color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
    { id: 'transport', title: 'Smart Transport', desc: 'Electric AC Buses, Live GPS Tracking, Schedules & Alerts', icon: Bus, color: 'bg-sky-50 text-sky-700 border-sky-200' },
    { id: 'government', title: 'Government Rules', desc: 'Schemes, Subsidies, Certificates & AI Document Guides', icon: FileText, color: 'bg-indigo-50 text-indigo-700 border-indigo-200' },
    { id: 'employment', title: 'Jobs & Careers', desc: 'Govt & Private Recruitment, Internships & Scholarships', icon: Briefcase, color: 'bg-amber-50 text-amber-700 border-amber-200' },
    { id: 'education', title: 'Education & Skills', desc: 'Colleges, Digital Libraries & Tech Bootcamps', icon: GraduationCap, color: 'bg-rose-50 text-rose-700 border-rose-200' },
    { id: 'socialWelfare', title: 'Social Welfare', desc: 'Senior Citizen Care, Women Safety & Helplines', icon: Users, color: 'bg-teal-50 text-teal-700 border-teal-200' },
    { id: 'wellbeing', title: 'City Well-Being', desc: '88% Composite Quality of Life Index & Analytics', icon: BarChart3, color: 'bg-purple-50 text-purple-700 border-purple-200' },
    { id: 'accidentAlert', title: 'Smart Accident Alert', desc: 'Anonymous Reporting, AI Triage, Encrypted Photo & 108 Dispatch', icon: Siren, color: 'bg-red-50 text-red-700 border-red-200' }
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    onOpenAiAssistant(searchQuery);
  };

  return (
    <div className="space-y-10 pb-12 w-full">
      
      {/* 1. HERO SECTION */}
      <section className="relative bg-gradient-to-br from-slate-950 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-10 lg:p-12 shadow-xl overflow-hidden border border-slate-800">
        <div className="absolute right-0 top-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute left-1/3 bottom-0 w-72 h-72 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-teal-300 shrink-0" />
              <span>Official Smart Citizen Information Platform</span>
            </div>
            <button
              type="button"
              data-testid="hero-report-accident-btn"
              onClick={() => setActiveTab('accidentAlert')}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold tracking-wide shadow-md transition-colors cursor-pointer"
            >
              <Siren className="w-4 h-4 shrink-0" />
              <span>REPORT ACCIDENT ANONYMOUSLY</span>
            </button>
          </div>

          <h1 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {t.heroTitle}
          </h1>

          <p className="text-slate-300 text-xs sm:text-sm lg:text-base leading-relaxed">
            {t.heroSubtitle}
          </p>

          {/* Search Bar (responsive for small screens to desktop) */}
          <form onSubmit={handleSearchSubmit} className="pt-2">
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-1.5 sm:p-2 shadow-2xl flex flex-col sm:flex-row items-stretch sm:items-center gap-2 border-2 border-teal-500/40 focus-within:border-teal-500">
              <div className="flex items-center gap-2 flex-1 px-2 py-1">
                <Search className="w-5 h-5 text-slate-400 shrink-0" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder={t.searchPlaceholder}
                  className="w-full text-slate-800 dark:text-slate-100 text-xs sm:text-sm placeholder-slate-400 dark:placeholder-slate-500 focus:outline-hidden bg-transparent"
                />
              </div>
              <button
                type="submit"
                className="bg-teal-600 hover:bg-teal-700 text-white text-xs sm:text-sm font-bold px-4 sm:px-6 py-2.5 rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shrink-0"
              >
                <Bot className="w-4 h-4" />
                <span>Search City</span>
              </button>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-3 text-xs text-slate-400">
              <span className="font-semibold text-slate-300">Popular Queries:</span>
              <button type="button" onClick={() => onOpenAiAssistant('When will the cardiologist visit?')} className="hover:text-teal-300 underline cursor-pointer">Cardiologist Visit</button>
              <span>•</span>
              <button type="button" onClick={() => onOpenAiAssistant('Which hospitals have nurse vacancies?')} className="hover:text-teal-300 underline cursor-pointer">Nurse Vacancies</button>
              <span>•</span>
              <button type="button" onClick={() => onOpenAiAssistant('When is the next bus on Route 100E?')} className="hover:text-teal-300 underline cursor-pointer">Route 100E Bus</button>
              <span>•</span>
              <button type="button" onClick={() => onOpenAiAssistant('What documents are needed for a birth certificate?')} className="hover:text-teal-300 underline cursor-pointer">Birth Certificate</button>
              <span>•</span>
              <button type="button" onClick={() => onOpenAiAssistant('Which government schemes am I eligible to explore?')} className="hover:text-teal-300 underline cursor-pointer">Aarogyasri Scheme</button>
            </div>
          </form>
        </div>

        {/* Hero Quick Stat Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8 pt-8 border-t border-slate-800 text-xs relative z-10">
          <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[11px]">Monitored Hospitals</span>
            <span className="text-base sm:text-lg font-bold text-white">{hospitals.length} Super-Specialty</span>
          </div>
          <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[11px]">Live Electric Transit</span>
            <span className="text-base sm:text-lg font-bold text-white">{busRoutes.length} City Corridors</span>
          </div>
          <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[11px]">Citizen Trust Rating</span>
            <span className="text-base sm:text-lg font-bold text-emerald-400">99.4% Verified Data</span>
          </div>
          <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[11px]">City Well-Being Index</span>
            <span className="text-base sm:text-lg font-bold text-teal-400">88% (Grade A)</span>
          </div>
        </div>
      </section>

      {/* 2. QUICK ACCESS CARDS */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">Essential City Portals & Services</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Instant access to verified public information categories</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickAccessCategories.map(cat => {
            const Icon = cat.icon;
            return (
              <div
                key={cat.id}
                onClick={() => setActiveTab(cat.id)}
                className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs hover:shadow-md hover:border-teal-500 dark:hover:border-teal-500 transition-all cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 border ${cat.color} dark:bg-slate-800 dark:border-slate-700`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                    {cat.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                    {cat.desc}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-teal-700 dark:text-teal-400 group-hover:translate-x-1 transition-transform">
                  <span>Explore Portal</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. LATEST VERIFIED ANNOUNCEMENTS */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping shrink-0" />
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">Latest Verified Public Announcements</h2>
          </div>
          <span className="text-xs text-slate-400 dark:text-slate-500 font-medium">Updated Continuous Live Feed</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {announcements.slice(0, 3).map(ann => (
            <div key={ann.id} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1.5 gap-2">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                    ann.isUrgent ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300' : 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300'
                  }`}>
                    {ann.category} Alert
                  </span>
                  <span className="text-[11px] text-slate-400 dark:text-slate-500">{new Date(ann.publishedAt).toLocaleDateString()}</span>
                </div>
                <h3 className="font-bold text-slate-900 dark:text-white text-xs sm:text-sm line-clamp-2">{ann.title}</h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 line-clamp-3">{ann.summary}</p>
              </div>

              <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700">
                <VerificationBadge verification={ann.verification} showDetails={false} />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. UPCOMING SPECIALIST DOCTOR VISITS */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>Upcoming Specialist Doctor Visits</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Consultation schedules, chamber details, and token booking links</p>
          </div>
          <button
            type="button"
            onClick={() => setActiveTab('healthcare')}
            className="text-xs font-semibold text-teal-700 dark:text-teal-400 hover:text-teal-900 dark:hover:text-teal-300 flex items-center gap-1 cursor-pointer self-start sm:self-auto"
          >
            <span>All Visiting Schedules</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {doctorVisits.slice(0, 3).map(visit => (
            <div key={visit.id} className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between hover:border-emerald-500 dark:hover:border-emerald-500 transition-all">
              <div>
                <div className="flex items-center justify-between mb-2 gap-2">
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 truncate">
                    {visit.specialization}
                  </span>
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 shrink-0">
                    Tokens: <strong className="text-slate-900 dark:text-white">{visit.bookedTokens}/{visit.tokenCapacity}</strong>
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 dark:text-white text-sm">{visit.doctorName}</h3>
                <div className="text-xs text-teal-700 dark:text-teal-400 font-medium mt-0.5 flex items-center gap-1 truncate">
                  <MapPin className="w-3.5 h-3.5 shrink-0" /> <span className="truncate">{visit.hospitalName}</span>
                </div>

                <div className="mt-3 bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-100 dark:border-slate-700 text-xs space-y-1">
                  <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                    <span>Date: <strong>{new Date(visit.visitDate).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}</strong></span>
                    <span>Room: <strong>{visit.roomNumber}</strong></span>
                  </div>
                  <div className="text-slate-500 dark:text-slate-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 shrink-0" /> <span>{visit.consultationHours}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <VerificationBadge verification={visit.verification} showDetails={false} />
                <button
                  type="button"
                  onClick={() => onBookToken(visit.id)}
                  disabled={visit.bookedTokens >= visit.tokenCapacity}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 dark:disabled:bg-slate-800 text-white text-xs font-bold py-2 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{visit.bookedTokens >= visit.tokenCapacity ? 'Slots Fully Booked' : 'Book Consultation Token'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. LATEST HOSPITAL JOB VACANCIES */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-teal-600 dark:text-teal-400 shrink-0" />
              <span>Latest Hospital Recruitment & Staff Openings</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Government and institutional healthcare positions with official gazette deadlines</p>
          </div>
          <button
            type="button"
            onClick={() => setActiveTab('employment')}
            className="text-xs font-semibold text-teal-700 dark:text-teal-400 hover:text-teal-900 dark:hover:text-teal-300 flex items-center gap-1 cursor-pointer self-start sm:self-auto"
          >
            <span>All Employment Opportunities</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {vacancies.slice(0, 3).map(vac => (
            <div key={vac.id} className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between hover:border-teal-500 dark:hover:border-teal-500 transition-all">
              <div>
                <div className="flex items-center justify-between mb-2 gap-2">
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950/70 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800 truncate">
                    {vac.roleType} • {vac.positions} Positions
                  </span>
                  <span className="text-xs font-semibold text-rose-600 dark:text-rose-400 shrink-0">
                    Deadline: {new Date(vac.deadline).toLocaleDateString()}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 dark:text-white text-sm leading-snug">{vac.title}</h3>
                <div className="text-xs text-slate-600 dark:text-slate-400 mt-1 font-medium">{vac.hospitalName}</div>

                <div className="mt-3 text-xs text-slate-600 dark:text-slate-300 space-y-1 bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-100 dark:border-slate-700">
                  <div className="line-clamp-2"><strong>Qualifications:</strong> {vac.qualifications}</div>
                  <div><strong>Salary Scale:</strong> <span className="text-emerald-700 dark:text-emerald-400 font-bold">{vac.salaryRange}</span></div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <VerificationBadge verification={vac.verification} showDetails={false} />
                <a
                  href={vac.applicationLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-bold py-2 rounded-xl transition-colors flex items-center justify-center gap-1 text-center"
                >
                  <span>Official Application Portal</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 6. IMPORTANT GOVERNMENT NOTIFICATIONS & SCHEMES */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0" />
              <span>Important Government Notifications & Public Schemes</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Searchable civic schemes, rules, subsidies, eligibility, and official documentation</p>
          </div>
          <button
            type="button"
            onClick={() => setActiveTab('government')}
            className="text-xs font-semibold text-indigo-700 dark:text-indigo-400 hover:text-indigo-900 dark:hover:text-indigo-300 flex items-center gap-1 cursor-pointer self-start sm:self-auto"
          >
            <span>All Schemes & Document Guides</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {governmentRules.slice(0, 3).map(rule => (
            <div key={rule.id} className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between hover:border-indigo-500 dark:hover:border-indigo-500 transition-all">
              <div>
                <div className="flex items-center justify-between mb-2 gap-2">
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/70 text-indigo-800 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 truncate">
                    {rule.department}
                  </span>
                  <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 shrink-0">
                    Fee: <strong className="text-emerald-600 dark:text-emerald-400">{rule.applicationFee}</strong>
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 dark:text-white text-sm leading-snug">{rule.title}</h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 line-clamp-3 leading-relaxed">
                  {rule.summary}
                </p>

                <div className="mt-3 text-xs bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-100 dark:border-slate-700 space-y-1">
                  <div className="text-slate-700 dark:text-slate-300">
                    <strong>Eligibility:</strong> <span className="line-clamp-1">{rule.eligibility[0] || 'Eligible citizens'}</span>
                  </div>
                  <div className="text-slate-500 dark:text-slate-400 text-[11px]">
                    Required: {rule.requiredDocuments.length} Verified Documents • Effective {new Date(rule.effectiveDate).toLocaleDateString()}
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <VerificationBadge verification={rule.verification} showDetails={false} />
                <button
                  type="button"
                  onClick={() => setActiveTab('government')}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-2 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <FileText className="w-4 h-4" />
                  <span>View Scheme Requirements</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 7. LATEST BUS SCHEDULE UPDATES */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Bus className="w-5 h-5 text-sky-600 dark:text-sky-400 shrink-0" />
              <span>Latest Smart Bus Schedules & Real-Time Telematics</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Live GPS tracking clearly distinguished from scheduled timetables</p>
          </div>
          <button
            type="button"
            onClick={() => setActiveTab('transport')}
            className="text-xs font-semibold text-sky-700 dark:text-sky-400 hover:text-sky-900 dark:hover:text-sky-300 flex items-center gap-1 cursor-pointer self-start sm:self-auto"
          >
            <span>Interactive Map & Full Timetables</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {busSchedules.slice(0, 3).map(sched => (
            <div key={sched.id} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center justify-between mb-2 gap-2">
                  <span className="text-xs font-bold px-2 py-0.5 rounded bg-sky-100 dark:bg-sky-950 text-sky-800 dark:text-sky-300 shrink-0">
                    Route {sched.routeNumber}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded shrink-0 ${
                    sched.isLive ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                  }`}>
                    {sched.isLive ? '🟢 Live GPS Tracking' : '⚪ Scheduled Timetable'}
                  </span>
                </div>

                <div className="font-bold text-slate-900 dark:text-white text-xs truncate">
                  {sched.source} ➔ {sched.destination}
                </div>

                <div className="mt-2 text-xs space-y-1">
                  <div className="text-slate-600 dark:text-slate-400 truncate">Current Stop: <strong className="text-slate-900 dark:text-slate-200">{sched.currentStop}</strong></div>
                  <div className="text-slate-600 dark:text-slate-400 truncate">Next Stop: <strong className="text-teal-700 dark:text-teal-400">{sched.nextStop}</strong></div>
                  <div className="flex items-center justify-between text-slate-700 dark:text-slate-300 pt-1">
                    <span>ETA: <strong className="text-emerald-700 dark:text-emerald-400">{sched.estimatedTime}</strong></span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">Status: {sched.status}</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700">
                <VerificationBadge verification={sched.verification} showDetails={false} />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 8. CITY WELL-BEING DASHBOARD */}
      <section className="space-y-4">
        <WellBeingChart metrics={wellbeingMetrics} />
      </section>

      {/* 9. CITY GEOSPATIAL INFRASTRUCTURE MAP PREVIEW */}
      <section className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <MapPin className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>City Geospatial Infrastructure</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Visual layout of verified hospitals, trauma care, and electric transit corridors</p>
          </div>
          <button
            type="button"
            onClick={() => setActiveTab('transport')}
            className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:text-emerald-900 dark:hover:text-emerald-300 flex items-center gap-1 cursor-pointer self-start sm:self-auto"
          >
            <span>Transit Map Overlays</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <InteractiveCityMap hospitals={hospitals} routes={busRoutes} />
      </section>

    </div>
  );
};
