import React, { useState } from 'react';
import type {
  AccidentOverallStatus,
  AccidentReport,
  AmbulanceUnit,
  Hospital,
  PoliceStation,
  User,
} from '../types';
import { canRoleAccessAuthorityDashboard } from '../utils/accidentEmergency';
import { AccidentReportFlow } from '../components/AccidentReportFlow';
import {
  AccidentTrackingView,
  type TrackedAccidentEntry,
} from '../components/AccidentTrackingView';
import { EmergencyAuthorityDashboard } from '../components/EmergencyAuthorityDashboard';
import { EyeOff, KeyRound, ShieldAlert } from 'lucide-react';

interface Props {
  currentUser: User;
  hospitals: Hospital[];
  policeStations: PoliceStation[];
  ambulanceUnits: AmbulanceUnit[];
  accidentReports: AccidentReport[];
  onSwitchUserRole: (role: string) => void;
  onAccidentSubmitted: (report: AccidentReport, trackingToken: string) => void;
  onRefreshAccidents: () => Promise<void>;
  onUpdateAccidentResponse: (
    reportId: string,
    payload: {
      agency: 'hospital' | 'ambulance' | 'police' | 'overall';
      status?: string;
      hospitalId?: string;
      etaMinutes?: number | null;
      bedsReserved?: number;
      notes?: string;
      overallStatus?: AccidentOverallStatus;
    }
  ) => Promise<void>;
}

export const AccidentEmergencyModule: React.FC<Props> = ({
  currentUser,
  hospitals,
  policeStations,
  ambulanceUnits,
  accidentReports,
  onSwitchUserRole,
  onAccidentSubmitted,
  onRefreshAccidents,
  onUpdateAccidentResponse,
}) => {
  const [subTab, setSubTab] = useState<'report' | 'track' | 'authority'>('report');
  const [trackedEntry, setTrackedEntry] = useState<TrackedAccidentEntry | null>(null);
  const [recentSubmissions, setRecentSubmissions] = useState<TrackedAccidentEntry[]>([]);
  const [justSubmittedCode, setJustSubmittedCode] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const isAuthority = canRoleAccessAuthorityDashboard(currentUser.role);
  const activeCount = accidentReports.filter((r) => r.overallStatus !== 'Resolved').length;

  const handleRefreshAuthority = async () => {
    if (!isAuthority) return;
    setIsRefreshing(true);
    try {
      await onRefreshAccidents();
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleLookupReport = async (
    incidentCode: string,
    trackingToken: string
  ): Promise<{ ok: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/accidents/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ incidentCode, trackingToken }),
      });
      const data = await res.json();
      if (!res.ok || !data.report) {
        return {
          ok: false,
          error: data.error || 'Invalid Accident Report ID or Secure Tracking Token.',
        };
      }

      const entry: TrackedAccidentEntry = {
        report: data.report,
        trackingToken: trackingToken.trim().toUpperCase(),
      };
      setTrackedEntry(entry);
      setRecentSubmissions((prev) => [
        entry,
        ...prev.filter((item) => item.report.incidentCode !== entry.report.incidentCode),
      ]);
      return { ok: true };
    } catch {
      return {
        ok: false,
        error: 'Unable to reach tracking endpoint right now. Please try again.',
      };
    }
  };

  const handleRefreshTracked = async () => {
    if (!trackedEntry) return;
    setIsRefreshing(true);
    try {
      await handleLookupReport(
        trackedEntry.report.incidentCode,
        trackedEntry.trackingToken
      );
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleReportSubmitted = (report: AccidentReport, trackingToken: string) => {
    const entry: TrackedAccidentEntry = { report, trackingToken };
    setTrackedEntry(entry);
    setJustSubmittedCode(report.incidentCode);
    setRecentSubmissions((prev) => [
      entry,
      ...prev.filter((item) => item.report.incidentCode !== report.incidentCode),
    ]);
    onAccidentSubmitted(report, trackingToken);
    setSubTab('track');
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="space-y-6" data-testid="accident-emergency-module">
      {/* Module Top Header & Clean Segmented Navigation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-wider text-red-600 dark:text-red-400">
            IDEAL CITY 360 · Privacy-First Emergency Dispatch (DPDP Act, 2023)
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Smart Accident Emergency Alert System
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            data-testid="accident-tab-report"
            onClick={() => setSubTab('report')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 border transition-colors cursor-pointer whitespace-nowrap ${
              subTab === 'report'
                ? 'bg-red-600 text-white border-red-600 shadow-xs'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-red-300'
            }`}
          >
            <EyeOff className="w-4 h-4" />
            <span>Report Anonymously</span>
          </button>

          <button
            type="button"
            data-testid="accident-tab-track"
            onClick={() => {
              setSubTab('track');
              if (trackedEntry) {
                handleRefreshTracked();
              }
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 border transition-colors cursor-pointer whitespace-nowrap ${
              subTab === 'track'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 border-slate-900 dark:border-white'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            <span>Track Anonymously</span>
          </button>

          <button
            type="button"
            data-testid="accident-tab-authority"
            onClick={() => {
              setSubTab('authority');
              if (isAuthority) {
                handleRefreshAuthority();
              }
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 border transition-colors cursor-pointer whitespace-nowrap ${
              subTab === 'authority'
                ? 'bg-teal-700 text-white border-teal-700'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-teal-400'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>
              Authority Dashboard{isAuthority ? ` (${activeCount} Active)` : ' (Restricted)'}
            </span>
          </button>
        </div>
      </div>

      {subTab === 'report' && (
        <AccidentReportFlow
          hospitals={hospitals}
          onReportSubmitted={handleReportSubmitted}
        />
      )}

      {subTab === 'track' && (
        <AccidentTrackingView
          trackedEntry={trackedEntry}
          recentSubmissions={recentSubmissions}
          justSubmittedCode={justSubmittedCode}
          onLookupReport={handleLookupReport}
          onSelectRecent={(entry) => setTrackedEntry(entry)}
          onRefreshTracked={handleRefreshTracked}
          onNewReport={() => setSubTab('report')}
          isRefreshing={isRefreshing}
        />
      )}

      {subTab === 'authority' && (
        <EmergencyAuthorityDashboard
          currentUser={currentUser}
          reports={accidentReports}
          hospitals={hospitals}
          policeStations={policeStations}
          ambulanceUnits={ambulanceUnits}
          onSwitchUserRole={onSwitchUserRole}
          onRefresh={handleRefreshAuthority}
          onUpdateResponse={onUpdateAccidentResponse}
          isRefreshing={isRefreshing}
        />
      )}
    </div>
  );
};
