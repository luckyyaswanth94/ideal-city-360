import React, { useState } from 'react';
import { User, Complaint, Hospital, DoctorVisit, HospitalVacancy, BusRoute, GovernmentRule } from '../types';
import { 
  ShieldAlert, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  FileText, 
  Users, 
  Activity, 
  Search, 
  History, 
  MessageSquare,
  Sparkles,
  ChevronRight,
  Filter
} from 'lucide-react';

interface AuditLog {
  id: string;
  timestamp: string;
  entityType: string;
  entityId: string;
  action: string;
  adminEmail: string;
  previousStatus?: string;
  newStatus?: string;
  notes?: string;
}

interface Props {
  currentUser: User;
  complaints: Complaint[];
  hospitals: Hospital[];
  visits: DoctorVisit[];
  vacancies: HospitalVacancy[];
  routes: BusRoute[];
  rules: GovernmentRule[];
  auditLogs: AuditLog[];
  onUpdateComplaintStatus: (complaintId: string, status: Complaint['status'], adminNotes: string) => void;
  onVerifyRecord: (entityType: string, entityId: string, newStatus: string, notes: string) => void;
}

export const AdminPortal: React.FC<Props> = ({
  currentUser,
  complaints,
  hospitals,
  visits,
  vacancies,
  routes,
  rules,
  auditLogs,
  onUpdateComplaintStatus,
  onVerifyRecord
}) => {
  const [activeTab, setActiveTab] = useState<'verification' | 'complaints' | 'audit'>('verification');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  
  // Verification action modal state
  const [actionModal, setActionModal] = useState<{
    isOpen: boolean;
    entityType: string;
    entityId: string;
    entityTitle: string;
    targetStatus: 'Verified' | 'Rejected' | 'Expired';
    notes: string;
  }>({
    isOpen: false,
    entityType: '',
    entityId: '',
    entityTitle: '',
    targetStatus: 'Verified',
    notes: ''
  });

  // Complaint edit state
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [complaintStatusInput, setComplaintStatusInput] = useState<Complaint['status']>('In Review');
  const [complaintNotesInput, setComplaintNotesInput] = useState('');

  // Collect all verifiable items into unified list
  const verifiableRecords = [
    ...hospitals.map(h => ({ id: h.id, type: 'hospital', title: h.name, category: 'Healthcare Hospital', meta: h.verification })),
    ...visits.map(v => ({ id: v.id, type: 'doctorVisit', title: `${v.doctorName} (${v.specialization})`, category: 'Specialist Visit', meta: v.verification })),
    ...vacancies.map(vac => ({ id: vac.id, type: 'vacancy', title: vac.title, category: 'Hospital Recruitment', meta: vac.verification })),
    ...routes.map(r => ({ id: r.id, type: 'route', title: `Route ${r.routeNumber}: ${r.name}`, category: 'Transit Corridor', meta: r.verification })),
    ...rules.map(ru => ({ id: ru.id, type: 'rule', title: ru.title, category: 'Government Scheme', meta: ru.verification }))
  ];

  const filteredVerifiable = verifiableRecords.filter(r => {
    if (filterStatus === 'all') return true;
    return r.meta.verificationStatus === filterStatus;
  });

  const handleOpenActionModal = (entityType: string, entityId: string, title: string, status: 'Verified' | 'Rejected' | 'Expired') => {
    setActionModal({
      isOpen: true,
      entityType,
      entityId,
      entityTitle: title,
      targetStatus: status,
      notes: ''
    });
  };

  const handleConfirmAction = (e: React.FormEvent) => {
    e.preventDefault();
    onVerifyRecord(
      actionModal.entityType,
      actionModal.entityId,
      actionModal.targetStatus,
      actionModal.notes || `Audited by ${currentUser.name}`
    );
    setActionModal({ ...actionModal, isOpen: false });
  };

  const handleSaveComplaint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedComplaint) return;
    onUpdateComplaintStatus(selectedComplaint.id, complaintStatusInput, complaintNotesInput);
    setSelectedComplaint(null);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-navy-950 text-white rounded-3xl p-6 sm:p-8 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5" /> Administration & Verification Hub
              </span>
              <span className="text-xs text-slate-400 capitalize">Role Scope: {currentUser.role.replace('_', ' ')}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Information Freshness & Society Command
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
              Strict multi-tier verification workflows, official source audit logs, citizen grievance dispatch, and tamper-resistant update records.
            </p>
          </div>

          <div className="bg-white/10 p-4 rounded-2xl border border-white/20 text-xs space-y-1">
            <div>Authorized Administrator: <strong className="text-white">{currentUser.name}</strong></div>
            <div>Designation: <strong className="text-purple-300 capitalize">{currentUser.role.replace('_', ' ')}</strong></div>
            <div>Audit Queue: <strong className="text-emerald-400">{verifiableRecords.length} Monitored Items</strong></div>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('verification')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors ${
              activeTab === 'verification' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Information Verification Queue ({verifiableRecords.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('complaints')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors ${
              activeTab === 'complaints' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Citizen Grievance Redressal ({complaints.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('audit')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors ${
              activeTab === 'audit' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Tamper-Resistant Audit Trail ({auditLogs.length})
          </button>
        </div>
      </div>

      {/* TAB 1: VERIFICATION QUEUE */}
      {activeTab === 'verification' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Information Verification & Expiration Registry</h2>
              <p className="text-xs text-slate-500">Every published record requires a verified source, verifier officer, and validity window</p>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 font-semibold">Filter:</span>
              <select
                value={filterStatus}
                onChange={e => setFilterStatus(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-slate-800 font-medium"
              >
                <option value="all">All Verification Statuses</option>
                <option value="Verified">Verified</option>
                <option value="Pending">Pending Audit</option>
                <option value="Expired">Expired</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="p-3">Record Title & Category</th>
                  <th className="p-3">Source & Verification URL</th>
                  <th className="p-3">Last Updated / Officer</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Administrative Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredVerifiable.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50">
                    <td className="p-3 font-semibold text-slate-900">
                      <div>{item.title}</div>
                      <span className="text-[10px] text-teal-700 font-medium">{item.category}</span>
                    </td>
                    <td className="p-3">
                      <div className="truncate max-w-[200px]" title={item.meta.sourceName}>{item.meta.sourceName}</div>
                      <a href={item.meta.sourceUrl} target="_blank" rel="noopener noreferrer" className="text-[10px] text-indigo-600 underline">
                        Verify Reference
                      </a>
                    </td>
                    <td className="p-3 text-[11px] text-slate-500">
                      <div>{new Date(item.meta.lastUpdated).toLocaleDateString()}</div>
                      <div className="text-[10px] text-slate-400">{item.meta.verifiedBy || 'Not verified'}</div>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        item.meta.verificationStatus === 'Verified' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
                        item.meta.verificationStatus === 'Pending' ? 'bg-amber-50 text-amber-800 border border-amber-200' :
                        item.meta.verificationStatus === 'Expired' ? 'bg-slate-100 text-slate-700 border border-slate-300' :
                        'bg-rose-50 text-rose-800 border border-rose-200'
                      }`}>
                        {item.meta.verificationStatus}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleOpenActionModal(item.type, item.id, item.title, 'Verified')}
                          className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded font-semibold text-[11px]"
                          title="Verify Record"
                        >
                          Verify
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenActionModal(item.type, item.id, item.title, 'Expired')}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded font-semibold text-[11px]"
                          title="Mark as Expired"
                        >
                          Expire
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenActionModal(item.type, item.id, item.title, 'Rejected')}
                          className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 rounded font-semibold text-[11px]"
                          title="Reject Record"
                        >
                          Reject
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: COMPLAINT RESOLUTION */}
      {activeTab === 'complaints' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Citizen Grievance Redressal Dispatch</h2>
              <p className="text-xs text-slate-500">Review reported municipal issues, update status, and communicate resolution progress</p>
            </div>
            <span className="text-xs font-bold text-purple-800 bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
              {complaints.length} Total Registered
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {complaints.map(cmp => (
              <div key={cmp.id} className="py-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[11px] font-bold bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                      #{cmp.ticketNumber}
                    </span>
                    <span className="text-[10px] font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded">
                      {cmp.category}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      cmp.status === 'Resolved' ? 'bg-emerald-100 text-emerald-800' :
                      cmp.status === 'In Progress' ? 'bg-sky-100 text-sky-800' :
                      cmp.status === 'In Review' ? 'bg-amber-100 text-amber-800' :
                      'bg-slate-100 text-slate-800'
                    }`}>
                      {cmp.status}
                    </span>
                  </div>

                  <h3 className="font-bold text-slate-900 text-sm">{cmp.title}</h3>
                  <p className="text-xs text-slate-600 line-clamp-2">{cmp.description}</p>
                  
                  <div className="text-[11px] text-slate-400">
                    Citizen: <strong>{cmp.citizenName}</strong> ({cmp.citizenEmail}) • {cmp.location}
                  </div>

                  {cmp.adminNotes && (
                    <div className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded border border-slate-100">
                      <strong>Current Admin Note:</strong> {cmp.adminNotes}
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setSelectedComplaint(cmp);
                    setComplaintStatusInput(cmp.status);
                    setComplaintNotesInput(cmp.adminNotes || '');
                  }}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0"
                >
                  Manage & Resolve Ticket
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: AUDIT TRAIL LOGS */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <History className="w-5 h-5 text-purple-600" />
                Information Verification Audit Trail
              </h2>
              <p className="text-xs text-slate-500">Immutable chronological log of all verification status updates and authority actions</p>
            </div>
            <span className="text-xs text-slate-400 font-mono">Total Log Entries: {auditLogs.length}</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-50 text-slate-500 uppercase text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="p-3">Timestamp</th>
                  <th className="p-3">Entity & Target ID</th>
                  <th className="p-3">Action Performed</th>
                  <th className="p-3">Administrator</th>
                  <th className="p-3">Transition</th>
                  <th className="p-3">Audit Reason / Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {auditLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/50">
                    <td className="p-3 text-[11px] text-slate-500 font-mono">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="p-3 font-semibold text-slate-900">
                      <div>{log.entityType}</div>
                      <span className="text-[10px] text-slate-400 font-mono">{log.entityId}</span>
                    </td>
                    <td className="p-3 font-bold text-teal-800">{log.action}</td>
                    <td className="p-3 text-slate-600">{log.adminEmail}</td>
                    <td className="p-3 text-[11px]">
                      <span className="text-slate-400">{log.previousStatus || 'Initial'}</span>
                      <span className="mx-1 font-bold text-slate-600">➔</span>
                      <span className="font-bold text-emerald-700">{log.newStatus}</span>
                    </td>
                    <td className="p-3 text-[11px] text-slate-600 max-w-xs">{log.notes || 'Routine audit'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Verification Status Action Modal */}
      {actionModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-bold text-slate-900 text-base">
                Set Verification Status: {actionModal.targetStatus}
              </h3>
              <button
                type="button"
                onClick={() => setActionModal({ ...actionModal, isOpen: false })}
                className="text-slate-400 hover:text-slate-700 text-lg leading-none p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmAction} className="mt-4 space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[11px] text-slate-400 block font-medium">Record Title:</span>
                <span className="font-bold text-slate-900 block">{actionModal.entityTitle}</span>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Audit Findings & Verification Notes (Mandatory for Compliance)
                </label>
                <textarea
                  rows={3}
                  required
                  value={actionModal.notes}
                  onChange={e => setActionModal({ ...actionModal, notes: e.target.value })}
                  placeholder="e.g. Cross-checked with official directorate registry, inspected bed capacity, validated gazette link..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActionModal({ ...actionModal, isOpen: false })}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-lg font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 text-white rounded-lg font-bold shadow-xs ${
                    actionModal.targetStatus === 'Verified' ? 'bg-emerald-600 hover:bg-emerald-700' :
                    actionModal.targetStatus === 'Expired' ? 'bg-slate-800 hover:bg-slate-900' :
                    'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  Confirm & Commit to Audit Trail
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Complaint Update Modal */}
      {selectedComplaint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-bold text-slate-900 text-base">
                Update Grievance: #{selectedComplaint.ticketNumber}
              </h3>
              <button
                type="button"
                onClick={() => setSelectedComplaint(null)}
                className="text-slate-400 hover:text-slate-700 text-lg leading-none p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveComplaint} className="mt-4 space-y-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <div className="font-bold text-slate-900">{selectedComplaint.title}</div>
                <div className="text-slate-600">{selectedComplaint.description}</div>
                <div className="text-slate-400">Location: {selectedComplaint.location}</div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Redressal Status</label>
                <select
                  value={complaintStatusInput}
                  onChange={e => setComplaintStatusInput(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 font-semibold"
                >
                  <option value="Submitted">Submitted (Queued for Inspection)</option>
                  <option value="In Review">In Review (Officer Assigned)</option>
                  <option value="In Progress">In Progress (Field Work Underway)</option>
                  <option value="Resolved">Resolved (Rectification Complete)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Official Redressal Notes (Visible to Citizen)
                </label>
                <textarea
                  rows={3}
                  required
                  value={complaintNotesInput}
                  onChange={e => setComplaintNotesInput(e.target.value)}
                  placeholder="e.g. Electrical team dispatched; new LED lamp installed and tested on Nov 12..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedComplaint(null)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-lg font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 text-white rounded-lg font-bold hover:bg-purple-700 shadow-xs"
                >
                  Save Status & Notify Citizen
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
