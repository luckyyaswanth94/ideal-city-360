import React, { useState } from 'react';
import { EducationService } from '../types';
import { VerificationBadge } from '../components/VerificationBadge';
import { GraduationCap, BookOpen, ExternalLink, Mail, Award, Sparkles } from 'lucide-react';

interface Props {
  services: EducationService[];
}

export const EducationModule: React.FC<Props> = ({ services }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filtered = services.filter(s => {
    return selectedCategory === 'all' || s.category === selectedCategory;
  });

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-rose-950 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-8 shadow-md">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1">
              <GraduationCap className="w-3.5 h-3.5" /> Education & Student Services
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
            Colleges, Digital Libraries & Skill Academies
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
            Access free public digital libraries, city AI literacy bootcamps, student career guidance centers, and merit scholarship portals.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-slate-800 text-xs">
          {['all', 'Skill Programme', 'Online Resource', 'Scholarship', 'College & University'].map(cat => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors ${
                selectedCategory === cat ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
              }`}
            >
              {cat === 'all' ? 'All Learning Opportunities' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filtered.map(item => (
          <div key={item.id} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between space-y-4 hover:border-rose-300 transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-800 border border-rose-200">
                  {item.category}
                </span>
                {item.deadline && (
                  <span className="text-xs font-semibold text-rose-600">
                    Apply by: {item.deadline}
                  </span>
                )}
              </div>

              <h3 className="font-bold text-slate-900 text-base leading-snug">{item.title}</h3>
              <div className="text-xs text-teal-700 font-medium mt-1">{item.institution}</div>

              <p className="text-xs text-slate-600 mt-3 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                {item.description}
              </p>

              <div className="mt-3 text-xs text-slate-600 space-y-1">
                <div><strong>Eligibility:</strong> {item.eligibility}</div>
                {item.contactEmail && <div><strong>Contact:</strong> {item.contactEmail}</div>}
              </div>
            </div>

            <div className="space-y-3 pt-3 border-t border-slate-100">
              <VerificationBadge verification={item.verification} />
              <a
                href={item.applicationLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-1.5 text-center shadow-xs"
              >
                Enroll / Access Digital Portal <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
