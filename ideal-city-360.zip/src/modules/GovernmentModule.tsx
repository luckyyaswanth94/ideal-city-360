import React, { useState } from 'react';
import { GovernmentRule, User } from '../types';
import { VerificationBadge } from '../components/VerificationBadge';
import { Language } from '../utils/translations';
import { 
  FileText, 
  Search, 
  Bot, 
  CheckCircle, 
  ExternalLink, 
  Sparkles, 
  PlusCircle, 
  Download, 
  X, 
  RefreshCw, 
  ShieldCheck,
  FileCheck2,
  Calendar,
  Layers,
  Info
} from 'lucide-react';

interface Props {
  rules: GovernmentRule[];
  currentUser: User;
  language: Language;
  onAddRule: (rule: Partial<GovernmentRule>) => void;
}

export const GovernmentModule: React.FC<Props> = ({
  rules,
  currentUser,
  language,
  onAddRule
}) => {
  const [selectedDept, setSelectedDept] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDoc, setSelectedDoc] = useState<GovernmentRule | null>(null);
  const [explainingDocId, setExplainingDocId] = useState<string | null>(null);
  const [aiExplanation, setAiExplanation] = useState<{ id: string; text: string } | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newRuleData, setNewRuleData] = useState({
    title: '',
    department: 'Civic & Municipality' as const,
    summary: '',
    eligibility: '',
    requiredDocuments: '',
    applicationSteps: '',
    applicationFee: 'Nil (Statutory Free Service)',
    officialSourceUrl: 'https://idealcity.gov.in',
    pdfTitle: 'Official_Notification_2026.pdf',
    pdfSummary: 'Official municipal notification published by urban authority.'
  });

  const canManage = currentUser.role === 'super_admin' || currentUser.role === 'gov_admin';

  const departments = [
    'all',
    'Civic & Municipality',
    'Welfare & Subsidy',
    'Health & Sanitation',
    'Urban Planning & Housing',
    'Revenue & Taxation'
  ];

  const filteredRules = rules.filter(r => {
    const matchesDept = selectedDept === 'all' || r.department === selectedDept;
    const matchesSearch = r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          r.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          r.requiredDocuments.some(d => d.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesDept && matchesSearch;
  });

  const handleExplainWithAi = async (rule: GovernmentRule) => {
    setExplainingDocId(rule.id);
    try {
      const res = await fetch('/api/gemini/explain-doc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ruleId: rule.id, language })
      });
      const data = await res.json();
      setAiExplanation({ id: rule.id, text: data.explanation });
    } catch (err) {
      setAiExplanation({ id: rule.id, text: 'Unable to generate AI explanation at this time.' });
    } finally {
      setExplainingDocId(null);
    }
  };

  const handleCreateRule = (e: React.FormEvent) => {
    e.preventDefault();
    onAddRule({
      ...newRuleData,
      eligibility: newRuleData.eligibility.split('\n').filter(Boolean),
      requiredDocuments: newRuleData.requiredDocuments.split('\n').filter(Boolean),
      applicationSteps: newRuleData.applicationSteps.split('\n').filter(Boolean),
      effectiveDate: new Date().toISOString().split('T')[0]
    });
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-8 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                <FileText className="w-3.5 h-3.5" /> Citizen Charter & Government Rules
              </span>
              <span className="text-xs text-slate-400">Statutory Welfare & Municipal Acts</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Public Schemes, Rules & Legal Documents
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
              Transparent, verified eligibility criteria, required documents checklists, step-by-step procedures, and AI-powered plain-language breakdown for complex official gazettes.
            </p>
          </div>

          {canManage && (
            <button
              type="button"
              onClick={() => setShowAddModal(true)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 self-start md:self-auto"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Publish Government Scheme</span>
            </button>
          )}
        </div>

        {/* Department Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-slate-800 text-xs">
          {departments.map(dept => (
            <button
              key={dept}
              type="button"
              onClick={() => setSelectedDept(dept)}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors capitalize ${
                selectedDept === dept ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
              }`}
            >
              {dept === 'all' ? 'All Departments' : dept}
            </button>
          ))}
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center gap-3">
        <Search className="w-4 h-4 text-slate-400 shrink-0 ml-2" />
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Search by scheme name, required document (e.g. Aadhaar, Ration Card), or keyword..."
          className="w-full text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden"
        />
      </div>

      {/* Scheme Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredRules.map(rule => (
          <div key={rule.id} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between space-y-5 hover:border-indigo-400 transition-all">
            <div className="space-y-4">
              
              <div className="flex items-start justify-between gap-3">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-800 border border-indigo-200">
                    {rule.department}
                  </span>
                  <h3 className="font-bold text-slate-900 text-base sm:text-lg mt-1.5 leading-snug">
                    {rule.title}
                  </h3>
                </div>

                {rule.pdfTitle && (
                  <button
                    type="button"
                    onClick={() => setSelectedDoc(rule)}
                    className="p-2 rounded-xl bg-slate-50 hover:bg-indigo-50 text-indigo-700 border border-slate-200 hover:border-indigo-300 transition-colors cursor-pointer shrink-0 flex items-center gap-1 text-xs font-semibold"
                    title="View PDF Document"
                  >
                    <FileCheck2 className="w-4 h-4" />
                    <span className="hidden sm:inline">View Gazette</span>
                  </button>
                )}
              </div>

              <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                {rule.summary}
              </p>

              {/* Eligibility Checklist */}
              <div>
                <h4 className="font-bold text-slate-800 text-xs mb-1.5 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                  Mandatory Eligibility Criteria:
                </h4>
                <ul className="space-y-1 text-xs text-slate-600">
                  {rule.eligibility.map((el, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-emerald-500 font-bold">•</span>
                      <span>{el}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Required Documents Checklist */}
              <div>
                <h4 className="font-bold text-slate-800 text-xs mb-1.5 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-indigo-600" />
                  Required Documents Checklist:
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {rule.requiredDocuments.map((doc, i) => (
                    <span key={i} className="text-[11px] bg-indigo-50 text-indigo-900 px-2.5 py-1 rounded-lg border border-indigo-100 font-medium">
                      {doc}
                    </span>
                  ))}
                </div>
              </div>

              {/* Application Steps */}
              <div>
                <h4 className="font-bold text-slate-800 text-xs mb-1.5 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-teal-600" />
                  Application Steps:
                </h4>
                <ol className="space-y-1 text-xs text-slate-600 list-decimal list-inside">
                  {rule.applicationSteps.map((step, i) => (
                    <li key={i}>{step}</li>
                  ))}
                </ol>
              </div>

              {/* Fee Transparency */}
              <div className="bg-amber-50/70 p-3 rounded-xl border border-amber-200 text-xs">
                <span className="font-bold text-amber-900 block mb-0.5">Statutory Application Fee:</span>
                <span className="text-amber-800 font-medium">{rule.applicationFee}</span>
              </div>

              {/* AI Explanation Accordion/Display if loaded */}
              {aiExplanation && aiExplanation.id === rule.id && (
                <div className="p-4 rounded-xl bg-teal-50 border border-teal-200 text-xs text-teal-900 space-y-2 animate-in fade-in">
                  <div className="flex items-center justify-between pb-1.5 border-b border-teal-200">
                    <span className="font-bold flex items-center gap-1.5 text-teal-900">
                      <Sparkles className="w-4 h-4 text-teal-600" /> IDEAL AI Simplified Plain-Language Guide
                    </span>
                    <button
                      type="button"
                      onClick={() => setAiExplanation(null)}
                      className="text-teal-700 hover:text-teal-900 font-bold"
                    >
                      ✕
                    </button>
                  </div>
                  <div className="whitespace-pre-wrap leading-relaxed text-slate-800">
                    {aiExplanation.text}
                  </div>
                </div>
              )}

            </div>

            {/* Bottom Actions and Verification */}
            <div className="space-y-3 pt-4 border-t border-slate-100">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <VerificationBadge verification={rule.verification} />
                
                <button
                  type="button"
                  onClick={() => handleExplainWithAi(rule)}
                  disabled={explainingDocId === rule.id}
                  className="bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 text-xs font-bold px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
                >
                  {explainingDocId === rule.id ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-teal-600" />
                      Explaining...
                    </>
                  ) : (
                    <>
                      <Bot className="w-3.5 h-3.5 text-teal-600" />
                      Explain with AI ({language === 'te' ? 'తెలుగు' : 'Plain English'})
                    </>
                  )}
                </button>
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
                <span>Effective: <strong>{rule.effectiveDate}</strong></span>
                <a
                  href={rule.officialSourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 underline"
                >
                  Official Government Portal <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* Official PDF Document Viewer Modal */}
      {selectedDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[85vh] flex flex-col overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95">
            
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-teal-400" />
                <div>
                  <h3 className="font-bold text-sm text-white">{selectedDoc.pdfTitle || 'Official Government Gazette.pdf'}</h3>
                  <span className="text-[11px] text-slate-400">{selectedDoc.department} • Digital Signature Certified</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedDoc(null)}
                className="text-slate-400 hover:text-white p-1 rounded"
              >
                ✕
              </button>
            </div>

            {/* Document Content View */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50 font-serif text-slate-800">
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4 relative">
                <div className="text-center pb-4 border-b border-slate-200">
                  <div className="text-xs uppercase font-sans tracking-widest text-slate-500 font-bold">GOVERNMENT GAZETTE EXTRAORDINARY</div>
                  <h2 className="text-lg font-bold text-slate-900 font-sans mt-1">{selectedDoc.title}</h2>
                  <div className="text-xs font-sans text-slate-400 mt-1">Official Reference: G.O.Ms.No. 68 / Ideal City Smart Municipal Framework</div>
                </div>

                <div className="space-y-3 text-xs leading-relaxed">
                  <p><strong>SUMMARY OF ORDER:</strong> {selectedDoc.summary}</p>
                  
                  <div>
                    <strong>1. STATUTORY ELIGIBILITY CONDITIONS:</strong>
                    <ul className="list-disc list-inside mt-1 space-y-1">
                      {selectedDoc.eligibility.map((el, i) => (
                        <li key={i}>{el}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <strong>2. DOCUMENTATION REQUIRED FOR SCRUTINY:</strong>
                    <ul className="list-disc list-inside mt-1 space-y-1">
                      {selectedDoc.requiredDocuments.map((d, i) => (
                        <li key={i}>{d}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <strong>3. STANDARD OPERATING PROCEDURE:</strong>
                    <ol className="list-decimal list-inside mt-1 space-y-1">
                      {selectedDoc.applicationSteps.map((st, i) => (
                        <li key={i}>{st}</li>
                      ))}
                    </ol>
                  </div>

                  <div className="bg-slate-50 p-3 rounded border border-slate-200 font-sans">
                    <strong>FEE SPECIFICATION:</strong> {selectedDoc.applicationFee}
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-200 flex items-center justify-between text-[11px] font-sans text-slate-400">
                  <span>Digitally Signed by: {selectedDoc.verification.verifiedBy}</span>
                  <span>Timestamp: {selectedDoc.verification.lastUpdated}</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-white border-t border-slate-200 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-sans">Certified Document Hash: SHA256-VALID-9942A</span>
              <div className="flex gap-2">
                <a
                  href={selectedDoc.officialSourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" /> Download Full Gazette PDF
                </a>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Add Rule Modal for Gov Admins */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-6 border border-slate-200 animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-bold text-slate-900 text-base">Publish Government Scheme / Regulation</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-700 text-lg leading-none p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateRule} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Scheme / Rule Title</label>
                <input
                  type="text"
                  required
                  value={newRuleData.title}
                  onChange={e => setNewRuleData({ ...newRuleData, title: e.target.value })}
                  placeholder="e.g. Universal Health Scheme 2026"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Department</label>
                  <select
                    value={newRuleData.department}
                    onChange={e => setNewRuleData({ ...newRuleData, department: e.target.value as any })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                  >
                    <option value="Civic & Municipality">Civic & Municipality</option>
                    <option value="Welfare & Subsidy">Welfare & Subsidy</option>
                    <option value="Health & Sanitation">Health & Sanitation</option>
                    <option value="Urban Planning & Housing">Urban Planning & Housing</option>
                    <option value="Revenue & Taxation">Revenue & Taxation</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Application Fee</label>
                  <input
                    type="text"
                    value={newRuleData.applicationFee}
                    onChange={e => setNewRuleData({ ...newRuleData, applicationFee: e.target.value })}
                    placeholder="Nil (Free) or ₹35 MeeSeva fee"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Official Summary</label>
                <textarea
                  rows={2}
                  required
                  value={newRuleData.summary}
                  onChange={e => setNewRuleData({ ...newRuleData, summary: e.target.value })}
                  placeholder="Brief description of the scheme and legal authority..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Eligibility Criteria (one per line)</label>
                <textarea
                  rows={2}
                  value={newRuleData.eligibility}
                  onChange={e => setNewRuleData({ ...newRuleData, eligibility: e.target.value })}
                  placeholder="Resident of city&#10;Income under ₹2,00,000&#10;Valid Food Security Card"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Required Documents (one per line)</label>
                <textarea
                  rows={2}
                  value={newRuleData.requiredDocuments}
                  onChange={e => setNewRuleData({ ...newRuleData, requiredDocuments: e.target.value })}
                  placeholder="Aadhaar Card&#10;White Ration Card&#10;Recent Photograph"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-lg font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 shadow-xs"
                >
                  Publish Verified Scheme
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
