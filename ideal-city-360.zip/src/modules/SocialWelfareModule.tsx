import React, { useState } from 'react';
import { SocialWelfareService, EmergencyContact } from '../types';
import { VerificationBadge } from '../components/VerificationBadge';
import { Users, Phone, MapPin, HeartHandshake, ShieldAlert, Utensils, Award, Clock } from 'lucide-react';

interface Props {
  services: SocialWelfareService[];
  emergencyContacts: EmergencyContact[];
}

export const SocialWelfareModule: React.FC<Props> = ({ services, emergencyContacts }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    'all',
    'Senior Citizen',
    'Women Safety',
    'Food Donation & Kitchen',
    'Disability Support',
    'NGO & Volunteer'
  ];

  const filtered = services.filter(s => {
    return selectedCategory === 'all' || s.category === selectedCategory;
  });

  return (
    <div className="space-y-8">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-950 via-slate-900 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-md">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-teal-500/20 text-teal-300 border border-teal-500/30 flex items-center gap-1">
              <Users className="w-3.5 h-3.5" /> Social Welfare & Community Shield
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
            Senior Citizen Care, Women Safety & Food Security
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
            Community assistance centers, Elder Line support, 24x7 SHE Teams women safety desks, and municipal Annapurna food kitchens.
          </p>
        </div>

        {/* Category Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-slate-800 text-xs">
          {categories.map(cat => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors capitalize ${
                selectedCategory === cat ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
              }`}
            >
              {cat === 'all' ? 'All Community Services' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* 24x7 Emergency Hotlines Grid */}
      <section className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-600" />
            <h2 className="text-lg font-bold text-slate-900">City Emergency Helpline Directory</h2>
          </div>
          <span className="text-xs text-slate-500 font-medium">Toll-Free 24x7 Dispatch</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {emergencyContacts.map(em => (
            <div key={em.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between text-center hover:border-rose-400 transition-colors">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider mb-1">{em.category}</span>
                <span className="text-lg font-black text-rose-700 block font-mono">{em.phone}</span>
                <span className="text-xs font-semibold text-slate-800 block mt-1 leading-tight line-clamp-2">{em.serviceName}</span>
              </div>
              <div className="mt-2 text-[10px] text-slate-400">{em.availableHours}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Social Welfare Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map(item => (
          <div key={item.id} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between space-y-4 hover:border-teal-400 transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-teal-50 text-teal-800 border border-teal-200">
                  {item.category}
                </span>
                <span className="text-xs text-slate-500 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" /> {item.timings.split(' ')[0]}
                </span>
              </div>

              <h3 className="font-bold text-slate-900 text-base leading-snug">{item.title}</h3>
              <div className="text-xs text-slate-600 font-medium mt-1">Provider: {item.provider}</div>

              <p className="text-xs text-slate-600 mt-3 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                {item.description}
              </p>

              <div className="mt-3 text-xs text-slate-600 space-y-1">
                <div className="flex items-start gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                  <span>{item.address}</span>
                </div>
                <div className="flex items-center gap-1.5 text-teal-700 font-semibold pt-1">
                  <Phone className="w-3.5 h-3.5 shrink-0" />
                  <span>{item.contactPhone}</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100">
              <VerificationBadge verification={item.verification} />
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
