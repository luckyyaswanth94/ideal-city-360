import React, { useState } from 'react';
import {
  User,
  Complaint,
  Hospital,
  JobListing,
  GovernmentRule,
  BloodDonationPledge,
  DonorLeaderboardEntry
} from '../types';
import {
  StarDonorBadgePill,
  StarDonorProfileCard,
  StarDonorLeaderboard
} from '../components/StarDonorPanel';
import { getCitizenDonationSummary } from '../utils/starDonor';
import { 
  UserCheck, 
  Bookmark, 
  Send, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Camera, 
  Bell, 
  MapPin, 
  Tag, 
  ChevronRight, 
  Trash2, 
  ExternalLink,
  Sun,
  Moon,
  Eye,
  Star,
  Droplet
} from 'lucide-react';

interface Props {
  currentUser: User;
  complaints: Complaint[];
  hospitals: Hospital[];
  jobs: JobListing[];
  governmentRules: GovernmentRule[];
  bloodDonations: BloodDonationPledge[];
  donorLeaderboard: DonorLeaderboardEntry[];
  onSubmitComplaint: (complaint: Partial<Complaint>) => void;
  onUpdateSubscriptions: (cats: string[]) => void;
  onToggleSave: (itemId: string) => void;
  onCompleteDonation: (donationId: string) => void;
  onGoToBloodBank: () => void;
  setActiveTab: (tab: string) => void;
  theme?: 'light' | 'dark';
  onToggleTheme?: () => void;
}

export const CitizenPortal: React.FC<Props> = ({
  currentUser,
  complaints,
  hospitals,
  jobs,
  governmentRules,
  bloodDonations,
  donorLeaderboard,
  onSubmitComplaint,
  onUpdateSubscriptions,
  onToggleSave,
  onCompleteDonation,
  onGoToBloodBank,
  setActiveTab,
  theme = 'light',
  onToggleTheme
}) => {
  const [activeTab, setActiveTabLocal] = useState<'dashboard' | 'starDonor' | 'submitGrievance' | 'saved' | 'subscriptions' | 'preferences'>('dashboard');
  const donationSummary = getCitizenDonationSummary(currentUser, donorLeaderboard, bloodDonations);
  
  // Grievance form state
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<Complaint['category']>('Sanitation & Roads');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [priority, setPriority] = useState<Complaint['priority']>('Medium');
  const [imageUrl, setImageUrl] = useState('');
  const [submittedTicket, setSubmittedTicket] = useState<string | null>(null);

  const availableCategories = ['Health', 'Transport', 'Civic', 'Emergency', 'Weather'];

  const handleToggleSub = (cat: string) => {
    let current = [...currentUser.subscribedCategories];
    if (current.includes(cat)) {
      current = current.filter(c => c !== cat);
    } else {
      current.push(cat);
    }
    onUpdateSubscriptions(current);
  };

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      setImageUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description || !location) return;

    onSubmitComplaint({
      title,
      category,
      description,
      location,
      priority,
      imageUrl
    });

    setSubmittedTicket(`IDC-2026-${Math.floor(10000 + Math.random() * 90000)}`);
    setTitle('');
    setDescription('');
    setLocation('');
    setImageUrl('');
  };

  // Saved objects
  const savedHospitals = hospitals.filter(h => currentUser.savedItemIds.includes(h.id));
  const savedJobs = jobs.filter(j => currentUser.savedItemIds.includes(j.id));
  const savedRules = governmentRules.filter(r => currentUser.savedItemIds.includes(r.id));

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-teal-500/20 text-teal-300 border border-teal-500/30 flex items-center gap-1">
                <UserCheck className="w-3.5 h-3.5" /> Citizen Self-Service Portal
              </span>
              <StarDonorBadgePill badge={donationSummary.badge} compact />
              <span className="text-xs text-slate-400">Zone: {currentUser.zone || 'Central Municipal Sector'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Welcome back, {currentUser.name}
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
              Track your Star Donor blood donation milestones, civic grievance tickets, verified bookmarks, and critical city alert subscriptions.
            </p>
          </div>

          <div className="bg-white/10 p-4 rounded-2xl border border-white/20 text-xs space-y-1.5 min-w-[240px]">
            <div>Email: <strong className="text-white">{currentUser.email}</strong></div>
            <div>Phone: <strong className="text-white">{currentUser.phone || '+91 98480 12345'}</strong></div>
            <div className="flex items-center justify-between gap-2 pt-1 border-t border-white/15">
              <span className="flex items-center gap-1 text-amber-300 font-bold">
                <Droplet className="w-3.5 h-3.5 fill-current text-rose-400" />
                Total Blood Donations:
              </span>
              <strong className="text-white text-sm" data-testid="header-total-donations">
                {donationSummary.totalDonations}
              </strong>
            </div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-slate-300">Star Donor Rank:</span>
              <button
                type="button"
                onClick={() => setActiveTabLocal('starDonor')}
                className="text-amber-300 hover:text-amber-200 font-bold underline cursor-pointer"
              >
                {donationSummary.cityRank ? `#${donationSummary.cityRank} • ${donationSummary.badge.tier.shortLabel}` : donationSummary.badge.tier.shortLabel}
              </button>
            </div>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveTabLocal('dashboard')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors cursor-pointer ${
              activeTab === 'dashboard' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            My Complaints & Status ({complaints.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTabLocal('starDonor')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'starDonor'
                ? 'bg-amber-400 text-slate-950 shadow-xs'
                : 'text-amber-200 hover:bg-amber-500/20 border border-amber-400/30'
            }`}
          >
            <Star className="w-3.5 h-3.5 fill-current" />
            <span>Star Donor &amp; Leaderboard ({donationSummary.totalDonations})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTabLocal('submitGrievance')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors cursor-pointer ${
              activeTab === 'submitGrievance' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Submit Grievance / Service Request
          </button>
          <button
            type="button"
            onClick={() => setActiveTabLocal('saved')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors cursor-pointer ${
              activeTab === 'saved' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Saved Items ({currentUser.savedItemIds.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTabLocal('subscriptions')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors cursor-pointer ${
              activeTab === 'subscriptions' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            Update Subscriptions ({currentUser.subscribedCategories.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTabLocal('preferences')}
            className={`px-4 py-2 rounded-xl font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'preferences' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-300 hover:bg-white/10'
            }`}
          >
            {theme === 'dark' ? <Moon className="w-3.5 h-3.5 text-teal-400" /> : <Sun className="w-3.5 h-3.5 text-amber-400" />}
            Accessibility & Display
          </button>
        </div>
      </div>

      {/* TAB: STAR DONOR BADGE & LEADERBOARD */}
      {activeTab === 'starDonor' && (
        <div className="space-y-6">
          <StarDonorProfileCard
            currentUser={currentUser}
            donorLeaderboard={donorLeaderboard}
            bloodDonations={bloodDonations}
            onCompleteDonation={onCompleteDonation}
            onGoToBloodBank={onGoToBloodBank}
          />
          <StarDonorLeaderboard
            donorLeaderboard={donorLeaderboard}
            bloodDonations={bloodDonations}
            currentUser={currentUser}
          />
        </div>
      )}

      {/* TAB 1: COMPLAINTS & DASHBOARD */}
      {activeTab === 'dashboard' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900">Tracked Grievances & Service Redressal</h2>
            <button
              type="button"
              onClick={() => setActiveTabLocal('submitGrievance')}
              className="text-xs font-bold text-teal-700 hover:text-teal-900 flex items-center gap-1"
            >
              + File New Grievance
            </button>
          </div>

          {complaints.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
              <CheckCircle2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="font-bold text-slate-800 text-base">No Active Grievance Tickets</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Have you noticed road damage, missing bus timetable, or inaccurate hospital info? Submit a grievance to trigger prompt inspection.
              </p>
              <button
                type="button"
                onClick={() => setActiveTabLocal('submitGrievance')}
                className="mt-4 px-5 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-teal-700"
              >
                Submit Citizen Grievance
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {complaints.map(cmp => {
                // Status steps timeline
                const steps = ['Submitted', 'In Review', 'In Progress', 'Resolved'];
                const currentStepIdx = steps.indexOf(cmp.status);

                return (
                  <div key={cmp.id} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold bg-slate-100 text-slate-800 px-2 py-0.5 rounded border border-slate-200">
                            Ticket #{cmp.ticketNumber}
                          </span>
                          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-teal-50 text-teal-800 border border-teal-200">
                            {cmp.category}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            cmp.priority === 'Critical' || cmp.priority === 'High' ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-700'
                          }`}>
                            {cmp.priority} Priority
                          </span>
                        </div>
                        <h3 className="font-bold text-slate-900 text-base mt-1.5">{cmp.title}</h3>
                      </div>

                      <div className="text-xs text-slate-400">
                        Logged on {new Date(cmp.createdAt).toLocaleDateString()}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                      <div className="md:col-span-2 space-y-2">
                        <p className="text-slate-700 leading-relaxed">{cmp.description}</p>
                        <div className="text-slate-500 flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>Location: {cmp.location}</span>
                        </div>

                        {cmp.adminNotes && (
                          <div className="mt-3 p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-700">
                            <span className="font-bold text-slate-900 block mb-0.5">Municipal Response & Action Notes:</span>
                            {cmp.adminNotes}
                          </div>
                        )}
                      </div>

                      {cmp.imageUrl && (
                        <div>
                          <span className="text-[11px] font-semibold text-slate-500 block mb-1">Supporting Photo Attachment:</span>
                          <img
                            src={cmp.imageUrl}
                            alt="Grievance evidence"
                            className="w-full h-32 object-cover rounded-xl border border-slate-200"
                          />
                        </div>
                      )}
                    </div>

                    {/* Visual Progress Timeline */}
                    <div className="pt-3 border-t border-slate-100">
                      <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">Resolution Progress:</div>
                      <div className="grid grid-cols-4 gap-2">
                        {steps.map((st, idx) => {
                          const isDone = idx <= currentStepIdx;
                          const isCurrent = idx === currentStepIdx;
                          return (
                            <div key={st} className="space-y-1 text-center">
                              <div className={`h-2 rounded-full transition-all ${
                                isDone ? 'bg-emerald-600' : 'bg-slate-200'
                              } ${isCurrent ? 'ring-2 ring-emerald-400' : ''}`} />
                              <span className={`text-[11px] block font-semibold ${
                                isDone ? 'text-emerald-700' : 'text-slate-400'
                              }`}>
                                {st}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: SUBMIT GRIEVANCE FORM */}
      {activeTab === 'submitGrievance' && (
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-2xl mx-auto space-y-5">
          <div className="pb-4 border-b border-slate-200">
            <h2 className="text-xl font-bold text-slate-900">Submit Citizen Complaint or Report Incorrect Info</h2>
            <p className="text-xs text-slate-500 mt-1">
              Your grievance is directly routed to the municipal control room and assigned an auditable tracking ticket.
            </p>
          </div>

          {submittedTicket && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 space-y-1 animate-in fade-in">
              <div className="font-bold flex items-center gap-1.5 text-emerald-800">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Grievance Registered Successfully!
              </div>
              <p>Your ticket reference number is <strong>{submittedTicket}</strong>. An inspection supervisor has been alerted.</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-800 mb-1">Issue Category</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-800 font-medium"
              >
                <option value="Sanitation & Roads">Sanitation & Road Damage / Pothole</option>
                <option value="Healthcare">Healthcare & Hospital Service Issue</option>
                <option value="Public Transport">Public Transport / Bus Timing Discrepancy</option>
                <option value="Water Supply">Drinking Water Supply / Leakage</option>
                <option value="Electricity">Streetlight / Power Fault</option>
                <option value="Illegal Encroachment">Illegal Encroachment / Footpath Obstruction</option>
                <option value="Incorrect Info Report">Report Inaccurate / Outdated Information on Platform</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-800 mb-1">Grievance Headline / Summary</label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Non-functional streetlights on Hospital Access Road Gate 2"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-800"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-800 mb-1">Exact Location / Landmark</label>
                <input
                  type="text"
                  required
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  placeholder="e.g. Sector 4, Raj Bhavan Road, Amberpet"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-800 mb-1">Priority</label>
                <select
                  value={priority}
                  onChange={e => setPriority(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-800 font-medium"
                >
                  <option value="Low">Low (General suggestion)</option>
                  <option value="Medium">Medium (Standard 48h resolution)</option>
                  <option value="High">High (Urgent public risk)</option>
                  <option value="Critical">Critical (Immediate safety threat)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-800 mb-1">Detailed Description of Issue</label>
              <textarea
                rows={4}
                required
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Please provide specific details to help the field inspection team locate and resolve the issue quickly..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-800"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-800 mb-1">Supporting Photo Attachment (Optional)</label>
              <div className="flex items-center gap-3">
                <label className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2.5 rounded-xl border border-slate-300 font-semibold cursor-pointer flex items-center gap-1.5 transition-colors">
                  <Camera className="w-4 h-4 text-slate-600" />
                  <span>Choose Photo</span>
                  <input type="file" accept="image/*" onChange={handleImageFileChange} className="hidden" />
                </label>
                <span className="text-slate-400 text-[11px]">Attach photo of damaged road, faulty screen, or paper notice</span>
              </div>
              {imageUrl && (
                <div className="mt-2 relative w-32 h-24 rounded-lg overflow-hidden border border-slate-200">
                  <img src={imageUrl} alt="preview" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setImageUrl('')}
                    className="absolute top-1 right-1 bg-rose-600 text-white rounded-full p-0.5 text-[10px]"
                  >
                    ✕
                  </button>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-200 flex justify-end">
              <button
                type="submit"
                className="bg-teal-600 hover:bg-teal-700 text-white font-bold px-6 py-3 rounded-xl shadow-xs flex items-center gap-2 cursor-pointer transition-colors"
              >
                <Send className="w-4 h-4" />
                <span>Submit Grievance to Municipal Control</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 3: SAVED ITEMS */}
      {activeTab === 'saved' && (
        <div className="space-y-6">
          <h2 className="text-lg font-bold text-slate-900">Your Bookmarked Public Records</h2>

          {/* Hospitals */}
          <div>
            <h3 className="font-bold text-slate-800 text-sm mb-3">Saved Hospitals ({savedHospitals.length})</h3>
            {savedHospitals.length === 0 ? (
              <p className="text-xs text-slate-400 italic">No hospitals saved yet. Click the bookmark icon on any hospital card to save it here.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {savedHospitals.map(h => (
                  <div key={h.id} className="p-4 bg-white rounded-xl border border-slate-200 flex justify-between items-start text-xs">
                    <div>
                      <h4 className="font-bold text-slate-900">{h.name}</h4>
                      <div className="text-slate-500 mt-0.5">{h.address}</div>
                      <div className="text-emerald-700 font-semibold mt-1">Available Beds: {h.bedCount.available} (ICU: {h.bedCount.icu})</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onToggleSave(h.id)}
                      className="text-rose-600 hover:text-rose-800 p-1"
                      title="Remove"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Jobs */}
          <div>
            <h3 className="font-bold text-slate-800 text-sm mb-3">Saved Employment Listings ({savedJobs.length})</h3>
            {savedJobs.length === 0 ? (
              <p className="text-xs text-slate-400 italic">No jobs saved yet.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {savedJobs.map(j => (
                  <div key={j.id} className="p-4 bg-white rounded-xl border border-slate-200 flex justify-between items-start text-xs">
                    <div>
                      <h4 className="font-bold text-slate-900">{j.title}</h4>
                      <div className="text-slate-500 mt-0.5">{j.organization} • Deadline: {j.deadline}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onToggleSave(j.id)}
                      className="text-rose-600 hover:text-rose-800 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: SUBSCRIPTIONS */}
      {activeTab === 'subscriptions' && (
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs max-w-xl mx-auto space-y-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <Bell className="w-5 h-5 text-teal-600" />
              Notification Category Subscriptions
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Select update categories you wish to receive instant alerts and notifications for.
            </p>
          </div>

          <div className="space-y-3 pt-2">
            {availableCategories.map(cat => {
              const isSubscribed = currentUser.subscribedCategories.includes(cat);
              return (
                <div
                  key={cat}
                  onClick={() => handleToggleSub(cat)}
                  className={`p-4 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
                    isSubscribed ? 'bg-teal-50 border-teal-300' : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div>
                    <span className="font-bold text-slate-900 text-sm block">{cat} Category</span>
                    <span className="text-xs text-slate-500">
                      {cat === 'Health' && 'Doctor visiting rosters, hospital bed status, vaccination camps'}
                      {cat === 'Transport' && 'Bus delays, route rerouting, electric bus fleet additions'}
                      {cat === 'Civic' && 'Water supply notices, road repairs, municipal services'}
                      {cat === 'Emergency' && 'Weather alerts, high-priority municipal emergency warnings'}
                      {cat === 'Weather' && 'Heavy rain, monsoon waterlogging, heatwave advisories'}
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={isSubscribed}
                    onChange={() => {}}
                    className="w-4 h-4 text-teal-600 rounded"
                  />
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 5: ACCESSIBILITY & DISPLAY PREFERENCES */}
      {activeTab === 'preferences' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-xs max-w-xl mx-auto space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Eye className="w-5 h-5 text-teal-600 dark:text-teal-400" />
              Accessibility & Display Preferences
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Customize visual appearance and contrast to ensure comfortable, accessible reading at all times.
            </p>
          </div>

          {/* Theme Mode Selector */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider block">
              Theme Mode
            </span>

            <div className="grid grid-cols-2 gap-3">
              {/* Light Mode Card */}
              <button
                type="button"
                onClick={() => {
                  if (theme !== 'light' && onToggleTheme) onToggleTheme();
                }}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                  theme === 'light'
                    ? 'border-teal-500 bg-teal-50/50 ring-2 ring-teal-500/20 shadow-xs'
                    : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-slate-50 dark:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-700 shadow-2xs">
                    <Sun className="w-5 h-5 text-amber-600" />
                  </div>
                  {theme === 'light' && (
                    <span className="w-2.5 h-2.5 rounded-full bg-teal-600"></span>
                  )}
                </div>
                <div>
                  <span className="font-bold text-slate-900 dark:text-white text-sm block">Light Mode</span>
                  <span className="text-slate-500 dark:text-slate-400 text-xs">High clarity white background with deep navy and emerald accents</span>
                </div>
              </button>

              {/* Dark Mode Card */}
              <button
                type="button"
                onClick={() => {
                  if (theme !== 'dark' && onToggleTheme) onToggleTheme();
                }}
                className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                  theme === 'dark'
                    ? 'border-teal-400 bg-teal-950/40 ring-2 ring-teal-400/20 shadow-xs'
                    : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-slate-50 dark:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-teal-400 shadow-2xs">
                    <Moon className="w-5 h-5 text-teal-300" />
                  </div>
                  {theme === 'dark' && (
                    <span className="w-2.5 h-2.5 rounded-full bg-teal-400"></span>
                  )}
                </div>
                <div>
                  <span className="font-bold text-slate-900 dark:text-white text-sm block">Dark Mode</span>
                  <span className="text-slate-500 dark:text-slate-400 text-xs">Reduced glare for low-light reading and enhanced battery efficiency</span>
                </div>
              </button>
            </div>
          </div>

          {/* Accessibility Standards Note */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 space-y-1.5">
            <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> WCAG AA Compliance
            </div>
            <p className="leading-relaxed">
              Theme colors adhere to WCAG 2.1 contrast ratios (4.5:1 minimum for normal text) ensuring full readability for citizens with low vision or photophobia.
            </p>
          </div>
        </div>
      )}

    </div>
  );
};
