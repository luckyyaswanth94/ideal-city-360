export type UserRole = 
  | 'citizen' 
  | 'super_admin' 
  | 'hospital_admin' 
  | 'transport_admin' 
  | 'gov_admin' 
  | 'verifier'
  | 'ambulance_service'
  | 'police_officer';

export type VerificationStatus = 'Pending' | 'Verified' | 'Rejected' | 'Expired';

export interface VerificationMeta {
  sourceName: string;
  sourceUrl: string;
  createdDate: string;
  lastUpdated: string;
  verificationStatus: VerificationStatus;
  validFrom?: string;
  validUntil?: string;
  verifiedBy?: string;
  isDemoData: boolean;
  updateHistory: {
    timestamp: string;
    action: string;
    user: string;
    details?: string;
  }[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  zone?: string;
  bloodGroup?: BloodGroup;
  totalDonations?: number;
  savedItemIds: string[];
  subscribedCategories: string[];
}

export interface Hospital {
  id: string;
  name: string;
  type: 'Government Super-Specialty' | 'Private Multi-Specialty' | 'Community Health Center' | 'Maternity & Child Hospital';
  address: string;
  phone: string;
  emergencyPhone: string;
  location: {
    lat: number;
    lng: number;
    area: string;
  };
  facilities: string[];
  bedCount: {
    total: number;
    available: number;
    icu: number;
  };
  rating: number;
  openHours: string;
  verification: VerificationMeta;
}

export interface Doctor {
  id: string;
  name: string;
  qualification: string;
  specialization: 'Cardiology' | 'Neurology' | 'Orthopedics' | 'Pediatrics' | 'Oncology' | 'General Medicine' | 'Gynecology' | 'Pulmonology';
  hospitalId: string;
  hospitalName: string;
  experienceYears: number;
  consultationFee: number;
  availableDays: string[];
  timings: string;
  rating: number;
  verification: VerificationMeta;
}

export interface DoctorVisit {
  id: string;
  doctorName: string;
  specialization: string;
  hospitalId: string;
  hospitalName: string;
  visitDate: string;
  consultationHours: string;
  appointmentLink: string;
  roomNumber: string;
  tokenCapacity: number;
  bookedTokens: number;
  status: 'Scheduled' | 'In Progress' | 'Completed' | 'Postponed';
  verification: VerificationMeta;
}

export interface HospitalVacancy {
  id: string;
  hospitalId: string;
  hospitalName: string;
  title: string;
  department: string;
  roleType: 'Nurse' | 'Doctor' | 'Technician' | 'Administrative' | 'Support Staff';
  qualifications: string;
  eligibility: string;
  positions: number;
  deadline: string;
  applicationLink: string;
  salaryRange: string;
  verification: VerificationMeta;
}

export interface HealthCamp {
  id: string;
  title: string;
  organizer: string;
  location: string;
  date: string;
  timings: string;
  servicesProvided: string[];
  contactNumber: string;
  freeMedicines: boolean;
  verification: VerificationMeta;
}

export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export interface BloodBank {
  id: string;
  name: string;
  hospitalId?: string;
  address: string;
  zone: string;
  lat?: number;
  lng?: number;
  phone: string;
  emergencyPhone: string;
  openHours: string;
  licenseNumber: string;
  is24x7: boolean;
  componentSeparation: boolean;
  inventory: Record<BloodGroup, number>;
  verification: VerificationMeta;
}

export interface BloodRequest {
  id: string;
  requestCode: string;
  patientName: string;
  bloodGroup: BloodGroup;
  unitsNeeded: number;
  urgency: 'Emergency' | 'Urgent' | 'Scheduled';
  hospitalName: string;
  bloodBankId?: string;
  zone?: string;
  lat?: number;
  lng?: number;
  contactName: string;
  contactPhone: string;
  notes?: string;
  status: 'Pending' | 'Matched' | 'Fulfilled';
  createdAt: string;
}

export interface BloodDonationPledge {
  id: string;
  pledgeCode: string;
  donorName: string;
  bloodGroup: BloodGroup;
  age: number;
  weightKg: number;
  phone: string;
  email?: string;
  preferredBankId: string;
  preferredBankName: string;
  preferredDate: string;
  preferredSlot: string;
  status: 'Scheduled' | 'Completed';
  createdAt: string;
}

export interface DonorLeaderboardEntry {
  id: string;
  name: string;
  email: string;
  bloodGroup: BloodGroup;
  zone: string;
  totalDonations: number;
  lastDonationDate: string;
  verified: boolean;
}

export interface BusStop {
  id: string;
  name: string;
  lat: number;
  lng: number;
  order: number;
}

export interface BusRoute {
  id: string;
  routeNumber: string;
  name: string;
  type: 'Smart Electric AC' | 'Metro Feeder' | 'Express City' | 'Standard Non-AC';
  source: string;
  destination: string;
  distanceKm: number;
  travelTimeMinutes: number;
  frequencyMinutes: number;
  stops: BusStop[];
  firstBus: string;
  lastBus: string;
  fareMin: number;
  fareMax: number;
  verification: VerificationMeta;
}

export interface BusSchedule {
  id: string;
  routeId: string;
  routeNumber: string;
  source: string;
  destination: string;
  currentStop: string;
  nextStop: string;
  scheduledTime: string;
  estimatedTime: string;
  isLive: boolean;
  status: 'On Time' | 'Delayed' | 'Departed' | 'Arriving';
  delayMinutes: number;
  busRegistrationNumber: string;
  occupancy: 'Low' | 'Medium' | 'High';
  verification: VerificationMeta;
}

export interface TransportAlert {
  id: string;
  title: string;
  routeNumber: string;
  type: 'Delay' | 'Route Change' | 'Cancellation' | 'Maintenance';
  message: string;
  effectiveFrom: string;
  effectiveUntil: string;
  verification: VerificationMeta;
}

export interface GovernmentRule {
  id: string;
  title: string;
  department: 'Civic & Municipality' | 'Welfare & Subsidy' | 'Revenue & Taxation' | 'Health & Sanitation' | 'Urban Planning & Housing';
  summary: string;
  eligibility: string[];
  requiredDocuments: string[];
  applicationSteps: string[];
  applicationFee: string;
  effectiveDate: string;
  expiryDate?: string;
  officialSourceUrl: string;
  pdfTitle?: string;
  pdfSummary?: string;
  verification: VerificationMeta;
}

export interface JobListing {
  id: string;
  title: string;
  organization: string;
  sector: 'Government' | 'Private' | 'Hospital' | 'Education';
  type: 'Full-time' | 'Contract' | 'Internship' | 'Scholarship' | 'Competitive Exam';
  qualification: string;
  vacancies: number;
  deadline: string;
  applicationLink: string;
  location: string;
  salary: string;
  verification: VerificationMeta;
}

export interface EducationService {
  id: string;
  title: string;
  institution: string;
  category: 'College & University' | 'School' | 'Scholarship' | 'Skill Programme' | 'Career Guidance' | 'Online Resource';
  description: string;
  eligibility: string;
  applicationLink: string;
  deadline?: string;
  contactEmail?: string;
  verification: VerificationMeta;
}

export interface SocialWelfareService {
  id: string;
  title: string;
  category: 'Senior Citizen' | 'Disability Support' | 'Women Safety' | 'Food Donation & Kitchen' | 'NGO & Volunteer' | 'Community Event';
  provider: string;
  contactPhone: string;
  address: string;
  description: string;
  timings: string;
  eligibility?: string;
  verification: VerificationMeta;
}

export interface EmergencyContact {
  id: string;
  serviceName: string;
  phone: string;
  availableHours: string;
  category: 'Police' | 'Ambulance' | 'Fire' | 'Women Helpline' | 'Disaster Management' | 'Childcare Helpline';
  tollFree: boolean;
}

export interface Complaint {
  id: string;
  ticketNumber: string;
  citizenId: string;
  citizenName: string;
  citizenEmail: string;
  title: string;
  category: 'Healthcare' | 'Public Transport' | 'Sanitation & Roads' | 'Water Supply' | 'Electricity' | 'Illegal Encroachment' | 'Incorrect Info Report';
  description: string;
  location: string;
  imageUrl?: string;
  status: 'Submitted' | 'In Review' | 'In Progress' | 'Resolved';
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
  adminNotes?: string;
}

export interface Announcement {
  id: string;
  title: string;
  category: 'Health' | 'Transport' | 'Civic' | 'Weather' | 'Emergency';
  summary: string;
  detailedText: string;
  publishedAt: string;
  isUrgent: boolean;
  officialSource: string;
  verification: VerificationMeta;
}

export interface CityWellBeingMetric {
  id: string;
  category: string;
  name: string;
  score: number; // 0 - 100
  target: number;
  unit: string;
  status: 'Excellent' | 'Good' | 'Needs Attention';
  trend: 'up' | 'stable' | 'down';
  historicalData: { month: string; value: number }[];
  keyHighlights: string[];
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'alert' | 'update' | 'verification' | 'complaint';
  timestamp: string;
  read: boolean;
  link?: string;
}

export type AccidentSeverity = 'Low' | 'Medium' | 'Critical';

export type AccidentType =
  | 'Car Collision'
  | 'Bike Accident'
  | 'Two-Wheeler & Car Collision'
  | 'Truck Accident'
  | 'Pedestrian Accident'
  | 'Multi-Vehicle Collision'
  | 'No Road Accident Detected'
  | 'Other Road Incident';

export interface AccidentAiAnalysis {
  isAccidentDetected: boolean;
  accidentType: AccidentType;
  severity: AccidentSeverity;
  confidenceLabel: 'High' | 'Moderate' | 'Low';
  visibleIndicators: string[];
  estimatedInjuredHint: string;
  shortDescription: string;
  disclaimer: string;
  analyzedAt: string;
  modelUsed: string;
  isManualFallback?: boolean;
}

export interface PoliceStation {
  id: string;
  name: string;
  zone: string;
  address: string;
  phone: string;
  controlRoomPhone: string;
  lat: number;
  lng: number;
  officerInCharge: string;
}

export interface AmbulanceUnit {
  id: string;
  callSign: string;
  stationName: string;
  zone: string;
  phone: string;
  vehicleNumber: string;
  type: 'ALS Trauma ICU' | 'BLS Rapid Response';
  lat: number;
  lng: number;
  status: 'Available' | 'Dispatched';
}

export type HospitalResponseStatus =
  | 'Pending'
  | 'Notified'
  | 'Acknowledged'
  | 'Trauma Bay Ready'
  | 'Patient Admitted';

export type AmbulanceResponseStatus =
  | 'Pending'
  | 'Notified'
  | 'Dispatched'
  | 'En Route'
  | 'On Scene'
  | 'Transporting'
  | 'Completed';

export type PoliceResponseStatus =
  | 'Pending'
  | 'Notified'
  | 'Patrol Dispatched'
  | 'Investigating'
  | 'Scene Cleared'
  | 'Case Closed';

export type AccidentOverallStatus =
  | 'Active Emergency'
  | 'Response Dispatched'
  | 'Resolved';

export interface NotifiedHospitalRecord {
  hospitalId: string;
  hospitalName: string;
  distanceKm: number;
  emergencyPhone: string;
  lat: number;
  lng: number;
  status: HospitalResponseStatus;
  deliveryConfirmed: boolean;
  deliveryMode: 'demo_simulated' | 'live_webhook';
  notifiedAt: string | null;
  updatedAt: string;
  bedsReserved?: number;
  notes?: string;
}

export interface AmbulanceDispatchRecord {
  unitId: string;
  callSign: string;
  stationName: string;
  vehicleNumber: string;
  phone: string;
  originLat: number;
  originLng: number;
  distanceKm: number;
  etaMinutes: number | null;
  routeWaypoints: { lat: number; lng: number }[];
  status: AmbulanceResponseStatus;
  deliveryConfirmed: boolean;
  deliveryMode: 'demo_simulated' | 'live_webhook';
  notifiedAt: string | null;
  updatedAt: string;
  notes?: string;
}

export interface PoliceDispatchRecord {
  stationId: string;
  stationName: string;
  zone: string;
  phone: string;
  lat: number;
  lng: number;
  distanceKm: number;
  status: PoliceResponseStatus;
  deliveryConfirmed: boolean;
  deliveryMode: 'demo_simulated' | 'live_webhook';
  notifiedAt: string | null;
  updatedAt: string;
  officerNotes?: string;
}

export interface AccidentResponseEvent {
  id: string;
  timestamp: string;
  actor: string;
  agency: 'Citizen' | 'AI Triage' | 'Hospital' | 'Ambulance' | 'Police' | 'Command Center';
  message: string;
  statusBadge?: string;
}

export interface AccidentPrivacyCompliance {
  exifMetadataStripped: boolean;
  strippedMetadataSegments: number;
  encryptedAtRest: boolean;
  noAiTrainingWithoutConsent: boolean;
  piiCollected: boolean;
  retentionDays: number;
  dpdpActCompliant: boolean;
}

export interface AccidentReport {
  id: string;
  incidentCode: string;
  reportedAt: string;
  incidentDate: string;
  incidentTime: string;
  latitude: number;
  longitude: number;
  locationLabel: string;
  locationSource: 'gps' | 'manual_map';
  googleMapsUrl: string;
  /** Authorized-only API media route (/api/accidents/media/:securePhotoId). Never publicly exposed. */
  securePhotoId: string;
  securePhotoUrl: string;
  aiAnalysis: AccidentAiAnalysis;
  accidentType: AccidentType;
  severity: AccidentSeverity;
  possibleInjuredCount: number | null;
  reporterConfirmed: boolean;
  confirmedAt: string;
  /** Strictly 'anonymous' unless reporter explicitly opted in to share an optional callback number */
  reporterIdentityMode: 'anonymous' | 'optional_callback_consented';
  reporterIdentityLabel: 'Anonymous';
  optionalCallbackConsented: boolean;
  optionalCallbackPhone?: string;
  sceneNotes?: string;
  authorityAlertText: string;
  overallStatus: AccidentOverallStatus;
  demoMode: boolean;
  retentionExpiresAt: string;
  privacyCompliance: AccidentPrivacyCompliance;
  notifiedHospitals: NotifiedHospitalRecord[];
  ambulanceDispatch: AmbulanceDispatchRecord;
  policeDispatch: PoliceDispatchRecord;
  responseHistory: AccidentResponseEvent[];
}
