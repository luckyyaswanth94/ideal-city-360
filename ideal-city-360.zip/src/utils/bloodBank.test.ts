import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getCompatibleDonorGroups,
  isCompatibleDonor,
  getStockLevelStatus,
  getTotalUnitsByGroup,
  getTotalCityUnits,
  filterBloodBanks,
  validateBloodRequest,
  validateBloodDonation,
  checkDonorEligibility
} from './bloodBank';
import type { BloodBank } from '../types';

const sampleBanks: BloodBank[] = [
  {
    id: 'bb-1',
    name: 'Central Govt Hospital Blood Bank',
    address: 'Sector 4, Central Medical Enclave',
    zone: 'Central Zone',
    phone: '040-2345-6790',
    emergencyPhone: '040-2345-6701',
    openHours: '24x7',
    licenseNumber: 'TS-BB-2026-001',
    is24x7: true,
    componentSeparation: true,
    inventory: { 'A+': 24, 'A-': 4, 'B+': 30, 'B-': 6, 'AB+': 12, 'AB-': 2, 'O+': 35, 'O-': 3 },
    verification: {
      sourceName: 'State Blood Transfusion Council',
      sourceUrl: 'https://sbtc.idealcity.gov.in',
      createdDate: '2026-01-01',
      lastUpdated: '2026-11-18T10:00:00Z',
      verificationStatus: 'Verified',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'bb-2',
    name: 'Cyber Corridor Red Cross Blood Center',
    address: 'Plot 18, Cyber Zone',
    zone: 'Cyber Zone',
    phone: '040-2980-1100',
    emergencyPhone: '040-2980-1199',
    openHours: '24x7',
    licenseNumber: 'TS-BB-2026-014',
    is24x7: true,
    componentSeparation: true,
    inventory: { 'A+': 16, 'A-': 2, 'B+': 18, 'B-': 0, 'AB+': 8, 'AB-': 1, 'O+': 20, 'O-': 0 },
    verification: {
      sourceName: 'Indian Red Cross Society',
      sourceUrl: 'https://redcross.idealcity.gov.in',
      createdDate: '2026-02-01',
      lastUpdated: '2026-11-18T11:00:00Z',
      verificationStatus: 'Verified',
      isDemoData: true,
      updateHistory: []
    }
  }
];

test('blood compatibility rules work for universal donor and universal recipient', () => {
  assert.deepEqual(getCompatibleDonorGroups('O-'), ['O-']);
  assert.equal(getCompatibleDonorGroups('AB+').length, 8);
  assert.equal(isCompatibleDonor('O-', 'A+'), true);
  assert.equal(isCompatibleDonor('A+', 'O-'), false);
  assert.equal(isCompatibleDonor('B-', 'B+'), true);
});

test('stock level classification distinguishes critical, low, and available', () => {
  assert.equal(getStockLevelStatus(0), 'Critical');
  assert.equal(getStockLevelStatus(3), 'Critical');
  assert.equal(getStockLevelStatus(4), 'Low');
  assert.equal(getStockLevelStatus(10), 'Low');
  assert.equal(getStockLevelStatus(11), 'Available');
});

test('inventory aggregation calculates group totals and city total accurately', () => {
  const byGroup = getTotalUnitsByGroup(sampleBanks);
  assert.equal(byGroup['A+'], 40);
  assert.equal(byGroup['O-'], 3);
  assert.equal(byGroup['B-'], 6);
  assert.equal(getTotalCityUnits(sampleBanks), 181);
});

test('filterBloodBanks filters by query, zone, and available blood group stock', () => {
  assert.equal(filterBloodBanks(sampleBanks, '', 'all', 'all').length, 2);
  assert.equal(filterBloodBanks(sampleBanks, 'red cross', 'all', 'all').length, 1);
  assert.equal(filterBloodBanks(sampleBanks, '', 'O-', 'all').length, 1);
  assert.equal(filterBloodBanks(sampleBanks, '', 'B-', 'Cyber Zone').length, 0);
  assert.equal(filterBloodBanks(sampleBanks, '', 'A+', 'Cyber Zone').length, 1);
});

test('validateBloodRequest rejects missing fields and accepts valid requests', () => {
  const bad = validateBloodRequest({
    patientName: '',
    bloodGroup: 'O-',
    unitsNeeded: 0,
    hospitalName: '',
    contactName: '',
    contactPhone: '123'
  });
  assert.equal(bad.valid, false);
  assert.ok(bad.errors.patientName);
  assert.ok(bad.errors.unitsNeeded);
  assert.ok(bad.errors.hospitalName);
  assert.ok(bad.errors.contactName);
  assert.ok(bad.errors.contactPhone);

  const good = validateBloodRequest({
    patientName: 'Ramesh Naidu',
    bloodGroup: 'O-',
    unitsNeeded: 2,
    urgency: 'Emergency',
    hospitalName: 'Central Govt Hospital',
    contactName: 'Suresh Naidu',
    contactPhone: '+91 98480 11223'
  });
  assert.equal(good.valid, true);
  assert.deepEqual(good.errors, {});
});

test('donor eligibility and donation validation enforce age, weight, and interval rules', () => {
  const tooYoung = checkDonorEligibility({ age: 16, weightKg: 60 });
  assert.equal(tooYoung.eligible, false);
  assert.equal(tooYoung.reasons.length, 1);

  const underweightAndRecent = checkDonorEligibility({ age: 25, weightKg: 45, monthsSinceLastDonation: 1 });
  assert.equal(underweightAndRecent.eligible, false);
  assert.equal(underweightAndRecent.reasons.length, 2);

  const badDonation = validateBloodDonation({
    donorName: 'A',
    bloodGroup: 'A+',
    age: 17,
    weightKg: 48,
    phone: 'bad',
    preferredBankId: '',
    preferredDate: ''
  });
  assert.equal(badDonation.valid, false);
  assert.ok(badDonation.errors.donorName);
  assert.ok(badDonation.errors.age);
  assert.ok(badDonation.errors.weightKg);
  assert.ok(badDonation.errors.phone);

  const goodDonation = validateBloodDonation({
    donorName: 'Kavitha Reddy',
    bloodGroup: 'A+',
    age: 28,
    weightKg: 60,
    phone: '9848055667',
    preferredBankId: 'bb-1',
    preferredDate: '2026-11-22',
    preferredSlot: '10:00 AM - 12:00 PM'
  });
  assert.equal(goodDonation.valid, true);
});
