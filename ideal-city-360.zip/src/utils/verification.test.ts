import test from 'node:test';
import assert from 'node:assert/strict';
import { 
  checkExpiration, 
  calculateCityWellBeingIndex, 
  formatRelativeTime, 
  processVerificationStatus, 
  filterByVerification,
  searchRecords
} from './verification';
import { CityWellBeingMetric, VerificationMeta } from '../types';

test('checkExpiration identifies past dates as expired', () => {
  const pastDate = '2020-01-01T00:00:00Z';
  const result = checkExpiration(pastDate);
  assert.equal(result.isExpired, true);
  assert.ok(result.daysRemaining !== null && result.daysRemaining < 0);
});

test('checkExpiration identifies future dates as not expired', () => {
  const futureDate = '2099-01-01T00:00:00Z';
  const result = checkExpiration(futureDate);
  assert.equal(result.isExpired, false);
  assert.ok(result.daysRemaining !== null && result.daysRemaining > 0);
});

test('checkExpiration handles undefined validUntil gracefully', () => {
  const result = checkExpiration(undefined);
  assert.equal(result.isExpired, false);
  assert.equal(result.daysRemaining, null);
});

test('calculateCityWellBeingIndex computes correct average and grade', () => {
  const metrics: CityWellBeingMetric[] = [
    {
      id: '1',
      category: 'Health',
      name: 'Healthcare Access',
      score: 90,
      target: 95,
      unit: '%',
      status: 'Excellent',
      trend: 'up',
      historicalData: [],
      keyHighlights: ['ICU Beds increased']
    },
    {
      id: '2',
      category: 'Safety',
      name: 'City Safety Index',
      score: 92,
      target: 90,
      unit: '%',
      status: 'Excellent',
      trend: 'up',
      historicalData: [],
      keyHighlights: ['CCTV coverage expanded']
    },
    {
      id: '3',
      category: 'Transport',
      name: 'On-time Transit',
      score: 76,
      target: 85,
      unit: '%',
      status: 'Good',
      trend: 'stable',
      historicalData: [],
      keyHighlights: ['Smart bus fleet added']
    }
  ];

  const result = calculateCityWellBeingIndex(metrics);
  // (90 + 92 + 76) / 3 = 86
  assert.equal(result.overallScore, 86);
  assert.equal(result.grade, 'A');
  assert.equal(result.totalMonitored, 3);
  assert.equal(result.statusSummary.excellent, 2);
  assert.equal(result.statusSummary.good, 1);
});

test('processVerificationStatus auto-expires records with past validUntil date', () => {
  const sampleMeta: VerificationMeta = {
    sourceName: 'Department of Health',
    sourceUrl: 'https://health.gov.in',
    createdDate: '2025-01-01',
    lastUpdated: '2025-01-01',
    verificationStatus: 'Verified',
    validUntil: '2025-02-01T00:00:00Z',
    verifiedBy: 'Chief Health Officer',
    isDemoData: true,
    updateHistory: []
  };

  const item = { id: 'sample-1', title: 'Free Health Camp', verification: sampleMeta };
  const processed = processVerificationStatus(item);
  assert.equal(processed.verification.verificationStatus, 'Expired');
});

test('searchRecords matches terms in specified fields', () => {
  const items = [
    { id: '1', name: 'Apollo Super Specialty Hospital', area: 'Central Zone', facilities: ['Emergency', 'ICU', 'Cardiology'] },
    { id: '2', name: 'City Civil Hospital', area: 'East Zone', facilities: ['OPD', 'Pediatrics'] },
    { id: '3', name: 'Sunrise Medicare Care', area: 'South Hub', facilities: ['Dialysis', 'Diagnostics'] }
  ];

  const cardioMatches = searchRecords(items, 'cardiology', ['name', 'facilities']);
  assert.equal(cardioMatches.length, 1);
  assert.equal(cardioMatches[0].id, '1');

  const zoneMatches = searchRecords(items, 'East', ['area']);
  assert.equal(zoneMatches.length, 1);
  assert.equal(zoneMatches[0].id, '2');
});
