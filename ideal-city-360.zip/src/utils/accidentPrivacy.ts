import crypto from 'node:crypto';
import type { AccidentReport } from '../types.ts';

export const RETENTION_POLICY_DAYS = 30;

export const PRIVACY_ASSURANCE_MESSAGE =
  'Your identity is protected. We share only the accident information and location necessary for emergency response. Your personal information is not disclosed to emergency authorities.';

export const FORBIDDEN_PII_KEYS = [
  'reporterId',
  'reporterName',
  'reporterEmail',
  'reporterPhone',
  'userName',
  'username',
  'accountId',
  'fullName',
  'email',
  'mobileNumber',
  'phoneNumber',
  'profilePhoto',
  'residentialAddress',
  'address',
  'ipAddress',
  'ip',
  'userAgent',
  'deviceId',
  'deviceInfo',
] as const;

/**
 * Strips EXIF (APP1), ICC/IPTC/XMP/Adobe/APPn (APP1..APP15, 0xFFE1..0xFFEF)
 * and Comment (COM, 0xFFFE) segments from a JPEG byte stream while preserving
 * SOI, APP0 (JFIF), DQT, DHT, SOF, DRI, SOS image data, and EOI.
 */
export function stripExifFromJpegBytes(bytes: Uint8Array): {
  cleaned: Uint8Array;
  removedSegments: number;
  hadExif: boolean;
} {
  // Check JPEG SOI marker (0xFF 0xD8)
  if (bytes.length < 4 || bytes[0] !== 0xff || bytes[1] !== 0xd8) {
    return { cleaned: bytes, removedSegments: 0, hadExif: false };
  }

  const outChunks: Uint8Array[] = [bytes.slice(0, 2)];
  let offset = 2;
  let removedSegments = 0;
  let hadExif = false;

  while (offset < bytes.length) {
    if (bytes[offset] !== 0xff) {
      // Unexpected byte; append remainder safely
      outChunks.push(bytes.slice(offset));
      break;
    }

    // Skip fill 0xFF padding bytes
    let markerStart = offset;
    while (offset < bytes.length && bytes[offset] === 0xff) {
      offset++;
    }
    if (offset >= bytes.length) {
      outChunks.push(bytes.slice(markerStart));
      break;
    }

    const marker = bytes[offset];
    offset++;

    // Start of Scan (0xDA) or End of Image (0xD9): keep rest of compressed image stream verbatim
    if (marker === 0xda || marker === 0xd9) {
      outChunks.push(bytes.slice(markerStart));
      break;
    }

    // Standalone markers without length (RST0..RST7 = 0xD0..0xD7, TEM = 0x01)
    if ((marker >= 0xd0 && marker <= 0xd7) || marker === 0x01) {
      outChunks.push(bytes.slice(markerStart, offset));
      continue;
    }

    if (offset + 2 > bytes.length) {
      outChunks.push(bytes.slice(markerStart));
      break;
    }

    const segmentLength = (bytes[offset] << 8) | bytes[offset + 1];
    const segmentEnd = offset + segmentLength;

    if (segmentLength < 2 || segmentEnd > bytes.length) {
      outChunks.push(bytes.slice(markerStart));
      break;
    }

    // Strip APP1..APP15 (0xE1..0xEF: EXIF, GPS, XMP, camera maker notes) and COM (0xFE)
    const isMetadataSegment =
      (marker >= 0xe1 && marker <= 0xef) || marker === 0xfe;

    if (isMetadataSegment) {
      removedSegments++;
      if (marker === 0xe1) {
        hadExif = true;
      }
    } else {
      outChunks.push(bytes.slice(markerStart, segmentEnd));
    }

    offset = segmentEnd;
  }

  const totalLen = outChunks.reduce((sum, c) => sum + c.length, 0);
  const cleaned = new Uint8Array(totalLen);
  let cursor = 0;
  for (const chunk of outChunks) {
    cleaned.set(chunk, cursor);
    cursor += chunk.length;
  }

  return { cleaned, removedSegments, hadExif };
}

/**
 * Strips PNG text/EXIF ancillary metadata chunks (tEXt, zTXt, iTXt, eXIf, tIME)
 * while preserving critical chunks (IHDR, PLTE, IDAT, IEND) and safe rendering chunks.
 */
export function stripMetadataFromPngBytes(bytes: Uint8Array): {
  cleaned: Uint8Array;
  removedSegments: number;
  hadExif: boolean;
} {
  const PNG_SIG = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];
  if (bytes.length < 16 || !PNG_SIG.every((b, idx) => bytes[idx] === b)) {
    return { cleaned: bytes, removedSegments: 0, hadExif: false };
  }

  const STRIP_CHUNKS = new Set(['tEXt', 'zTXt', 'iTXt', 'eXIf', 'tIME']);
  const outChunks: Uint8Array[] = [bytes.slice(0, 8)];
  let offset = 8;
  let removedSegments = 0;
  let hadExif = false;

  while (offset + 12 <= bytes.length) {
    const length =
      ((bytes[offset] << 24) |
        (bytes[offset + 1] << 16) |
        (bytes[offset + 2] << 8) |
        bytes[offset + 3]) >>>
      0;
    const type = String.fromCharCode(
      bytes[offset + 4],
      bytes[offset + 5],
      bytes[offset + 6],
      bytes[offset + 7]
    );
    const chunkEnd = offset + 12 + length;
    if (chunkEnd > bytes.length) {
      outChunks.push(bytes.slice(offset));
      break;
    }

    if (STRIP_CHUNKS.has(type)) {
      removedSegments++;
      if (type === 'eXIf') hadExif = true;
    } else {
      outChunks.push(bytes.slice(offset, chunkEnd));
    }

    offset = chunkEnd;
    if (type === 'IEND') break;
  }

  const totalLen = outChunks.reduce((sum, c) => sum + c.length, 0);
  const cleaned = new Uint8Array(totalLen);
  let cursor = 0;
  for (const c of outChunks) {
    cleaned.set(c, cursor);
    cursor += c.length;
  }
  return { cleaned, removedSegments, hadExif };
}

export function stripImageMetadataBuffer(
  buffer: Buffer,
  mimeType: string
): { cleaned: Buffer; removedSegments: number; hadExif: boolean } {
  const bytes = new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength);
  if (mimeType === 'image/png') {
    const res = stripMetadataFromPngBytes(bytes);
    return {
      cleaned: Buffer.from(res.cleaned),
      removedSegments: res.removedSegments,
      hadExif: res.hadExif,
    };
  }
  const res = stripExifFromJpegBytes(bytes);
  return {
    cleaned: Buffer.from(res.cleaned),
    removedSegments: res.removedSegments,
    hadExif: res.hadExif,
  };
}

export function generateSecureReportId(year = new Date().getFullYear()): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const randomBytes = crypto.randomBytes(6);
  let suffix = '';
  for (let i = 0; i < 6; i++) {
    suffix += alphabet[randomBytes[i] % alphabet.length];
  }
  return `ACC-${year}-${suffix}`;
}

export function generateSecureTrackingToken(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const raw = crypto.randomBytes(16);
  const groups: string[] = [];
  for (let g = 0; g < 4; g++) {
    let chunk = '';
    for (let i = 0; i < 4; i++) {
      chunk += alphabet[raw[g * 4 + i] % alphabet.length];
    }
    groups.push(chunk);
  }
  return `TRK-${groups.join('-')}`;
}

export function generateOpaqueMediaId(): string {
  return `med-${crypto.randomBytes(16).toString('hex')}`;
}

export function hashTrackingToken(token: string): string {
  return crypto
    .createHash('sha256')
    .update(token.trim().toUpperCase())
    .digest('hex');
}

export function verifyTrackingTokenHash(
  candidateToken: string,
  expectedHashHex: string
): boolean {
  if (!candidateToken || !expectedHashHex) return false;
  const candidateHash = Buffer.from(hashTrackingToken(candidateToken), 'hex');
  const expectedBuf = Buffer.from(expectedHashHex, 'hex');
  if (candidateHash.length !== expectedBuf.length) return false;
  return crypto.timingSafeEqual(candidateHash, expectedBuf);
}

export interface EncryptedBlob {
  ciphertext: Buffer;
  iv: Buffer;
  authTag: Buffer;
}

export function encryptBuffer(plaintext: Buffer, key32: Buffer): EncryptedBlob {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key32, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return { ciphertext, iv, authTag };
}

export function decryptBuffer(blob: EncryptedBlob, key32: Buffer): Buffer {
  const decipher = crypto.createDecipheriv('aes-256-gcm', key32, blob.iv);
  decipher.setAuthTag(blob.authTag);
  return Buffer.concat([decipher.update(blob.ciphertext), decipher.final()]);
}

export function computeRetentionExpiryIso(
  createdAtIso: string,
  retentionDays = RETENTION_POLICY_DAYS
): string {
  const base = new Date(createdAtIso).getTime();
  const safeBase = Number.isFinite(base) ? base : Date.now();
  return new Date(safeBase + retentionDays * 24 * 60 * 60 * 1000).toISOString();
}

export function isIncidentRetentionExpired(
  retentionExpiresAt: string,
  nowMs = Date.now()
): boolean {
  const expiry = new Date(retentionExpiresAt).getTime();
  if (!Number.isFinite(expiry)) return false;
  return nowMs >= expiry;
}

export function buildAnonymousAuthorityAlertMessage(params: {
  incidentCode: string;
  accidentType: string;
  severity: string;
  latitude: number;
  longitude: number;
  googleMapsUrl: string;
  incidentDate: string;
  incidentTime: string;
  securePhotoUrl: string;
  possibleInjuredCount: number | null;
  optionalCallbackPhone?: string;
}): string {
  const lines = [
    'NEW ROAD ACCIDENT ALERT',
    '',
    `Report ID: ${params.incidentCode}`,
    `Accident Type: Possible ${params.accidentType}`,
    `Severity: ${params.severity} – AI Estimate (Requires Human Assessment)`,
    `Location: ${params.latitude.toFixed(5)}, ${params.longitude.toFixed(5)}`,
    `Map: ${params.googleMapsUrl}`,
    `Reported At: ${params.incidentDate} ${params.incidentTime}`,
    `Possible Injured: ${params.possibleInjuredCount !== null ? params.possibleInjuredCount : 'Unknown'}`,
    `Photograph: ${params.securePhotoUrl} (Authorized Emergency Access Only)`,
    '',
    params.optionalCallbackPhone
      ? `Reporter Identity: Anonymous (Optional Callback Consented: ${params.optionalCallbackPhone})`
      : 'Reporter Identity: Anonymous',
  ];
  return lines.join('\n');
}

/**
 * Defensive privacy assertion: strips any forbidden PII keys from an emergency incident
 * object before storage or transmission to authorities/tracking APIs.
 */
export function sanitizeEmergencyIncidentRecord<T extends Record<string, any>>(
  record: T
): Omit<T, (typeof FORBIDDEN_PII_KEYS)[number]> {
  const clone: Record<string, any> = { ...record };
  for (const forbiddenKey of FORBIDDEN_PII_KEYS) {
    if (forbiddenKey in clone) {
      delete clone[forbiddenKey];
    }
  }
  return clone as Omit<T, (typeof FORBIDDEN_PII_KEYS)[number]>;
}

export function hasAnyForbiddenPiiKey(obj: Record<string, any>): string[] {
  return FORBIDDEN_PII_KEYS.filter(
    (key) => key in obj && obj[key] !== undefined && obj[key] !== null
  );
}

export function filterActiveRetentionIncidents(
  reports: AccidentReport[],
  nowMs = Date.now()
): AccidentReport[] {
  return reports.filter(
    (r) => !isIncidentRetentionExpired(r.retentionExpiresAt, nowMs)
  );
}
