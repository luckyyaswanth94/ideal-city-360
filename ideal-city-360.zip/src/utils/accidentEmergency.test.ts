import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildGoogleMapsDirectionsUrl,
  buildGoogleMapsUrl,
  buildScopedMediaUrl,
  canRoleAccessAuthorityDashboard,
  canRoleUpdateAgency,
  computeShortestRoute,
  deriveOverallAccidentStatus,
  findNearestAmbulanceUnit,
  findNearestHospitals,
  findNearestPoliceStation,
  formatSafeIncidentDescription,
  haversineDistanceKm,
  validateAccidentSubmission,
} from './accidentEmergency.ts';
import type { AmbulanceUnit, Hospital, PoliceStation } from '../types.ts';

const mockHospitals: Hospital[] = [
  {
    id: 'hosp-a',
    name: 'Central Trauma Hospital',
    type: 'Government Super-Specialty',
    address: 'Sector 4',
    phone: '040-1111',
    emergencyPhone: '108',
    location: { lat: 17.4065, lng: 78.4772, area: 'Central Zone' },
    facilities: ['24x7 Trauma Care'],
    bedCount: { total: 500, available: 50, icu: 10 },
    rating: 4.8,
    openHours: '24h',
    verification: {
      sourceName: 'Test',
      sourceUrl: 'https://example.com',
      createdDate: '2026-01-01',
      lastUpdated: '2026-01-01',
      verificationStatus: 'Verified',
      isDemoData: true,
      updateHistory: [],
    },
  },
  {
    id: 'hosp-b',
    name: 'Cyber Corridor Hospital',
    type: 'Private Multi-Specialty',
    address: 'Jubilee Valley',
    phone: '040-2222',
    emergencyPhone: '1066',
    location: { lat: 17.4258, lng: 78.4116, area: 'Cyber Zone' },
    facilities: ['Trauma Care'],
    bedCount: { total: 400, available: 30, icu: 8 },
    rating: 4.9,
    openHours: '24h',
    verification: {
      sourceName: 'Test',
      sourceUrl: 'https://example.com',
      createdDate: '2026-01-01',
      lastUpdated: '2026-01-01',
      verificationStatus: 'Verified',
      isDemoData: true,
      updateHistory: [],
    },
  },
];

const mockAmbulances: AmbulanceUnit[] = [
  {
    id: 'amb-1',
    callSign: 'EMS-108-CYBER',
    stationName: 'Cyber Zone Trauma Base',
    zone: 'Cyber Zone',
    phone: '108',
    vehicleNumber: 'TS-09-EM-1081',
    type: 'ALS Trauma ICU',
    lat: 17.424,
    lng: 78.415,
    status: 'Available',
  },
  {
    id: 'amb-2',
    callSign: 'EMS-108-CENTRAL',
    stationName: 'Central Hub',
    zone: 'Central Zone',
    phone: '108',
    vehicleNumber: 'TS-09-EM-1082',
    type: 'ALS Trauma ICU',
    lat: 17.405,
    lng: 78.478,
    status: 'Dispatched',
  },
];

const mockPolice: PoliceStation[] = [
  {
    id: 'pol-1',
    name: 'Cyber Zone Traffic Police Station',
    zone: 'Cyber Zone',
    address: 'HITEC Arterial',
    phone: '040-2785-3300',
    controlRoomPhone: '100',
    lat: 17.429,
    lng: 78.409,
    officerInCharge: 'Inspector Rajesh',
  },
  {
    id: 'pol-2',
    name: 'Central Zone Police Station',
    zone: 'Central Zone',
    address: 'Tank Bund Road',
    phone: '040-2785-4400',
    controlRoomPhone: '100',
    lat: 17.407,
    lng: 78.476,
    officerInCharge: 'Inspector Kavitha',
  },
];

test('validateAccidentSubmission rejects unconfirmed image submission', () => {
  const result = validateAccidentSubmission({
    photoDataUrl: 'data:image/jpeg;base64,abc123',
    latitude: 17.42,
    longitude: 78.41,
    accidentType: 'Bike Accident',
    severity: 'Critical',
    reporterConfirmed: false,
  });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => /confirmation/i.test(e)));
});

test('validateAccidentSubmission accepts anonymous report with zero PII and blocks unconsented callback phone', () => {
  const okAnon = validateAccidentSubmission({
    photoDataUrl: '/assets/accidents/bike-car-collision.jpg',
    latitude: 17.4245,
    longitude: 78.4142,
    accidentType: 'Two-Wheeler & Car Collision',
    severity: 'Medium',
    possibleInjuredCount: 2,
    reporterConfirmed: true,
  });
  assert.equal(okAnon.valid, true);

  const unconsentedCallback = validateAccidentSubmission({
    photoDataUrl: 'data:image/jpeg;base64,abc123',
    latitude: 17.42,
    longitude: 78.41,
    accidentType: 'Car Collision',
    severity: 'Medium',
    reporterConfirmed: true,
    optionalCallbackPhone: '+91 98480 12345',
    optionalCallbackConsented: false,
  });
  assert.equal(unconsentedCallback.valid, false);
  assert.ok(unconsentedCallback.errors.some((e) => /explicit consent/i.test(e)));

  const consentedCallback = validateAccidentSubmission({
    photoDataUrl: 'data:image/jpeg;base64,abc123',
    latitude: 17.42,
    longitude: 78.41,
    accidentType: 'Car Collision',
    severity: 'Medium',
    reporterConfirmed: true,
    optionalCallbackPhone: '+91 98480 12345',
    optionalCallbackConsented: true,
  });
  assert.equal(consentedCallback.valid, true);
});

test('findNearestHospitals, ambulance, and police rank accurately by geospatial distance', () => {
  const incidentLat = 17.425;
  const incidentLng = 78.412;

  const hospitals = findNearestHospitals(mockHospitals, incidentLat, incidentLng, 2);
  assert.equal(hospitals[0].hospital.id, 'hosp-b');
  assert.ok(hospitals[0].distanceKm < hospitals[1].distanceKm);

  const nearestAmb = findNearestAmbulanceUnit(mockAmbulances, 17.406, 78.477);
  assert.equal(nearestAmb?.unit.id, 'amb-1');

  const nearestPol = findNearestPoliceStation(mockPolice, incidentLat, incidentLng);
  assert.equal(nearestPol?.station.id, 'pol-1');
});

test('computeShortestRoute returns valid multi-point polyline, road distance, and positive ETA', () => {
  const route = computeShortestRoute(
    { lat: 17.424, lng: 78.415 },
    { lat: 17.4065, lng: 78.4772 }
  );
  assert.equal(route.waypoints.length, 5);
  assert.equal(route.waypoints[0].lat, 17.424);
  assert.equal(route.waypoints[4].lng, 78.4772);
  assert.ok(route.routeDistanceKm >= haversineDistanceKm(17.424, 78.415, 17.4065, 78.4772));
  assert.ok(route.estimatedEtaMinutes >= 3);
});

test('Google Maps URL builders and scoped media URL helper format properly', () => {
  assert.equal(
    buildGoogleMapsUrl(17.425812, 78.411645),
    'https://www.google.com/maps?q=17.425812,78.411645'
  );
  assert.match(
    buildGoogleMapsDirectionsUrl(17.424, 78.415, 17.4065, 78.4772),
    /^https:\/\/www\.google\.com\/maps\/dir\/\?api=1&origin=17\.424000,78\.415000&destination=17\.406500,78\.477200&travelmode=driving$/
  );
  assert.equal(
    buildScopedMediaUrl('/api/accidents/media/med-1', 'ACC-2026-AA11BB', 'TRK-1111-2222-3333-4444'),
    '/api/accidents/media/med-1?reportCode=ACC-2026-AA11BB&token=TRK-1111-2222-3333-4444'
  );
});

test('formatSafeIncidentDescription enforces human-assessment disclaimer and GPS coordinates', () => {
  const desc = formatSafeIncidentDescription(
    'Possible two-wheeler and car collision detected. Visible vehicle damage.',
    17.4251,
    78.4123
  );
  assert.match(desc, /human assessment/i);
  assert.match(desc, /17\.42510, 78\.41230/);
});

test('RBAC helpers restrict authority updates and status derivation works', () => {
  assert.equal(canRoleAccessAuthorityDashboard('citizen'), false);
  assert.equal(canRoleAccessAuthorityDashboard('hospital_admin'), true);
  assert.equal(canRoleAccessAuthorityDashboard('ambulance_service'), true);
  assert.equal(canRoleAccessAuthorityDashboard('police_officer'), true);
  assert.equal(canRoleAccessAuthorityDashboard('super_admin'), true);

  assert.equal(canRoleUpdateAgency('citizen', 'police'), false);
  assert.equal(canRoleUpdateAgency('hospital_admin', 'hospital'), true);
  assert.equal(canRoleUpdateAgency('hospital_admin', 'police'), false);
  assert.equal(canRoleUpdateAgency('ambulance_service', 'ambulance'), true);
  assert.equal(canRoleUpdateAgency('police_officer', 'police'), true);
  assert.equal(canRoleUpdateAgency('police_officer', 'overall'), true);

  const status = deriveOverallAccidentStatus({
    overallStatus: 'Active Emergency',
    notifiedHospitals: [],
    ambulanceDispatch: {
      unitId: 'a',
      callSign: 'EMS',
      stationName: 'Base',
      vehicleNumber: 'V',
      phone: '108',
      originLat: 17.4,
      originLng: 78.4,
      distanceKm: 1,
      etaMinutes: 4,
      routeWaypoints: [],
      status: 'En Route',
      deliveryConfirmed: true,
      deliveryMode: 'demo_simulated',
      notifiedAt: '2026-11-19T00:00:00Z',
      updatedAt: '2026-11-19T00:00:00Z',
    },
    policeDispatch: {
      stationId: 'p',
      stationName: 'PS',
      zone: 'Z',
      phone: '100',
      lat: 17.4,
      lng: 78.4,
      distanceKm: 1,
      status: 'Notified',
      deliveryConfirmed: true,
      deliveryMode: 'demo_simulated',
      notifiedAt: '2026-11-19T00:00:00Z',
      updatedAt: '2026-11-19T00:00:00Z',
    },
  });
  assert.equal(status, 'Response Dispatched');
});
