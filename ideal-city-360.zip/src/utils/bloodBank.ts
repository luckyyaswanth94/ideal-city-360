import type { BloodBank, BloodGroup } from '../types';

export const BLOOD_GROUPS: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

const COMPATIBLE_DONORS: Record<BloodGroup, BloodGroup[]> = {
  'O-': ['O-'],
  'O+': ['O-', 'O+'],
  'A-': ['O-', 'A-'],
  'A+': ['O-', 'O+', 'A-', 'A+'],
  'B-': ['O-', 'B-'],
  'B+': ['O-', 'O+', 'B-', 'B+'],
  'AB-': ['O-', 'A-', 'B-', 'AB-'],
  'AB+': ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+']
};

export function getCompatibleDonorGroups(recipientGroup: BloodGroup): BloodGroup[] {
  return [...COMPATIBLE_DONORS[recipientGroup]];
}

export function isCompatibleDonor(donorGroup: BloodGroup, recipientGroup: BloodGroup): boolean {
  return COMPATIBLE_DONORS[recipientGroup].includes(donorGroup);
}

export type StockLevelStatus = 'Critical' | 'Low' | 'Available';

export function getStockLevelStatus(units: number): StockLevelStatus {
  if (units <= 3) return 'Critical';
  if (units <= 10) return 'Low';
  return 'Available';
}

export function getTotalUnitsByGroup(banks: BloodBank[]): Record<BloodGroup, number> {
  const totals: Record<BloodGroup, number> = {
    'A+': 0,
    'A-': 0,
    'B+': 0,
    'B-': 0,
    'AB+': 0,
    'AB-': 0,
    'O+': 0,
    'O-': 0
  };
  for (const bank of banks) {
    for (const group of BLOOD_GROUPS) {
      totals[group] += Math.max(0, bank.inventory[group] ?? 0);
    }
  }
  return totals;
}

export function getTotalCityUnits(banks: BloodBank[]): number {
  const byGroup = getTotalUnitsByGroup(banks);
  return BLOOD_GROUPS.reduce((sum, g) => sum + byGroup[g], 0);
}

export function filterBloodBanks(
  banks: BloodBank[],
  searchQuery: string,
  bloodGroup: BloodGroup | 'all',
  zone: string
): BloodBank[] {
  const q = searchQuery.trim().toLowerCase();
  return banks.filter(bank => {
    const matchesSearch =
      !q ||
      bank.name.toLowerCase().includes(q) ||
      bank.address.toLowerCase().includes(q) ||
      bank.zone.toLowerCase().includes(q) ||
      bank.licenseNumber.toLowerCase().includes(q);
    const matchesZone = zone === 'all' || bank.zone === zone;
    const matchesGroup = bloodGroup === 'all' || (bank.inventory[bloodGroup] ?? 0) > 0;
    return matchesSearch && matchesZone && matchesGroup;
  });
}

export interface BloodRequestInput {
  patientName: string;
  bloodGroup: BloodGroup;
  unitsNeeded: number;
  urgency: 'Emergency' | 'Urgent' | 'Scheduled';
  hospitalName: string;
  contactName: string;
  contactPhone: string;
  notes?: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

const PHONE_REGEX = /^[+\d][\d\s-]{8,16}$/;

export function validateBloodRequest(input: Partial<BloodRequestInput>): ValidationResult {
  const errors: Record<string, string> = {};

  if (!input.patientName || input.patientName.trim().length < 2) {
    errors.patientName = 'Patient full name is required (min 2 characters).';
  }
  if (!input.bloodGroup || !BLOOD_GROUPS.includes(input.bloodGroup)) {
    errors.bloodGroup = 'Select a valid blood group.';
  }
  if (typeof input.unitsNeeded !== 'number' || Number.isNaN(input.unitsNeeded) || input.unitsNeeded < 1 || input.unitsNeeded > 10) {
    errors.unitsNeeded = 'Units needed must be between 1 and 10.';
  }
  if (!input.hospitalName || input.hospitalName.trim().length < 3) {
    errors.hospitalName = 'Hospital or clinical facility name is required.';
  }
  if (!input.contactName || input.contactName.trim().length < 2) {
    errors.contactName = 'Attendant / contact person name is required.';
  }
  if (!input.contactPhone || !PHONE_REGEX.test(input.contactPhone.trim())) {
    errors.contactPhone = 'Enter a valid 10-digit contact phone number.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors
  };
}

export interface BloodDonationInput {
  donorName: string;
  bloodGroup: BloodGroup;
  age: number;
  weightKg: number;
  phone: string;
  email?: string;
  preferredBankId: string;
  preferredDate: string;
  preferredSlot: string;
  monthsSinceLastDonation?: number;
}

export function checkDonorEligibility(params: {
  age: number;
  weightKg: number;
  monthsSinceLastDonation?: number;
}): { eligible: boolean; reasons: string[] } {
  const reasons: string[] = [];
  if (Number.isNaN(params.age) || params.age < 18 || params.age > 65) {
    reasons.push('Donor age must be between 18 and 65 years.');
  }
  if (Number.isNaN(params.weightKg) || params.weightKg < 50) {
    reasons.push('Donor weight must be at least 50 kg.');
  }
  if (
    typeof params.monthsSinceLastDonation === 'number' &&
    !Number.isNaN(params.monthsSinceLastDonation) &&
    params.monthsSinceLastDonation >= 0 &&
    params.monthsSinceLastDonation < 3
  ) {
    reasons.push('At least 3 months must have elapsed since your previous whole blood donation.');
  }
  return {
    eligible: reasons.length === 0,
    reasons
  };
}

export function validateBloodDonation(input: Partial<BloodDonationInput>): ValidationResult {
  const errors: Record<string, string> = {};

  if (!input.donorName || input.donorName.trim().length < 2) {
    errors.donorName = 'Donor full name is required (min 2 characters).';
  }
  if (!input.bloodGroup || !BLOOD_GROUPS.includes(input.bloodGroup)) {
    errors.bloodGroup = 'Select a valid blood group.';
  }
  if (typeof input.age !== 'number' || Number.isNaN(input.age) || input.age < 18 || input.age > 65) {
    errors.age = 'Eligible donors must be between 18 and 65 years old.';
  }
  if (typeof input.weightKg !== 'number' || Number.isNaN(input.weightKg) || input.weightKg < 50) {
    errors.weightKg = 'Minimum donor weight requirement is 50 kg.';
  }
  if (
    typeof input.monthsSinceLastDonation === 'number' &&
    !Number.isNaN(input.monthsSinceLastDonation) &&
    input.monthsSinceLastDonation >= 0 &&
    input.monthsSinceLastDonation < 3
  ) {
    errors.monthsSinceLastDonation = 'Wait at least 3 months between whole blood donations.';
  }
  if (!input.phone || !PHONE_REGEX.test(input.phone.trim())) {
    errors.phone = 'Enter a valid contact phone number.';
  }
  if (!input.preferredBankId || !input.preferredBankId.trim()) {
    errors.preferredBankId = 'Choose a preferred blood bank center.';
  }
  if (!input.preferredDate || !input.preferredDate.trim()) {
    errors.preferredDate = 'Select a preferred donation date.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors
  };
}
