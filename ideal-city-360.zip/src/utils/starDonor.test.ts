import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getStarDonorBadge,
  buildDonorLeaderboard,
  getCitizenDonationSummary
} from './starDonor';
import type { BloodDonationPledge, DonorLeaderboardEntry, User } from '../types';

const citizen: User = {
  id: 'usr-1',
  name: 'Srinivas Rao',
  email: 'citizen@idealcity360.gov.in',
  role: 'citizen',
  bloodGroup: 'O+',
  totalDonations: 5,
  zone: 'Cyber Zone',
  savedItemIds: [],
  subscribedCategories: []
};

const baseEntries: DonorLeaderboardEntry[] = [
  {
    id: 'ldr-1',
    name: 'Dr. Kavya Menon',
    email: 'kavya@idealcity.in',
    bloodGroup: 'O-',
    zone: 'Central Zone',
    totalDonations: 12,
    lastDonationDate: '2026-10-15',
    verified: true
  },
  {
    id: 'ldr-2',
    name: 'Srinivas Rao',
    email: 'citizen@idealcity360.gov.in',
    bloodGroup: 'O+',
    zone: 'Cyber Zone',
    totalDonations: 5,
    lastDonationDate: '2026-09-20',
    verified: true
  },
  {
    id: 'ldr-3',
    name: 'Arjun Verma',
    email: 'arjun@idealcity.in',
    bloodGroup: 'A+',
    zone: 'North Zone',
    totalDonations: 6,
    lastDonationDate: '2026-10-01',
    verified: true
  }
];

test('getStarDonorBadge assigns exact tiers, stars, lives saved, and progress', () => {
  const zero = getStarDonorBadge(0);
  assert.equal(zero.tier.id, 'new');
  assert.equal(zero.isStarDonor, false);
  assert.equal(zero.donationsToNextTier, 1);
  assert.equal(zero.livesImpacted, 0);

  const bronze = getStarDonorBadge(2);
  assert.equal(bronze.tier.id, 'bronze');
  assert.equal(bronze.tier.stars, 1);
  assert.equal(bronze.donationsToNextTier, 1);
  assert.equal(bronze.progressPercent, 50);

  const silver = getStarDonorBadge(3);
  assert.equal(silver.tier.id, 'silver');
  assert.equal(silver.tier.stars, 2);
  assert.equal(silver.donationsToNextTier, 2);

  const gold = getStarDonorBadge(5);
  assert.equal(gold.tier.id, 'gold');
  assert.equal(gold.tier.stars, 3);
  assert.equal(gold.livesImpacted, 15);
  assert.equal(gold.donationsToNextTier, 5);

  const platinum = getStarDonorBadge(10);
  assert.equal(platinum.tier.id, 'platinum');
  assert.equal(platinum.tier.stars, 5);
  assert.equal(platinum.progressPercent, 100);
  assert.equal(platinum.donationsToNextTier, 0);
});

test('buildDonorLeaderboard ranks donors accurately and updates when a donation is completed', () => {
  const scheduledOnly: BloodDonationPledge[] = [
    {
      id: 'd1',
      pledgeCode: 'BLD-DON-1',
      donorName: 'Srinivas Rao',
      bloodGroup: 'O+',
      age: 32,
      weightKg: 71,
      phone: '9848012345',
      email: 'citizen@idealcity360.gov.in',
      preferredBankId: 'bb-1',
      preferredBankName: 'Central Bank',
      preferredDate: '2026-11-21',
      preferredSlot: '10:00 AM',
      status: 'Scheduled',
      createdAt: '2026-11-18T10:00:00Z'
    }
  ];

  const boardBefore = buildDonorLeaderboard(baseEntries, scheduledOnly, citizen);
  assert.equal(boardBefore[0].name, 'Dr. Kavya Menon');
  assert.equal(boardBefore[1].name, 'Arjun Verma');
  assert.equal(boardBefore[2].name, 'Srinivas Rao');
  assert.equal(boardBefore[2].rank, 3);
  assert.equal(boardBefore[2].isCurrentUser, true);

  // Mark two pledges as Completed -> Srinivas moves to 7 donations and overtakes Arjun (6)!
  const completedPledges: BloodDonationPledge[] = [
    { ...scheduledOnly[0], status: 'Completed' },
    { ...scheduledOnly[0], id: 'd2', pledgeCode: 'BLD-DON-2', preferredDate: '2026-11-25', status: 'Completed' }
  ];

  const boardAfter = buildDonorLeaderboard(baseEntries, completedPledges, citizen);
  assert.equal(boardAfter[1].name, 'Srinivas Rao');
  assert.equal(boardAfter[1].totalDonations, 7);
  assert.equal(boardAfter[1].rank, 2);
});

test('buildDonorLeaderboard filters by zone and bloodGroup while preserving citywide rank', () => {
  const filtered = buildDonorLeaderboard(baseEntries, [], citizen, { zone: 'Cyber Zone', bloodGroup: 'O+' });
  assert.equal(filtered.length, 1);
  assert.equal(filtered[0].name, 'Srinivas Rao');
  assert.equal(filtered[0].rank, 3);
});

test('getCitizenDonationSummary reflects base donations, scheduled pledges, and completed upgrades', () => {
  const pledges: BloodDonationPledge[] = [
    {
      id: 'd1',
      pledgeCode: 'BLD-DON-1',
      donorName: 'Srinivas Rao',
      bloodGroup: 'O+',
      age: 32,
      weightKg: 71,
      phone: '9848012345',
      email: 'citizen@idealcity360.gov.in',
      preferredBankId: 'bb-1',
      preferredBankName: 'Central Bank',
      preferredDate: '2026-11-21',
      preferredSlot: '10:00 AM',
      status: 'Scheduled',
      createdAt: '2026-11-18T10:00:00Z'
    }
  ];

  const summary = getCitizenDonationSummary(citizen, baseEntries, pledges);
  assert.equal(summary.totalDonations, 5);
  assert.equal(summary.scheduledPledges.length, 1);
  assert.equal(summary.badge.tier.label, 'Gold Star Donor');
  assert.equal(summary.cityRank, 3);
});
