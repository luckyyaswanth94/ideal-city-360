import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {
  buildAnonymousAuthorityAlertMessage,
  computeRetentionExpiryIso,
  decryptBuffer,
  encryptBuffer,
  generateSecureReportId,
  generateSecureTrackingToken,
  hasAnyForbiddenPiiKey,
  hashTrackingToken,
  isIncidentRetentionExpired,
  sanitizeEmergencyIncidentRecord,
  stripExifFromJpegBytes,
  verifyTrackingTokenHash,
} from './accidentPrivacy.ts';

test('stripExifFromJpegBytes removes APP1 EXIF/GPS and COM comment segments while preserving JPEG image payload', () => {
  // Construct synthetic JPEG: SOI + APP0 (keep) + APP1 EXIF GPS (strip) + COM DeviceInfo (strip) + SOS + payload + EOI
  const soi = [0xff, 0xd8];
  const app0Payload = [0x4a, 0x46, 0x49, 0x46, 0x00]; // "JFIF\0"
  const app0 = [0xff, 0xe0, 0x00, app0Payload.length + 2, ...app0Payload];

  const exifText = Buffer.from('Exif\0\0GPSLat=17.4264;iPhone16Pro;User=Srinivas');
  const app1 = [0xff, 0xe1, 0x00, exifText.length + 2, ...exifText];

  const comText = Buffer.from('Captured by IMEI-99887766');
  const com = [0xff, 0xfe, 0x00, comText.length + 2, ...comText];

  const sosAndEoi = [0xff, 0xda, 0x00, 0x04, 0x11, 0x22, 0x33, 0x44, 0xff, 0xd9];

  const dirtyJpeg = new Uint8Array([...soi, ...app0, ...app1, ...com, ...sosAndEoi]);
  const result = stripExifFromJpegBytes(dirtyJpeg);

  assert.equal(result.hadExif, true);
  assert.equal(result.removedSegments, 2);
  // Cleaned buffer still starts with SOI and ends with EOI
  assert.equal(result.cleaned[0], 0xff);
  assert.equal(result.cleaned[1], 0xd8);
  assert.equal(result.cleaned[result.cleaned.length - 2], 0xff);
  assert.equal(result.cleaned[result.cleaned.length - 1], 0xd9);

  // Sensitive EXIF and camera strings are completely gone from the cleaned bytes
  const cleanedAscii = Buffer.from(result.cleaned).toString('latin1');
  assert.equal(cleanedAscii.includes('Exif'), false);
  assert.equal(cleanedAscii.includes('iPhone16Pro'), false);
  assert.equal(cleanedAscii.includes('IMEI-99887766'), false);
  assert.equal(cleanedAscii.includes('JFIF'), true);
});

test('AES-256-GCM encryptBuffer and decryptBuffer protect sensitive images and reject tampering', () => {
  const key = crypto.randomBytes(32);
  const original = Buffer.from('classified-accident-photo-binary-payload');
  const encrypted = encryptBuffer(original, key);

  assert.notEqual(encrypted.ciphertext.toString('hex'), original.toString('hex'));
  const decrypted = decryptBuffer(encrypted, key);
  assert.deepEqual(decrypted, original);

  // Tampering with ciphertext must fail GCM authentication tag check
  const tampered = Buffer.from(encrypted.ciphertext);
  tampered[0] ^= 0xff;
  assert.throws(() =>
    decryptBuffer({ ...encrypted, ciphertext: tampered }, key)
  );
});

test('generateSecureReportId and tracking token hashing work with constant-time verification', () => {
  const id1 = generateSecureReportId(2026);
  const id2 = generateSecureReportId(2026);
  assert.match(id1, /^ACC-2026-[A-Z0-9]{6}$/);
  assert.notEqual(id1, id2);

  const token = generateSecureTrackingToken();
  assert.match(token, /^TRK-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/);

  const hash = hashTrackingToken(token);
  assert.equal(verifyTrackingTokenHash(token, hash), true);
  assert.equal(verifyTrackingTokenHash(token.toLowerCase(), hash), true);
  assert.equal(verifyTrackingTokenHash('TRK-0000-0000-0000-0000', hash), false);
});

test('sanitizeEmergencyIncidentRecord removes all forbidden PII keys before authority sharing', () => {
  const unsafe = {
    incidentCode: 'ACC-2026-AB12CD',
    accidentType: 'Bike Accident',
    severity: 'Critical',
    reporterName: 'Srinivas Rao',
    reporterPhone: '+91 98480 12345',
    reporterEmail: 'citizen@idealcity360.gov.in',
    reporterId: 'usr-citizen-1',
    ipAddress: '10.0.0.42',
    userAgent: 'Mozilla/5.0',
    deviceId: 'dev-xyz',
  };

  const sanitized = sanitizeEmergencyIncidentRecord(unsafe);
  assert.deepEqual(hasAnyForbiddenPiiKey(sanitized), []);
  assert.equal(sanitized.incidentCode, 'ACC-2026-AB12CD');
  assert.equal('reporterName' in sanitized, false);
  assert.equal('reporterEmail' in sanitized, false);
  assert.equal('ipAddress' in sanitized, false);
});

test('buildAnonymousAuthorityAlertMessage formats alert strictly with Reporter Identity: Anonymous and zero PII', () => {
  const msg = buildAnonymousAuthorityAlertMessage({
    incidentCode: 'ACC-2026-99A1B2',
    accidentType: 'Two-Wheeler & Car Collision',
    severity: 'Critical',
    latitude: 17.4264,
    longitude: 78.4141,
    googleMapsUrl: 'https://www.google.com/maps?q=17.426400,78.414100',
    incidentDate: '2026-11-19',
    incidentTime: '04:20 PM',
    securePhotoUrl: '/api/accidents/media/med-123',
    possibleInjuredCount: 1,
  });

  assert.match(msg, /NEW ROAD ACCIDENT ALERT/);
  assert.match(msg, /Report ID: ACC-2026-99A1B2/);
  assert.match(msg, /Reporter Identity: Anonymous$/);
  assert.match(msg, /\/api\/accidents\/media\/med-123/);
});

test('automatic data retention policy computes 30-day expiry and detects expired incidents', () => {
  const created = '2026-01-01T00:00:00.000Z';
  const expiry = computeRetentionExpiryIso(created, 30);
  assert.equal(expiry, '2026-01-31T00:00:00.000Z');
  assert.equal(isIncidentRetentionExpired(expiry, new Date('2026-01-15T00:00:00.000Z').getTime()), false);
  assert.equal(isIncidentRetentionExpired(expiry, new Date('2026-02-01T00:00:00.000Z').getTime()), true);
});
