import type { VerificationMeta, VerificationStatus, CityWellBeingMetric } from '../types.ts';

/**
 * Checks whether a record has passed its validUntil date
 */
export function checkExpiration(validUntil?: string): { isExpired: boolean; daysRemaining: number | null } {
  if (!validUntil) {
    return { isExpired: false, daysRemaining: null };
  }
  const expiry = new Date(validUntil);
  const now = new Date();
  
  if (isNaN(expiry.getTime())) {
    return { isExpired: false, daysRemaining: null };
  }

  const diffMs = expiry.getTime() - now.getTime();
  const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

  return {
    isExpired: diffMs < 0,
    daysRemaining: diffDays,
  };
}

/**
 * Formats a relative time string (e.g. "2 hours ago", "Yesterday", "Nov 12, 2026")
 */
export function formatRelativeTime(isoString: string): string {
  if (!isoString) return 'Recent';
  const date = new Date(isoString);
  if (isNaN(date.getTime())) return isoString;

  const now = new Date();
  const diffMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

  if (diffMinutes < 1) return 'Just now';
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  const diffHours = Math.floor(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 7) return `${diffDays}d ago`;

  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

/**
 * Filters items that are verified and not expired.
 * Also marks records as 'Expired' if their validUntil date is past.
 */
export function processVerificationStatus<T extends { verification: VerificationMeta }>(item: T): T {
  const { isExpired } = checkExpiration(item.verification.validUntil);
  if (isExpired && item.verification.verificationStatus === 'Verified') {
    return {
      ...item,
      verification: {
        ...item.verification,
        verificationStatus: 'Expired' as VerificationStatus,
      },
    };
  }
  return item;
}

/**
 * Computes an overall City Well-Being Index (0 - 100) from an array of domain metrics
 */
export function calculateCityWellBeingIndex(metrics: CityWellBeingMetric[]): {
  overallScore: number;
  grade: 'A+' | 'A' | 'B+' | 'B' | 'Needs Attention';
  totalMonitored: number;
  statusSummary: { excellent: number; good: number; needsAttention: number };
} {
  if (!metrics || metrics.length === 0) {
    return {
      overallScore: 0,
      grade: 'Needs Attention',
      totalMonitored: 0,
      statusSummary: { excellent: 0, good: 0, needsAttention: 0 },
    };
  }

  const totalScore = metrics.reduce((acc, m) => acc + m.score, 0);
  const overallScore = Math.round(totalScore / metrics.length);

  let grade: 'A+' | 'A' | 'B+' | 'B' | 'Needs Attention' = 'B';
  if (overallScore >= 90) grade = 'A+';
  else if (overallScore >= 80) grade = 'A';
  else if (overallScore >= 70) grade = 'B+';
  else if (overallScore >= 60) grade = 'B';
  else grade = 'Needs Attention';

  const statusSummary = {
    excellent: metrics.filter(m => m.status === 'Excellent').length,
    good: metrics.filter(m => m.status === 'Good').length,
    needsAttention: metrics.filter(m => m.status === 'Needs Attention').length,
  };

  return {
    overallScore,
    grade,
    totalMonitored: metrics.length,
    statusSummary,
  };
}

/**
 * Filter items by verification status
 */
export function filterByVerification<T extends { verification: VerificationMeta }>(
  items: T[],
  filter: 'all' | 'Verified' | 'Pending' | 'Expired' | 'Rejected'
): T[] {
  if (filter === 'all') return items;
  return items.filter(i => i.verification.verificationStatus === filter);
}

/**
 * General text search across object values
 */
export function searchRecords<T extends Record<string, any>>(records: T[], query: string, fields: (keyof T)[]): T[] {
  const q = query.trim().toLowerCase();
  if (!q) return records;

  return records.filter(item => {
    return fields.some(field => {
      const val = item[field];
      if (typeof val === 'string') {
        return val.toLowerCase().includes(q);
      }
      if (Array.isArray(val)) {
        return val.some((v: unknown) => typeof v === 'string' && v.toLowerCase().includes(q));
      }
      return false;
    });
  });
}
