import type {
  AccidentOverallStatus,
  AccidentReport,
  AccidentSeverity,
  AccidentType,
  AmbulanceUnit,
  Hospital,
  PoliceStation,
  UserRole,
} from '../types.ts';

export const AI_CAUSE_DISCLAIMER =
  'AI visual assessment only: exact cause of an accident cannot be determined from a photograph alone. Accident severity requires human assessment.';

export const PRIVACY_ASSURANCE_MESSAGE =
  'Your identity is protected. We share only the accident information and location necessary for emergency response. Your personal information is not disclosed to emergency authorities.';

export const RETENTION_POLICY_DAYS = 30;

export const VALID_ACCIDENT_TYPES: AccidentType[] = [
  'Car Collision',
  'Bike Accident',
  'Two-Wheeler & Car Collision',
  'Truck Accident',
  'Pedestrian Accident',
  'Multi-Vehicle Collision',
  'No Road Accident Detected',
  'Other Road Incident',
];

export const VALID_ACCIDENT_SEVERITIES: AccidentSeverity[] = [
  'Low',
  'Medium',
  'Critical',
];

export const DEFAULT_CITY_CENTER = {
  lat: 17.415,
  lng: 78.46,
};

export function haversineDistanceKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100;
}

export function buildGoogleMapsUrl(lat: number, lng: number): string {
  return `https://www.google.com/maps?q=${lat.toFixed(6)},${lng.toFixed(6)}`;
}

export function buildGoogleMapsDirectionsUrl(
  originLat: number,
  originLng: number,
  destLat: number,
  destLng: number
): string {
  return `https://www.google.com/maps/dir/?api=1&origin=${originLat.toFixed(6)},${originLng.toFixed(6)}&destination=${destLat.toFixed(6)},${destLng.toFixed(6)}&travelmode=driving`;
}

export function findNearestHospitals(
  hospitals: Hospital[],
  lat: number,
  lng: number,
  limit = 3
): { hospital: Hospital; distanceKm: number }[] {
  return hospitals
    .map((hospital) => ({
      hospital,
      distanceKm: haversineDistanceKm(
        lat,
        lng,
        hospital.location.lat,
        hospital.location.lng
      ),
    }))
    .sort((a, b) => a.distanceKm - b.distanceKm)
    .slice(0, Math.max(1, limit));
}

export function findNearestAmbulanceUnit(
  units: AmbulanceUnit[],
  lat: number,
  lng: number
): { unit: AmbulanceUnit; distanceKm: number } | null {
  if (!units.length) return null;
  const available = units.filter((u) => u.status === 'Available');
  const pool = available.length > 0 ? available : units;
  const ranked = pool
    .map((unit) => ({
      unit,
      distanceKm: haversineDistanceKm(lat, lng, unit.lat, unit.lng),
    }))
    .sort((a, b) => a.distanceKm - b.distanceKm);
  return ranked[0] || null;
}

export function findNearestPoliceStation(
  stations: PoliceStation[],
  lat: number,
  lng: number
): { station: PoliceStation; distanceKm: number } | null {
  if (!stations.length) return null;
  const ranked = stations
    .map((station) => ({
      station,
      distanceKm: haversineDistanceKm(lat, lng, station.lat, station.lng),
    }))
    .sort((a, b) => a.distanceKm - b.distanceKm);
  return ranked[0] || null;
}

export function computeShortestRoute(
  origin: { lat: number; lng: number },
  destination: { lat: number; lng: number }
): {
  waypoints: { lat: number; lng: number }[];
  routeDistanceKm: number;
  estimatedEtaMinutes: number;
} {
  const straightKm = haversineDistanceKm(
    origin.lat,
    origin.lng,
    destination.lat,
    destination.lng
  );
  const routeDistanceKm = Math.max(
    0.4,
    Math.round(straightKm * 1.24 * 100) / 100
  );

  // Build realistic road-corridor arterial polyline waypoints between origin and incident
  const dLat = destination.lat - origin.lat;
  const dLng = destination.lng - origin.lng;
  const perpLat = -dLng * 0.08;
  const perpLng = dLat * 0.08;

  const waypoints = [
    { lat: origin.lat, lng: origin.lng },
    {
      lat: Number((origin.lat + dLat * 0.25 + perpLat * 0.5).toFixed(6)),
      lng: Number((origin.lng + dLng * 0.25 + perpLng * 0.5).toFixed(6)),
    },
    {
      lat: Number((origin.lat + dLat * 0.55 + perpLat).toFixed(6)),
      lng: Number((origin.lng + dLng * 0.55 + perpLng).toFixed(6)),
    },
    {
      lat: Number((origin.lat + dLat * 0.8 + perpLat * 0.35).toFixed(6)),
      lng: Number((origin.lng + dLng * 0.8 + perpLng * 0.35).toFixed(6)),
    },
    { lat: destination.lat, lng: destination.lng },
  ];

  // Emergency response vehicle average urban corridor speed ~36 km/h + 2 min mobilization
  const estimatedEtaMinutes = Math.max(
    3,
    Math.round((routeDistanceKm / 36) * 60 + 2)
  );

  return {
    waypoints,
    routeDistanceKm,
    estimatedEtaMinutes,
  };
}

export function formatSafeIncidentDescription(
  rawSummary: string,
  lat: number,
  lng: number
): string {
  const cleaned = (rawSummary || '').trim();
  const coords = `Location: ${lat.toFixed(5)}, ${lng.toFixed(5)}.`;
  const hasHumanAssessmentNote = /human assessment|cannot be determined/i.test(
    cleaned
  );
  const base =
    cleaned ||
    'Possible road traffic incident observed in uploaded photograph. Visible vehicle or roadway disruption.';
  const withAssessment = hasHumanAssessmentNote
    ? base
    : `${base.replace(/\.$/, '')}. Accident severity requires human assessment.`;
  if (withAssessment.includes(lat.toFixed(3))) {
    return withAssessment;
  }
  return `${withAssessment} ${coords}`;
}

export interface AccidentSubmissionPayload {
  photoDataUrl?: string;
  latitude?: number;
  longitude?: number;
  locationLabel?: string;
  accidentType?: string;
  severity?: string;
  possibleInjuredCount?: number | null;
  reporterConfirmed?: boolean;
  sceneNotes?: string;
  optionalCallbackConsented?: boolean;
  optionalCallbackPhone?: string;
}

export function validateAccidentSubmission(
  payload: AccidentSubmissionPayload
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (payload.reporterConfirmed !== true) {
    errors.push(
      'Explicit human confirmation is required before sending emergency notifications.'
    );
  }

  const photo = (payload.photoDataUrl || '').trim();
  const isValidPhoto =
    photo.startsWith('data:image/') || photo.startsWith('/assets/');
  if (!isValidPhoto) {
    errors.push('Please upload or capture an accident photograph first.');
  }

  if (
    typeof payload.latitude !== 'number' ||
    !Number.isFinite(payload.latitude) ||
    payload.latitude < -90 ||
    payload.latitude > 90
  ) {
    errors.push('Valid accident latitude coordinate is required.');
  }

  if (
    typeof payload.longitude !== 'number' ||
    !Number.isFinite(payload.longitude) ||
    payload.longitude < -180 ||
    payload.longitude > 180
  ) {
    errors.push('Valid accident longitude coordinate is required.');
  }

  if (
    !payload.accidentType ||
    !VALID_ACCIDENT_TYPES.includes(payload.accidentType as AccidentType)
  ) {
    errors.push('Please select a valid accident classification.');
  }

  if (
    !payload.severity ||
    !VALID_ACCIDENT_SEVERITIES.includes(payload.severity as AccidentSeverity)
  ) {
    errors.push('Please select a valid severity level (Low, Medium, Critical).');
  }

  if (
    payload.possibleInjuredCount !== undefined &&
    payload.possibleInjuredCount !== null
  ) {
    if (
      !Number.isInteger(payload.possibleInjuredCount) ||
      payload.possibleInjuredCount < 0 ||
      payload.possibleInjuredCount > 200
    ) {
      errors.push('Estimated injured count must be a whole number between 0 and 200.');
    }
  }

  // Optional callback number is strictly opt-in with explicit separate consent
  const trimmedPhone = (payload.optionalCallbackPhone || '').trim();
  if (trimmedPhone && payload.optionalCallbackConsented !== true) {
    errors.push(
      'Separate explicit consent is required before sharing an optional callback number.'
    );
  }

  return { valid: errors.length === 0, errors };
}

export function canRoleAccessAuthorityDashboard(role: UserRole): boolean {
  return (
    role === 'super_admin' ||
    role === 'hospital_admin' ||
    role === 'ambulance_service' ||
    role === 'police_officer'
  );
}

export function canRoleUpdateAgency(
  role: UserRole,
  agency: 'hospital' | 'ambulance' | 'police' | 'overall'
): boolean {
  if (role === 'super_admin') return true;
  if (role === 'hospital_admin') return agency === 'hospital';
  if (role === 'ambulance_service') return agency === 'ambulance';
  if (role === 'police_officer') return agency === 'police' || agency === 'overall';
  return false;
}

export function deriveOverallAccidentStatus(
  report: Pick<
    AccidentReport,
    'overallStatus' | 'notifiedHospitals' | 'ambulanceDispatch' | 'policeDispatch'
  >
): AccidentOverallStatus {
  if (report.overallStatus === 'Resolved') return 'Resolved';
  const policeDone =
    report.policeDispatch.status === 'Scene Cleared' ||
    report.policeDispatch.status === 'Case Closed';
  const ambulanceDone = report.ambulanceDispatch.status === 'Completed';
  if (policeDone && ambulanceDone) return 'Resolved';

  const anyActiveResponse =
    report.ambulanceDispatch.status !== 'Pending' &&
    report.ambulanceDispatch.status !== 'Notified';
  const policeActive =
    report.policeDispatch.status !== 'Pending' &&
    report.policeDispatch.status !== 'Notified';
  const hospitalReady = report.notifiedHospitals.some(
    (h) => h.status !== 'Pending' && h.status !== 'Notified'
  );

  if (anyActiveResponse || policeActive || hospitalReady) {
    return 'Response Dispatched';
  }
  return 'Active Emergency';
}

export function buildScopedMediaUrl(
  securePhotoUrl: string,
  incidentCode?: string,
  trackingToken?: string
): string {
  if (incidentCode && trackingToken) {
    const sep = securePhotoUrl.includes('?') ? '&' : '?';
    return `${securePhotoUrl}${sep}reportCode=${encodeURIComponent(incidentCode)}&token=${encodeURIComponent(trackingToken)}`;
  }
  return securePhotoUrl;
}

