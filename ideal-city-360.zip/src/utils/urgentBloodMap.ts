import type { BloodBank, BloodGroup, BloodRequest, Hospital } from '../types';
import { getCompatibleDonorGroups, isCompatibleDonor } from './bloodBank';

export interface GeoReferencePoint {
  lat: number;
  lng: number;
  label: string;
}

export const DEFAULT_USER_LOCATION: GeoReferencePoint = {
  lat: 17.415,
  lng: 78.46,
  label: 'Ideal City Center'
};

export const ZONE_REFERENCE_POINTS: Record<string, GeoReferencePoint> = {
  'Central Zone': { lat: 17.412, lng: 78.471, label: 'Central Zone Hub' },
  'Cyber Zone': { lat: 17.434, lng: 78.404, label: 'Cyber Zone Hub' },
  'North Zone': { lat: 17.438, lng: 78.494, label: 'North Zone Hub' },
  'South Zone': { lat: 17.392, lng: 78.456, label: 'South Zone Hub' }
};

export type UrgencyMapFilter = 'all_urgent' | 'Urgent' | 'Emergency';

export interface UrgentBloodRequestPin {
  request: BloodRequest;
  lat: number;
  lng: number;
  zone: string;
  resolvedBankId?: string;
  resolvedBankName?: string;
  distanceKm: number;
  compatibleDonorGroups: BloodGroup[];
  isCompatibleWithCurrentDonor: boolean;
}

/**
 * Computes Haversine great-circle distance in kilometers, rounded to 1 decimal place.
 */
export function calculateDistanceKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

/**
 * Resolves coordinates & nearest matching blood bank for any blood request:
 * 1) Explicit request lat/lng
 * 2) Linked bloodBankId coordinates (or linked hospital coordinates)
 * 3) Hospital name match against city hospitals or blood banks
 * 4) Deterministic fallback near city center so newly submitted requests always map cleanly
 */
export function resolveRequestCoordinates(
  request: BloodRequest,
  bloodBanks: BloodBank[],
  hospitals: Hospital[]
): {
  lat: number;
  lng: number;
  zone: string;
  resolvedBankId?: string;
  resolvedBankName?: string;
} {
  const linkedBank = request.bloodBankId
    ? bloodBanks.find(b => b.id === request.bloodBankId)
    : undefined;

  const normalizedHospital = request.hospitalName.trim().toLowerCase();
  const matchedHospital =
    (linkedBank?.hospitalId
      ? hospitals.find(h => h.id === linkedBank.hospitalId)
      : undefined) ||
    hospitals.find(
      h =>
        h.name.toLowerCase() === normalizedHospital ||
        normalizedHospital.includes(h.name.toLowerCase()) ||
        h.name.toLowerCase().includes(normalizedHospital)
    );

  const matchedBankByName =
    linkedBank ||
    bloodBanks.find(
      b =>
        (matchedHospital && b.hospitalId === matchedHospital.id) ||
        b.name.toLowerCase().includes(normalizedHospital) ||
        normalizedHospital.includes(b.name.toLowerCase())
    );

  if (typeof request.lat === 'number' && typeof request.lng === 'number') {
    return {
      lat: request.lat,
      lng: request.lng,
      zone: request.zone || matchedBankByName?.zone || matchedHospital?.location.area || 'Central Zone',
      resolvedBankId: matchedBankByName?.id,
      resolvedBankName: matchedBankByName?.name
    };
  }

  if (
    linkedBank &&
    typeof linkedBank.lat === 'number' &&
    typeof linkedBank.lng === 'number'
  ) {
    return {
      lat: linkedBank.lat,
      lng: linkedBank.lng,
      zone: request.zone || linkedBank.zone,
      resolvedBankId: linkedBank.id,
      resolvedBankName: linkedBank.name
    };
  }

  if (matchedHospital) {
    return {
      lat: matchedHospital.location.lat,
      lng: matchedHospital.location.lng,
      zone: request.zone || matchedBankByName?.zone || matchedHospital.location.area,
      resolvedBankId: matchedBankByName?.id,
      resolvedBankName: matchedBankByName?.name
    };
  }

  if (
    matchedBankByName &&
    typeof matchedBankByName.lat === 'number' &&
    typeof matchedBankByName.lng === 'number'
  ) {
    return {
      lat: matchedBankByName.lat,
      lng: matchedBankByName.lng,
      zone: request.zone || matchedBankByName.zone,
      resolvedBankId: matchedBankByName.id,
      resolvedBankName: matchedBankByName.name
    };
  }

  // Deterministic small offset around city center so custom facility requests stay visible & distinct
  let hash = 0;
  for (let i = 0; i < request.id.length; i++) {
    hash = (hash * 31 + request.id.charCodeAt(i)) % 1000;
  }
  const latOffset = ((hash % 21) - 10) * 0.0014;
  const lngOffset = (((Math.floor(hash / 21) % 21) - 10)) * 0.0014;

  return {
    lat: Number((DEFAULT_USER_LOCATION.lat + latOffset).toFixed(4)),
    lng: Number((DEFAULT_USER_LOCATION.lng + lngOffset).toFixed(4)),
    zone: request.zone || 'Central Zone',
    resolvedBankId: bloodBanks[0]?.id,
    resolvedBankName: bloodBanks[0]?.name
  };
}

export interface UrgentBloodMapOptions {
  urgencyFilter?: UrgencyMapFilter;
  bloodGroup?: BloodGroup | 'all';
  zone?: string;
  referenceLocation?: GeoReferencePoint;
  donorBloodGroup?: BloodGroup;
  compatibleOnly?: boolean;
}

/**
 * Returns active (non-Fulfilled) Urgent/Emergency blood requests enriched with coordinates,
 * distance from the reference location, and donor compatibility, sorted by urgency then nearest distance.
 */
export function getActiveUrgentBloodRequestPins(
  requests: BloodRequest[],
  bloodBanks: BloodBank[],
  hospitals: Hospital[],
  options: UrgentBloodMapOptions = {}
): UrgentBloodRequestPin[] {
  const {
    urgencyFilter = 'all_urgent',
    bloodGroup = 'all',
    zone = 'all',
    referenceLocation = DEFAULT_USER_LOCATION,
    donorBloodGroup,
    compatibleOnly = false
  } = options;

  const activeUrgent = requests.filter(req => {
    if (req.status === 'Fulfilled') return false;
    if (req.urgency === 'Scheduled') return false;
    if (urgencyFilter === 'Urgent' && req.urgency !== 'Urgent') return false;
    if (urgencyFilter === 'Emergency' && req.urgency !== 'Emergency') return false;
    if (bloodGroup !== 'all' && req.bloodGroup !== bloodGroup) return false;
    return true;
  });

  const enriched: UrgentBloodRequestPin[] = activeUrgent.map(req => {
    const resolved = resolveRequestCoordinates(req, bloodBanks, hospitals);
    const distanceKm = calculateDistanceKm(
      referenceLocation.lat,
      referenceLocation.lng,
      resolved.lat,
      resolved.lng
    );
    const compatibleDonorGroups = getCompatibleDonorGroups(req.bloodGroup);
    const isCompatibleWithCurrentDonor = donorBloodGroup
      ? isCompatibleDonor(donorBloodGroup, req.bloodGroup)
      : false;

    return {
      request: req,
      lat: resolved.lat,
      lng: resolved.lng,
      zone: resolved.zone,
      resolvedBankId: resolved.resolvedBankId,
      resolvedBankName: resolved.resolvedBankName,
      distanceKm,
      compatibleDonorGroups,
      isCompatibleWithCurrentDonor
    };
  });

  const filtered = enriched.filter(pin => {
    if (zone !== 'all' && pin.zone !== zone) return false;
    if (compatibleOnly && donorBloodGroup && !pin.isCompatibleWithCurrentDonor) return false;
    return true;
  });

  // Sort: Emergency before Urgent, then nearest distance first
  return filtered.sort((a, b) => {
    const urgencyWeight = (u: BloodRequest['urgency']) => (u === 'Emergency' ? 0 : 1);
    const diffUrgency = urgencyWeight(a.request.urgency) - urgencyWeight(b.request.urgency);
    if (diffUrgency !== 0) return diffUrgency;
    return a.distanceKm - b.distanceKm;
  });
}
