import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDistanceKm,
  resolveRequestCoordinates,
  getActiveUrgentBloodRequestPins,
  DEFAULT_USER_LOCATION
} from './urgentBloodMap';
import type { BloodBank, BloodRequest, Hospital } from '../types';

const mockHospitals: Hospital[] = [
  {
    id: 'hosp-1',
    name: 'Ideal City Central Government Super-Specialty Hospital',
    type: 'Government Super-Specialty',
    address: 'Sector 4, Raj Bhavan Road',
    location: { lat: 17.4065, lng: 78.4772, area: 'Central Zone' },
    phone: '040-2345-6789',
    emergencyPhone: '108',
    facilities: ['Blood Bank'],
    bedCount: { total: 100, available: 50, icu: 10 },
    rating: 4.7,
    openHours: '24x7',
    verification: {
      sourceName: 'DMHO',
      sourceUrl: 'https://idealcity.gov.in',
      createdDate: '2026-01-01',
      lastUpdated: '2026-11-18T10:00:00Z',
      verificationStatus: 'Verified',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'hosp-2',
    name: 'Apollo Health City & Research Institute',
    type: 'Private Multi-Specialty',
    address: 'Jubilee Valley Boulevard',
    location: { lat: 17.4258, lng: 78.4116, area: 'Cyber Zone' },
    phone: '040-2980-4400',
    emergencyPhone: '1066',
    facilities: ['Blood Bank'],
    bedCount: { total: 150, available: 80, icu: 12 },
    rating: 4.8,
    openHours: '24x7',
    verification: {
      sourceName: 'DMHO',
      sourceUrl: 'https://apollo.idealcity.gov.in',
      createdDate: '2026-01-01',
      lastUpdated: '2026-11-18T10:00:00Z',
      verificationStatus: 'Verified',
      isDemoData: true,
      updateHistory: []
    }
  }
];

const mockBanks: BloodBank[] = [
  {
    id: 'bb-1',
    name: 'Central Govt Blood Bank',
    hospitalId: 'hosp-1',
    address: 'Sector 4',
    zone: 'Central Zone',
    lat: 17.4065,
    lng: 78.4772,
    phone: '040-2345-6790',
    emergencyPhone: '104',
    openHours: '24x7',
    licenseNumber: 'LIC-001',
    is24x7: true,
    componentSeparation: true,
    inventory: { 'A+': 10, 'A-': 2, 'B+': 12, 'B-': 3, 'AB+': 5, 'AB-': 1, 'O+': 20, 'O-': 2 },
    verification: mockHospitals[0].verification
  },
  {
    id: 'bb-3',
    name: 'Apollo Blood Bank',
    hospitalId: 'hosp-2',
    address: 'Jubilee Valley',
    zone: 'Cyber Zone',
    lat: 17.4258,
    lng: 78.4116,
    phone: '040-2980-4450',
    emergencyPhone: '1066',
    openHours: '24x7',
    licenseNumber: 'LIC-029',
    is24x7: true,
    componentSeparation: true,
    inventory: { 'A+': 10, 'A-': 2, 'B+': 12, 'B-': 3, 'AB+': 5, 'AB-': 1, 'O+': 20, 'O-': 2 },
    verification: mockHospitals[1].verification
  }
];

const sampleRequests: BloodRequest[] = [
  {
    id: 'r-emergency',
    requestCode: 'BLD-REQ-101',
    patientName: 'Lakshmi Narayana',
    bloodGroup: 'O-',
    unitsNeeded: 2,
    urgency: 'Emergency',
    hospitalName: 'Ideal City Central Government Super-Specialty Hospital',
    bloodBankId: 'bb-1',
    contactName: 'Prakash',
    contactPhone: '+91 98480 33412',
    status: 'Pending',
    createdAt: '2026-11-18T14:20:00Z'
  },
  {
    id: 'r-urgent',
    requestCode: 'BLD-REQ-102',
    patientName: 'Mohammed Azeem',
    bloodGroup: 'O+',
    unitsNeeded: 1,
    urgency: 'Urgent',
    hospitalName: 'Apollo Health City & Research Institute',
    bloodBankId: 'bb-3',
    contactName: 'Imran',
    contactPhone: '+91 98480 55112',
    status: 'Pending',
    createdAt: '2026-11-18T15:10:00Z'
  },
  {
    id: 'r-scheduled',
    requestCode: 'BLD-REQ-103',
    patientName: 'Suresh Babu',
    bloodGroup: 'A+',
    unitsNeeded: 1,
    urgency: 'Scheduled',
    hospitalName: 'Apollo Health City & Research Institute',
    bloodBankId: 'bb-3',
    contactName: 'Ramesh',
    contactPhone: '+91 98480 11111',
    status: 'Pending',
    createdAt: '2026-11-18T12:00:00Z'
  },
  {
    id: 'r-fulfilled',
    requestCode: 'BLD-REQ-104',
    patientName: 'Meena Kumari',
    bloodGroup: 'B+',
    unitsNeeded: 1,
    urgency: 'Urgent',
    hospitalName: 'Ideal City Central Government Super-Specialty Hospital',
    bloodBankId: 'bb-1',
    contactName: 'Raju',
    contactPhone: '+91 98480 22222',
    status: 'Fulfilled',
    createdAt: '2026-11-18T10:00:00Z'
  }
];

test('calculateDistanceKm computes accurate Haversine distances', () => {
  assert.equal(calculateDistanceKm(17.415, 78.46, 17.415, 78.46), 0);
  const dist = calculateDistanceKm(17.4065, 78.4772, 17.4258, 78.4116);
  // Central Govt Hospital to Apollo Health City is ~7.3 km
  assert.ok(dist > 6.5 && dist < 8.5, `Expected ~7.3 km, got ${dist}`);
});

test('resolveRequestCoordinates resolves explicit, bank-linked, hospital-matched, and fallback locations', () => {
  const fromBank = resolveRequestCoordinates(sampleRequests[0], mockBanks, mockHospitals);
  assert.equal(fromBank.lat, 17.4065);
  assert.equal(fromBank.lng, 78.4772);
  assert.equal(fromBank.zone, 'Central Zone');

  const fromExplicit = resolveRequestCoordinates(
    { ...sampleRequests[0], lat: 17.45, lng: 78.49, zone: 'North Zone' },
    mockBanks,
    mockHospitals
  );
  assert.equal(fromExplicit.lat, 17.45);
  assert.equal(fromExplicit.lng, 78.49);
  assert.equal(fromExplicit.zone, 'North Zone');

  const fallback = resolveRequestCoordinates(
    { ...sampleRequests[0], id: 'custom-req', bloodBankId: undefined, hospitalName: 'New City Clinic' },
    mockBanks,
    mockHospitals
  );
  assert.ok(Math.abs(fallback.lat - DEFAULT_USER_LOCATION.lat) < 0.05);
  assert.ok(Math.abs(fallback.lng - DEFAULT_USER_LOCATION.lng) < 0.05);
});

test('getActiveUrgentBloodRequestPins excludes Scheduled and Fulfilled requests and sorts Emergency first', () => {
  const pins = getActiveUrgentBloodRequestPins(sampleRequests, mockBanks, mockHospitals, {
    donorBloodGroup: 'O+'
  });
  assert.equal(pins.length, 2);
  assert.equal(pins[0].request.id, 'r-emergency');
  assert.equal(pins[1].request.id, 'r-urgent');
  // O+ donor cannot donate to O- (Emergency), CAN donate to O+ (Urgent)
  assert.equal(pins[0].isCompatibleWithCurrentDonor, false);
  assert.equal(pins[1].isCompatibleWithCurrentDonor, true);
});

test('getActiveUrgentBloodRequestPins supports urgency, zone, blood group, and compatibleOnly filters', () => {
  const urgentOnly = getActiveUrgentBloodRequestPins(sampleRequests, mockBanks, mockHospitals, {
    urgencyFilter: 'Urgent'
  });
  assert.equal(urgentOnly.length, 1);
  assert.equal(urgentOnly[0].request.id, 'r-urgent');

  const compatibleForOPlus = getActiveUrgentBloodRequestPins(sampleRequests, mockBanks, mockHospitals, {
    donorBloodGroup: 'O+',
    compatibleOnly: true
  });
  assert.equal(compatibleForOPlus.length, 1);
  assert.equal(compatibleForOPlus[0].request.bloodGroup, 'O+');

  const centralOnly = getActiveUrgentBloodRequestPins(sampleRequests, mockBanks, mockHospitals, {
    zone: 'Central Zone'
  });
  assert.equal(centralOnly.length, 1);
  assert.equal(centralOnly[0].zone, 'Central Zone');
});
