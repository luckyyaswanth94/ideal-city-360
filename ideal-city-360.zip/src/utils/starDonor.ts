import type { BloodDonationPledge, BloodGroup, DonorLeaderboardEntry, User } from '../types';

export type StarDonorTierId = 'new' | 'bronze' | 'silver' | 'gold' | 'platinum';

export interface StarDonorTier {
  id: StarDonorTierId;
  label: string;
  shortLabel: string;
  minDonations: number;
  stars: number;
  nextTierLabel: string | null;
  nextTierMin: number | null;
  description: string;
}

export const STAR_DONOR_TIERS: StarDonorTier[] = [
  {
    id: 'new',
    label: 'Community Supporter',
    shortLabel: 'Supporter',
    minDonations: 0,
    stars: 0,
    nextTierLabel: 'Bronze Star Donor',
    nextTierMin: 1,
    description: 'Complete your first verified blood donation to earn your Star Donor badge.'
  },
  {
    id: 'bronze',
    label: 'Bronze Star Donor',
    shortLabel: 'Bronze Star',
    minDonations: 1,
    stars: 1,
    nextTierLabel: 'Silver Star Donor',
    nextTierMin: 3,
    description: 'Verified lifesaver who has stepped up to donate blood for citizens in need.'
  },
  {
    id: 'silver',
    label: 'Silver Star Donor',
    shortLabel: 'Silver Star',
    minDonations: 3,
    stars: 2,
    nextTierLabel: 'Gold Star Donor',
    nextTierMin: 5,
    description: 'Consistent city blood donor strengthening emergency blood reserves.'
  },
  {
    id: 'gold',
    label: 'Gold Star Donor',
    shortLabel: 'Gold Star',
    minDonations: 5,
    stars: 3,
    nextTierLabel: 'Platinum Star Donor',
    nextTierMin: 10,
    description: 'Distinguished regular donor recognized by the Municipal Health Directorate.'
  },
  {
    id: 'platinum',
    label: 'Platinum Star Donor',
    shortLabel: 'Platinum Star',
    minDonations: 10,
    stars: 5,
    nextTierLabel: null,
    nextTierMin: null,
    description: 'Elite civic champion with 10+ verified blood donations saving dozens of lives.'
  }
];

export interface StarDonorBadgeInfo {
  tier: StarDonorTier;
  totalDonations: number;
  livesImpacted: number;
  progressPercent: number;
  donationsToNextTier: number;
  isStarDonor: boolean;
}

export function getStarDonorBadge(totalDonations: number): StarDonorBadgeInfo {
  const safeCount = Math.max(0, Math.floor(Number.isFinite(totalDonations) ? totalDonations : 0));

  let currentTier = STAR_DONOR_TIERS[0];
  for (const tier of STAR_DONOR_TIERS) {
    if (safeCount >= tier.minDonations) {
      currentTier = tier;
    }
  }

  let progressPercent = 100;
  let donationsToNextTier = 0;

  if (currentTier.nextTierMin !== null) {
    const span = currentTier.nextTierMin - currentTier.minDonations;
    const gained = safeCount - currentTier.minDonations;
    progressPercent = span > 0 ? Math.min(100, Math.max(0, Math.round((gained / span) * 100))) : 100;
    donationsToNextTier = Math.max(0, currentTier.nextTierMin - safeCount);
  }

  return {
    tier: currentTier,
    totalDonations: safeCount,
    livesImpacted: safeCount * 3,
    progressPercent,
    donationsToNextTier,
    isStarDonor: safeCount >= 1
  };
}

export interface RankedDonorEntry extends DonorLeaderboardEntry {
  rank: number;
  badge: StarDonorBadgeInfo;
  isCurrentUser: boolean;
}

export function buildDonorLeaderboard(
  baseEntries: DonorLeaderboardEntry[],
  donations: BloodDonationPledge[],
  currentUser: User,
  filters?: { zone?: string; bloodGroup?: BloodGroup | 'all' }
): RankedDonorEntry[] {
  const byEmail = new Map<string, DonorLeaderboardEntry>();

  for (const entry of baseEntries) {
    byEmail.set(entry.email.toLowerCase(), { ...entry });
  }

  // Ensure currentUser is represented if they have base donations or completed donations
  const userKey = currentUser.email.toLowerCase();
  if (!byEmail.has(userKey) && (currentUser.totalDonations ?? 0) > 0) {
    byEmail.set(userKey, {
      id: `ldr-${currentUser.id}`,
      name: currentUser.name,
      email: currentUser.email,
      bloodGroup: currentUser.bloodGroup || 'O+',
      zone: currentUser.zone || 'Central Zone',
      totalDonations: currentUser.totalDonations ?? 0,
      lastDonationDate: new Date().toISOString().split('T')[0],
      verified: true
    });
  }

  // Add completed donations from live session pledges
  for (const pledge of donations) {
    if (pledge.status !== 'Completed') continue;
    const key = (pledge.email || pledge.donorName).toLowerCase();
    const existing = byEmail.get(key);
    if (existing) {
      existing.totalDonations += 1;
      if (pledge.preferredDate > existing.lastDonationDate) {
        existing.lastDonationDate = pledge.preferredDate;
      }
    } else {
      byEmail.set(key, {
        id: `ldr-${pledge.id}`,
        name: pledge.donorName,
        email: pledge.email || `${pledge.donorName.toLowerCase().replace(/\s+/g, '.')}@idealcity.in`,
        bloodGroup: pledge.bloodGroup,
        zone: 'Central Zone',
        totalDonations: 1,
        lastDonationDate: pledge.preferredDate,
        verified: true
      });
    }
  }

  // Sort globally first so ranks reflect true citywide standings
  const sortedAll = Array.from(byEmail.values()).sort((a, b) => {
    if (b.totalDonations !== a.totalDonations) {
      return b.totalDonations - a.totalDonations;
    }
    return b.lastDonationDate.localeCompare(a.lastDonationDate);
  });

  const rankedAll: RankedDonorEntry[] = sortedAll.map((entry, idx) => ({
    ...entry,
    rank: idx + 1,
    badge: getStarDonorBadge(entry.totalDonations),
    isCurrentUser: entry.email.toLowerCase() === userKey
  }));

  if (!filters) return rankedAll;

  return rankedAll.filter(entry => {
    const matchesZone = !filters.zone || filters.zone === 'all' || entry.zone === filters.zone;
    const matchesGroup = !filters.bloodGroup || filters.bloodGroup === 'all' || entry.bloodGroup === filters.bloodGroup;
    return matchesZone && matchesGroup;
  });
}

export interface CitizenDonationSummary {
  totalDonations: number;
  completedSessionDonations: number;
  scheduledPledges: BloodDonationPledge[];
  completedPledges: BloodDonationPledge[];
  badge: StarDonorBadgeInfo;
  cityRank: number | null;
  totalRankedDonors: number;
  bloodGroup: BloodGroup;
}

export function getCitizenDonationSummary(
  currentUser: User,
  baseEntries: DonorLeaderboardEntry[],
  donations: BloodDonationPledge[]
): CitizenDonationSummary {
  const userEmail = currentUser.email.toLowerCase();
  const userName = currentUser.name.toLowerCase();

  const userPledges = donations.filter(
    d => (d.email && d.email.toLowerCase() === userEmail) || d.donorName.toLowerCase() === userName
  );
  const scheduledPledges = userPledges.filter(d => d.status === 'Scheduled');
  const completedPledges = userPledges.filter(d => d.status === 'Completed');

  const leaderboard = buildDonorLeaderboard(baseEntries, donations, currentUser);
  const userRankEntry = leaderboard.find(e => e.isCurrentUser);

  const baseEntry = baseEntries.find(e => e.email.toLowerCase() === userEmail);
  const baseCount = baseEntry ? baseEntry.totalDonations : (currentUser.totalDonations ?? 0);
  const totalDonations = userRankEntry ? userRankEntry.totalDonations : baseCount + completedPledges.length;

  return {
    totalDonations,
    completedSessionDonations: completedPledges.length,
    scheduledPledges,
    completedPledges,
    badge: getStarDonorBadge(totalDonations),
    cityRank: userRankEntry ? userRankEntry.rank : null,
    totalRankedDonors: leaderboard.length,
    bloodGroup: userRankEntry?.bloodGroup || currentUser.bloodGroup || 'O+'
  };
}
