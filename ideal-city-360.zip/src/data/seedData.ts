import type { 
  Hospital, 
  Doctor, 
  DoctorVisit, 
  HospitalVacancy, 
  HealthCamp,
  BloodBank,
  BloodRequest,
  BloodDonationPledge,
  DonorLeaderboardEntry,
  BusRoute, 
  BusSchedule, 
  TransportAlert, 
  GovernmentRule, 
  JobListing, 
  EducationService, 
  SocialWelfareService, 
  EmergencyContact, 
  Announcement, 
  CityWellBeingMetric, 
  Complaint, 
  User,
  PoliceStation,
  AmbulanceUnit,
  AccidentReport
} from '../types.ts';

export const SEED_USERS: User[] = [
  {
    id: 'usr-citizen-1',
    name: 'Srinivas Rao',
    email: 'citizen@idealcity360.gov.in',
    role: 'citizen',
    phone: '+91 98480 12345',
    zone: 'Cyber Zone',
    bloodGroup: 'O+',
    totalDonations: 5,
    savedItemIds: ['hosp-1', 'doc-1', 'job-1'],
    subscribedCategories: ['Health', 'Transport', 'Civic']
  },
  {
    id: 'usr-admin-1',
    name: 'Dr. Aruna Devi (IAS)',
    email: 'admin@idealcity360.gov.in',
    role: 'super_admin',
    phone: '+91 98480 99001',
    zone: 'City Central Administrative District',
    savedItemIds: [],
    subscribedCategories: ['Health', 'Transport', 'Civic', 'Emergency', 'Weather']
  },
  {
    id: 'usr-hosp-1',
    name: 'Dr. Vikramaditya Reddy',
    email: 'hospital.admin@idealcity360.gov.in',
    role: 'hospital_admin',
    phone: '+91 98480 77112',
    zone: 'Central Medical Enclave',
    savedItemIds: [],
    subscribedCategories: ['Health']
  },
  {
    id: 'usr-trans-1',
    name: 'Ramesh Chandra (RTO)',
    email: 'transport.admin@idealcity360.gov.in',
    role: 'transport_admin',
    phone: '+91 98480 66223',
    zone: 'Transit Operations Command Center',
    savedItemIds: [],
    subscribedCategories: ['Transport']
  },
  {
    id: 'usr-gov-1',
    name: 'Sunita Sharma (Joint Director)',
    email: 'gov.admin@idealcity360.gov.in',
    role: 'gov_admin',
    phone: '+91 98480 55334',
    zone: 'Public Grievance Secretariat',
    savedItemIds: [],
    subscribedCategories: ['Civic', 'Emergency']
  },
  {
    id: 'usr-verif-1',
    name: 'K. Mahender (Fact-Check Cell)',
    email: 'verifier@idealcity360.gov.in',
    role: 'verifier',
    phone: '+91 98480 44889',
    zone: 'Public Information Audit Cell',
    savedItemIds: [],
    subscribedCategories: ['Health', 'Transport', 'Civic', 'Emergency', 'Weather']
  },
  {
    id: 'usr-amb-1',
    name: 'S. Narayana (108 EMS Lead)',
    email: 'ambulance.ems@idealcity360.gov.in',
    role: 'ambulance_service',
    phone: '+91 98480 10800',
    zone: 'Emergency Medical Services Command',
    savedItemIds: [],
    subscribedCategories: ['Emergency', 'Health']
  },
  {
    id: 'usr-pol-1',
    name: 'Insp. M. Anitha (Traffic Police)',
    email: 'police.traffic@idealcity360.gov.in',
    role: 'police_officer',
    phone: '+91 98480 10012',
    zone: 'Metropolitan Traffic Control Room',
    savedItemIds: [],
    subscribedCategories: ['Emergency', 'Transport']
  }
];

export const SEED_HOSPITALS: Hospital[] = [
  {
    id: 'hosp-1',
    name: 'Ideal City Central Government Super-Specialty Hospital',
    type: 'Government Super-Specialty',
    address: 'Sector 4, Raj Bhavan Road, Central Medical Enclave',
    phone: '040-2345-6789',
    emergencyPhone: '108 / 040-2345-6700',
    location: {
      lat: 17.4065,
      lng: 78.4772,
      area: 'Central Zone'
    },
    facilities: ['24x7 Trauma Care', 'Cath Lab', 'Free Pharmacy', 'Digital ICU', 'Dialysis Unit', 'CT/MRI 3 Tesla'],
    bedCount: {
      total: 850,
      available: 142,
      icu: 28
    },
    rating: 4.8,
    openHours: '24 Hours Emergency | OPD: 08:30 AM - 02:00 PM',
    verification: {
      sourceName: 'Directorate of Medical Education & Health Services',
      sourceUrl: 'https://health.telangana.gov.in/ideal-city-hospital',
      createdDate: '2026-01-10',
      lastUpdated: '2026-11-12T05:30:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-01-01',
      validUntil: '2027-12-31',
      verifiedBy: 'Dr. Vikramaditya Reddy (Medical Superintendent)',
      isDemoData: true,
      updateHistory: [
        { timestamp: '2026-11-12T05:30:00Z', action: 'Bed availability updated', user: 'hospital.admin@idealcity360.gov.in' }
      ]
    }
  },
  {
    id: 'hosp-2',
    name: 'Apollo Health City & Research Institute',
    type: 'Private Multi-Specialty',
    address: 'Plot 12, Jubilee Valley Boulevard, Cyber Corridor',
    phone: '040-2980-4400',
    emergencyPhone: '1066 / 040-2980-4499',
    location: {
      lat: 17.4258,
      lng: 78.4116,
      area: 'Cyber Zone'
    },
    facilities: ['Robotic Surgery', 'Organ Transplant Suite', 'Air Ambulance Pad', 'Level-3 NICU', 'PET-CT Scan', 'Preventive Health Pavilion'],
    bedCount: {
      total: 550,
      available: 64,
      icu: 12
    },
    rating: 4.9,
    openHours: '24 Hours Open | Specialist OPD: 09:00 AM - 06:00 PM',
    verification: {
      sourceName: 'Telangana State Clinical Establishments Registry',
      sourceUrl: 'https://tsce.gov.in/apollo-health-city',
      createdDate: '2026-02-14',
      lastUpdated: '2026-11-11T18:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-01-01',
      validUntil: '2027-06-30',
      verifiedBy: 'State Healthcare Quality Auditor',
      isDemoData: true,
      updateHistory: [
        { timestamp: '2026-11-11T18:00:00Z', action: 'NABH Accreditation renewed', user: 'admin@idealcity360.gov.in' }
      ]
    }
  },
  {
    id: 'hosp-3',
    name: 'KIMS Sunshine Advanced Bone & Heart Institute',
    type: 'Private Multi-Specialty',
    address: 'Near Paradise Circle, Secunderabad Station Road',
    phone: '040-4455-8899',
    emergencyPhone: '040-4455-8800',
    location: {
      lat: 17.4435,
      lng: 78.4983,
      area: 'North Zone'
    },
    facilities: ['Joint Replacement Pavilion', 'Minimally Invasive Spine Center', 'Cardiothoracic ICU', 'Day Care Surgery'],
    bedCount: {
      total: 380,
      available: 48,
      icu: 9
    },
    rating: 4.7,
    openHours: '24 Hours Open',
    verification: {
      sourceName: 'District Medical & Health Office (DMHO)',
      sourceUrl: 'https://dmho.idealcity.gov.in/registered-providers',
      createdDate: '2026-03-01',
      lastUpdated: '2026-11-10T09:15:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-01-01',
      validUntil: '2027-03-31',
      verifiedBy: 'DMHO Inspection Officer',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'hosp-4',
    name: 'Ideal City Mother & Child Welfare Hospital (Niloufer Annex)',
    type: 'Maternity & Child Hospital',
    address: 'Red Hills, Hospital Road, Old City Link',
    phone: '040-2339-1122',
    emergencyPhone: '040-2339-1199',
    location: {
      lat: 17.3980,
      lng: 78.4621,
      area: 'South Zone'
    },
    facilities: ['Advanced Neonatal ICU', 'Free Institutional Delivery', 'Kangaroo Mother Care', 'High Risk Pregnancy Unit', 'Pediatric Surgery'],
    bedCount: {
      total: 420,
      available: 78,
      icu: 16
    },
    rating: 4.6,
    openHours: '24 Hours Emergency | Maternal OPD: 09:00 AM - 01:00 PM',
    verification: {
      sourceName: 'Commissioner of Family Welfare, Govt of Telangana',
      sourceUrl: 'https://familywelfare.ts.gov.in/niloufer-annex',
      createdDate: '2026-01-20',
      lastUpdated: '2026-11-08T11:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-01-01',
      validUntil: '2027-12-31',
      verifiedBy: 'State Maternal Health Officer',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_DOCTORS: Doctor[] = [
  {
    id: 'doc-1',
    name: 'Dr. Anand Kumar Swaminathan, MD, DM',
    qualification: 'MBBS, MD (General Medicine), DM (Cardiology), FACC',
    specialization: 'Cardiology',
    hospitalId: 'hosp-1',
    hospitalName: 'Ideal City Central Government Super-Specialty Hospital',
    experienceYears: 22,
    consultationFee: 0, // Free at Gov Hospital
    availableDays: ['Monday', 'Wednesday', 'Friday'],
    timings: '09:00 AM - 01:30 PM',
    rating: 4.9,
    verification: {
      sourceName: 'National Medical Commission (NMC) Registry',
      sourceUrl: 'https://nmc.org.in/doctor-verification/TS-28491',
      createdDate: '2026-01-15',
      lastUpdated: '2026-11-05T10:00:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'Medical Superintendent',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'doc-2',
    name: 'Dr. Pratyusha Varma, MS, MCh (AIIMS)',
    qualification: 'MBBS, MS (Surgery), MCh (Neuro Surgery)',
    specialization: 'Neurology',
    hospitalId: 'hosp-2',
    hospitalName: 'Apollo Health City & Research Institute',
    experienceYears: 16,
    consultationFee: 1200,
    availableDays: ['Tuesday', 'Thursday', 'Saturday'],
    timings: '10:00 AM - 04:00 PM',
    rating: 4.9,
    verification: {
      sourceName: 'Apollo Credentialing Board',
      sourceUrl: 'https://apollohealthcity.com/doctors/pratyusha-varma',
      createdDate: '2026-02-10',
      lastUpdated: '2026-11-01T08:00:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'Chief of Medical Services',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'doc-3',
    name: 'Dr. Rajeshwar Rao Kothapalli, MS (Ortho)',
    qualification: 'MBBS, MS (Orthopedics), Fellow in Robotic Joint Replacement (Germany)',
    specialization: 'Orthopedics',
    hospitalId: 'hosp-3',
    hospitalName: 'KIMS Sunshine Advanced Bone & Heart Institute',
    experienceYears: 19,
    consultationFee: 900,
    availableDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    timings: '11:00 AM - 05:00 PM',
    rating: 4.8,
    verification: {
      sourceName: 'Telangana Medical Council',
      sourceUrl: 'https://tgmc.gov.in/verified/19842',
      createdDate: '2026-03-05',
      lastUpdated: '2026-10-28T14:30:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'TGMC Registrar',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'doc-4',
    name: 'Dr. Farhana Begum, MD, DCH',
    qualification: 'MBBS, MD (Pediatrics), DCH, Fellowship in Neonatal Intensive Care',
    specialization: 'Pediatrics',
    hospitalId: 'hosp-4',
    hospitalName: 'Ideal City Mother & Child Welfare Hospital (Niloufer Annex)',
    experienceYears: 14,
    consultationFee: 0,
    availableDays: ['Monday', 'Wednesday', 'Thursday', 'Saturday'],
    timings: '08:30 AM - 01:00 PM',
    rating: 4.8,
    verification: {
      sourceName: 'Directorate of Public Health',
      sourceUrl: 'https://health.ts.gov.in/doctors/farhana-begum',
      createdDate: '2026-01-25',
      lastUpdated: '2026-11-02T16:00:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'District Health Officer',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_DOCTOR_VISITS: DoctorVisit[] = [
  {
    id: 'visit-1',
    doctorName: 'Dr. Anand Kumar Swaminathan, MD, DM',
    specialization: 'Senior Interventional Cardiologist',
    hospitalId: 'hosp-1',
    hospitalName: 'Ideal City Central Government Super-Specialty Hospital',
    visitDate: '2026-11-14',
    consultationHours: '09:00 AM - 01:30 PM (Token slots)',
    appointmentLink: 'https://idealcity.gov.in/opd-booking/cardiocentral',
    roomNumber: 'OPD Block A - Chamber 104',
    tokenCapacity: 45,
    bookedTokens: 32,
    status: 'Scheduled',
    verification: {
      sourceName: 'Govt Hospital OPD Roster System',
      sourceUrl: 'https://idealcityhosp.gov.in/rosters/cardiology-nov',
      createdDate: '2026-11-01',
      lastUpdated: '2026-11-12T04:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-11-01',
      validUntil: '2026-11-14',
      verifiedBy: 'OPD Superintendent S. Ramana',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'visit-2',
    doctorName: 'Dr. Pratyusha Varma, MS, MCh',
    specialization: 'Consultant Neurosurgeon & Spine Specialist',
    hospitalId: 'hosp-2',
    hospitalName: 'Apollo Health City & Research Institute',
    visitDate: '2026-11-15',
    consultationHours: '10:30 AM - 03:30 PM',
    appointmentLink: 'https://apollohealthcity.com/book-slot/neuro-varma',
    roomNumber: 'Platinum Tower 2 - Suite 308',
    tokenCapacity: 25,
    bookedTokens: 18,
    status: 'Scheduled',
    verification: {
      sourceName: 'Apollo Hospital Management Portal',
      sourceUrl: 'https://apollohealthcity.com/rosters/neuro',
      createdDate: '2026-11-05',
      lastUpdated: '2026-11-11T12:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-11-05',
      validUntil: '2026-11-15',
      verifiedBy: 'Clinical Coordinator Radhika',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'visit-3',
    doctorName: 'Dr. B. Sudarshan Reddy, MS, MCh (Surgical Oncology)',
    specialization: 'Visiting Senior Onco-Surgeon (Tata Memorial Alumnus)',
    hospitalId: 'hosp-1',
    hospitalName: 'Ideal City Central Government Super-Specialty Hospital',
    visitDate: '2026-11-18',
    consultationHours: '09:30 AM - 04:00 PM (Free Screening & Evaluation)',
    appointmentLink: 'https://idealcity.gov.in/onco-care/nov18',
    roomNumber: 'Comprehensive Cancer Block - Suite 2',
    tokenCapacity: 50,
    bookedTokens: 41,
    status: 'Scheduled',
    verification: {
      sourceName: 'National Health Mission State Cell',
      sourceUrl: 'https://nhm.telangana.gov.in/visiting-specialists',
      createdDate: '2026-11-08',
      lastUpdated: '2026-11-12T02:30:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-11-08',
      validUntil: '2026-11-18',
      verifiedBy: 'NHM State Coordinator Dr. Mallikarjun',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_VACANCIES: HospitalVacancy[] = [
  {
    id: 'vac-1',
    hospitalId: 'hosp-1',
    hospitalName: 'Ideal City Central Government Super-Specialty Hospital',
    title: 'Staff Nurse Grade-II (Critical Care & Emergency ICU)',
    department: 'Intensive Care & Emergency Medicine',
    roleType: 'Nurse',
    qualifications: 'B.Sc Nursing / GNM with State Nursing Council registration and min 2 years ICU experience',
    eligibility: 'Age 21-38 years (Age relaxation applicable as per state govt norms)',
    positions: 35,
    deadline: '2026-11-28',
    applicationLink: 'https://idealcity.gov.in/recruitment/nurse-grade2-2026',
    salaryRange: '₹42,000 - ₹56,000 / month + DA & HRA (Govt Scale)',
    verification: {
      sourceName: 'Telangana Medical & Health Services Recruitment Board (MHSRB)',
      sourceUrl: 'https://mhsrb.telangana.gov.in/notifications/notif-08-2026.pdf',
      createdDate: '2026-10-25',
      lastUpdated: '2026-11-10T11:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-10-25',
      validUntil: '2026-11-28',
      verifiedBy: 'Secretary MHSRB',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'vac-2',
    hospitalId: 'hosp-1',
    hospitalName: 'Ideal City Central Government Super-Specialty Hospital',
    title: 'Senior Resident Doctor (Pediatrics & Neonatology)',
    department: 'Pediatrics Department',
    roleType: 'Doctor',
    qualifications: 'MD / DNB in Pediatrics recognized by NMC',
    eligibility: 'Completed residency within last 3 years; registered with State Council',
    positions: 8,
    deadline: '2026-11-25',
    applicationLink: 'https://idealcity.gov.in/recruitment/sr-pediatrics-2026',
    salaryRange: '₹95,000 - ₹1,15,000 / month',
    verification: {
      sourceName: 'Directorate of Medical Education Notification',
      sourceUrl: 'https://dme.telangana.gov.in/recruitment-sr-2026',
      createdDate: '2026-11-01',
      lastUpdated: '2026-11-09T14:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-11-01',
      validUntil: '2026-11-25',
      verifiedBy: 'DME Officer Dr. Sudhakar',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'vac-3',
    hospitalId: 'hosp-2',
    hospitalName: 'Apollo Health City & Research Institute',
    title: 'Dialysis & Cath Lab Technician',
    department: 'Nephrology & Interventional Cardiology',
    roleType: 'Technician',
    qualifications: 'Diploma / Degree in Dialysis Technology / Cardiac Care Tech with 1+ years experience',
    eligibility: 'Open to fresh certified graduates and experienced candidates',
    positions: 6,
    deadline: '2026-12-05',
    applicationLink: 'https://apollohealthcity.com/careers/technicians-nov26',
    salaryRange: '₹30,000 - ₹45,000 / month + Shift Allowance',
    verification: {
      sourceName: 'Apollo HR Official Portal',
      sourceUrl: 'https://apollohealthcity.com/careers',
      createdDate: '2026-11-06',
      lastUpdated: '2026-11-11T15:20:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-11-06',
      validUntil: '2026-12-05',
      verifiedBy: 'Talent Acquisition Lead Rajesh',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_HEALTH_CAMPS: HealthCamp[] = [
  {
    id: 'camp-1',
    title: 'Free Mega Diabetes, Hypertension & Cardiac Screening Camp',
    organizer: 'Ideal City Health Mission in partnership with Indian Red Cross',
    location: 'Community Center Grounds, Amberpet Circle, East Zone',
    date: '2026-11-22',
    timings: '08:00 AM - 03:00 PM',
    servicesProvided: ['Free Blood Sugar & HbA1c', 'ECG on the spot', 'Lipid Profile', 'Free Physician Consultation', 'Free Generic Medicines for 1 Month'],
    contactNumber: '040-2765-8800',
    freeMedicines: true,
    verification: {
      sourceName: 'District Health Society Official Notice',
      sourceUrl: 'https://dmho.idealcity.gov.in/camps/nov22-amberpet',
      createdDate: '2026-11-04',
      lastUpdated: '2026-11-12T01:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-11-04',
      validUntil: '2026-11-22',
      verifiedBy: 'District Health Officer',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'camp-2',
    title: 'Comprehensive Eye Examination & Cataract Detection Camp',
    organizer: 'Rotary Club of Smart City & Sarojini Devi Eye Hospital',
    location: 'Govt Boys High School Auditorium, Secunderabad Clock Tower',
    date: '2026-11-29',
    timings: '09:00 AM - 02:00 PM',
    servicesProvided: ['Computerized Refraction Eye Test', 'Free Spectacles for Seniors', 'Glaucoma & Retina Check', 'Free Cataract Surgery Registration with Transport'],
    contactNumber: '040-2460-3344',
    freeMedicines: true,
    verification: {
      sourceName: 'Govt Eye Hospital Outreach Registry',
      sourceUrl: 'https://sdeh.telangana.gov.in/camps',
      createdDate: '2026-11-07',
      lastUpdated: '2026-11-11T10:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-11-07',
      validUntil: '2026-11-29',
      verifiedBy: 'SDEH Outreach Superintendent',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_BUS_ROUTES: BusRoute[] = [
  {
    id: 'route-1',
    routeNumber: '100E',
    name: 'Smart Electric AC Express: Metro Hub - Cyber City - Airport Link',
    type: 'Smart Electric AC',
    source: 'Secunderabad Central Station',
    destination: 'Financial District Bio-Park Terminal',
    distanceKm: 28.5,
    travelTimeMinutes: 55,
    frequencyMinutes: 10,
    firstBus: '05:30 AM',
    lastBus: '11:45 PM',
    fareMin: 25,
    fareMax: 65,
    stops: [
      { id: 'st-1', name: 'Secunderabad Central Terminal', lat: 17.4334, lng: 78.5014, order: 1 },
      { id: 'st-2', name: 'Paradise Metro Junction', lat: 17.4418, lng: 78.4872, order: 2 },
      { id: 'st-3', name: 'Begumpet Airport Plaza', lat: 17.4475, lng: 78.4682, order: 3 },
      { id: 'st-4', name: 'Punjagutta Central Mall', lat: 17.4264, lng: 78.4528, order: 4 },
      { id: 'st-5', name: 'Banjara Hills Care Hospital', lat: 17.4156, lng: 78.4389, order: 5 },
      { id: 'st-6', name: 'Jubilee Checkpost', lat: 17.4296, lng: 78.4095, order: 6 },
      { id: 'st-7', name: 'HITEC City Cyber Towers', lat: 17.4504, lng: 78.3808, order: 7 },
      { id: 'st-8', name: 'Financial District Bio-Park Terminal', lat: 17.4168, lng: 78.3489, order: 8 }
    ],
    verification: {
      sourceName: 'Smart City Metropolitan Transport Corporation (TSRTC)',
      sourceUrl: 'https://tsrtc.telangana.gov.in/smart-city-100e',
      createdDate: '2026-01-01',
      lastUpdated: '2026-11-12T05:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-01-01',
      validUntil: '2027-12-31',
      verifiedBy: 'TSRTC Chief Traffic Manager',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'route-2',
    routeNumber: '218H',
    name: 'Healthcare & Heritage Express: Charminar - Central Hospital - Koti',
    type: 'Metro Feeder',
    source: 'Charminar Historical Gate',
    destination: 'Ideal City Central Government Super-Specialty Hospital',
    distanceKm: 14.2,
    travelTimeMinutes: 35,
    frequencyMinutes: 12,
    firstBus: '05:00 AM',
    lastBus: '11:00 PM',
    fareMin: 15,
    fareMax: 35,
    stops: [
      { id: 'st-201', name: 'Charminar Bus Depot', lat: 17.3616, lng: 78.4747, order: 1 },
      { id: 'st-202', name: 'Madina Building Junction', lat: 17.3688, lng: 78.4735, order: 2 },
      { id: 'st-203', name: 'Afzalgunj Osmania General Hospital', lat: 17.3775, lng: 78.4792, order: 3 },
      { id: 'st-204', name: 'Koti Women’s College Metro', lat: 17.3850, lng: 78.4867, order: 4 },
      { id: 'st-205', name: 'Ideal City Central Super-Specialty Hospital', lat: 17.4065, lng: 78.4772, order: 5 }
    ],
    verification: {
      sourceName: 'Smart Transit City Operations Room',
      sourceUrl: 'https://tsrtc.telangana.gov.in/routes/218h',
      createdDate: '2026-02-10',
      lastUpdated: '2026-11-12T05:15:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'Divisional Traffic Officer',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'route-3',
    routeNumber: '5K',
    name: 'North-South Arterial: Mehdipatnam - Secretariat - Secunderabad',
    type: 'Express City',
    source: 'Mehdipatnam Skywalk Bus Terminal',
    destination: 'Secunderabad Station (Gurudwara)',
    distanceKm: 18.0,
    travelTimeMinutes: 42,
    frequencyMinutes: 8,
    firstBus: '04:45 AM',
    lastBus: '11:30 PM',
    fareMin: 20,
    fareMax: 45,
    stops: [
      { id: 'st-301', name: 'Mehdipatnam Depot', lat: 17.3916, lng: 78.4402, order: 1 },
      { id: 'st-302', name: 'Masab Tank Flyover', lat: 17.4022, lng: 78.4498, order: 2 },
      { id: 'st-303', name: 'BR Ambedkar State Secretariat', lat: 17.4121, lng: 78.4705, order: 3 },
      { id: 'st-304', name: 'Tank Bund Ambedkar Statue', lat: 17.4239, lng: 78.4746, order: 4 },
      { id: 'st-305', name: 'Secunderabad Station', lat: 17.4334, lng: 78.5014, order: 5 }
    ],
    verification: {
      sourceName: 'TSRTC Greater City Zone',
      sourceUrl: 'https://tsrtc.telangana.gov.in/routes/5k',
      createdDate: '2026-01-01',
      lastUpdated: '2026-11-11T20:00:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'Traffic Superintendent',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_BUS_SCHEDULES: BusSchedule[] = [
  {
    id: 'sched-1',
    routeId: 'route-1',
    routeNumber: '100E',
    source: 'Secunderabad Central',
    destination: 'Financial District Bio-Park',
    currentStop: 'Punjagutta Central Mall',
    nextStop: 'Banjara Hills Care Hospital',
    scheduledTime: '09:10 AM',
    estimatedTime: '09:13 AM (Real-time GPS)',
    isLive: true,
    status: 'Delayed',
    delayMinutes: 3,
    busRegistrationNumber: 'TG-09-EV-4412 (Electric)',
    occupancy: 'Medium',
    verification: {
      sourceName: 'Smart City Intelligent Transit System (ITS Telematics)',
      sourceUrl: 'https://its.idealcity360.gov.in/bus-tracking/TG09EV4412',
      createdDate: '2026-11-12',
      lastUpdated: '2026-11-12T06:30:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'Automated GPS Telematics Gateway',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'sched-2',
    routeId: 'route-1',
    routeNumber: '100E',
    source: 'Secunderabad Central',
    destination: 'Financial District Bio-Park',
    currentStop: 'HITEC City Cyber Towers',
    nextStop: 'Financial District Bio-Park Terminal',
    scheduledTime: '09:20 AM',
    estimatedTime: '09:20 AM (On Time)',
    isLive: true,
    status: 'On Time',
    delayMinutes: 0,
    busRegistrationNumber: 'TG-09-EV-4488 (Electric)',
    occupancy: 'High',
    verification: {
      sourceName: 'Smart City Intelligent Transit System (ITS Telematics)',
      sourceUrl: 'https://its.idealcity360.gov.in/bus-tracking/TG09EV4488',
      createdDate: '2026-11-12',
      lastUpdated: '2026-11-12T06:32:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'Automated GPS Telematics Gateway',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'sched-3',
    routeId: 'route-2',
    routeNumber: '218H',
    source: 'Charminar Bus Depot',
    destination: 'Ideal City Central Hospital',
    currentStop: 'Afzalgunj Osmania General Hospital',
    nextStop: 'Koti Women’s College Metro',
    scheduledTime: '09:15 AM',
    estimatedTime: '09:15 AM (On Schedule)',
    isLive: false, // Clearly distinguish scheduled timings from actual live bus tracking!
    status: 'On Time',
    delayMinutes: 0,
    busRegistrationNumber: 'TG-09-Z-1890 (Standard Timetable)',
    occupancy: 'Medium',
    verification: {
      sourceName: 'Published RTO Municipal Transit Timetable',
      sourceUrl: 'https://tsrtc.telangana.gov.in/timetables/218h',
      createdDate: '2026-11-01',
      lastUpdated: '2026-11-12T04:30:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'RTO Depot Supervisor',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_TRANSPORT_ALERTS: TransportAlert[] = [
  {
    id: 'talert-1',
    title: 'Route 100E & 5K: Minor Diversion at Panjagutta Flyover Maintenance',
    routeNumber: '100E / 5K',
    type: 'Route Change',
    message: 'Due to scheduled asphalt resurfacing at Panjagutta flyover ramp, buses are routed via Nagarjuna Circle road. Expected delay 4-6 minutes.',
    effectiveFrom: '2026-11-12 00:00',
    effectiveUntil: '2026-11-14 23:59',
    verification: {
      sourceName: 'City Traffic Police & RTO Joint Advisory',
      sourceUrl: 'https://trafficpolice.idealcity.gov.in/advisories/2026-11-12',
      createdDate: '2026-11-11',
      lastUpdated: '2026-11-12T03:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-11-12',
      validUntil: '2026-11-14',
      verifiedBy: 'Joint Commissioner of Traffic Police',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'talert-2',
    title: 'Peak Hour Boost: 12 Additional Electric Buses on Metro Feeder Routes',
    routeNumber: 'All Metro Feeders',
    type: 'Delay', // positive boost
    message: 'To reduce wait times, frequency enhanced from 15 min to 8 min between 08:00 AM - 11:30 AM and 05:00 PM - 08:30 PM.',
    effectiveFrom: '2026-11-10',
    effectiveUntil: '2026-12-31',
    verification: {
      sourceName: 'TSRTC Operations Press Release',
      sourceUrl: 'https://tsrtc.telangana.gov.in/press/peak-hour-ev-boost',
      createdDate: '2026-11-09',
      lastUpdated: '2026-11-10T10:00:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'Transport Administrator',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_GOVERNMENT_RULES: GovernmentRule[] = [
  {
    id: 'gov-rule-1',
    title: 'Aarogyasri Health Care Trust - Universal Free Critical Care Scheme',
    department: 'Health & Sanitation',
    summary: 'Provides cashless medical coverage up to ₹10 Lakhs per family per year for 1,672 listed super-specialty and secondary surgeries and therapies in empanelled government and private hospitals.',
    eligibility: [
      'Resident family of the state holding Food Security Card (White Ration Card)',
      'Annual family income below ₹2,00,000 (urban) or ₹1,50,000 (rural)',
      'Patient must possess valid Aadhaar card and registered mobile number',
      'Treatment must be for listed secondary or tertiary surgical/medical conditions'
    ],
    requiredDocuments: [
      'Original Food Security Card (White Ration Card) or Aarogyasri Card',
      'Aadhaar Card of the patient and family head',
      'Doctor referral slip from Primary Health Center (PHC) / Government Hospital',
      'Recent passport-size photograph'
    ],
    applicationSteps: [
      'Visit any Empanelled Network Hospital Aarogyasri Helpdesk with White Ration Card and Aadhaar',
      'The Aarogya Mithra desk officer verifies eligibility via online portal biometric check',
      'Treating specialist submits pre-authorization request with diagnostic scans',
      'Trust approves cashless treatment within 12-24 hours (immediate for trauma emergencies)',
      'Cashless treatment, surgery, post-op medicine and follow-up consultation provided free'
    ],
    applicationFee: 'Nil (Strictly 100% Free under official Govt Order G.O.Ms.No. 68)',
    effectiveDate: '2024-01-01',
    expiryDate: '2030-12-31',
    officialSourceUrl: 'https://aarogyasri.telangana.gov.in/guidelines-2026.pdf',
    pdfTitle: 'Aarogyasri_Scheme_Comprehensive_Manual_GOMs68.pdf',
    pdfSummary: 'Official Government Order detailing full cashless limits, 1672 surgical packages, network hospital grievance redressal, and zero-fee statutory guarantee.',
    verification: {
      sourceName: 'Department of Health, Medical & Family Welfare, Govt of Telangana',
      sourceUrl: 'https://aarogyasri.telangana.gov.in',
      createdDate: '2026-01-05',
      lastUpdated: '2026-11-10T12:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2024-01-01',
      validUntil: '2030-12-31',
      verifiedBy: 'Dr. K. Srinivas (Aarogyasri Trust Executive Officer)',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'gov-rule-2',
    title: 'Issuance of Digital Birth Certificate within 21 Days (GHMC Citizen Charter)',
    department: 'Civic & Municipality',
    summary: 'Statutory citizen charter guaranteeing automated digital issuance of birth certificates within 21 days of birth institutional registration without in-person office visits.',
    eligibility: [
      'Birth occurring within municipal corporation boundaries',
      'Reporting by the hospital within 21 days of occurrence is free of charge',
      'Applicable for both institutional (hospital) and documented home births'
    ],
    requiredDocuments: [
      'Form-1 Hospital Birth Record Slip signed by Medical Record Officer',
      'Parents Aadhaar Cards & Mobile Numbers',
      'Marriage Certificate or joint declaration (optional but recommended for names)'
    ],
    applicationSteps: [
      'Hospital enters birth details into the State Civil Registration System (CRS) portal at discharge',
      'Parents receive SMS notification with Registration Number & OTP link',
      'Log into the Ideal City MeeSeva portal, confirm child’s name within 1 year',
      'Download digitally signed QR-code birth certificate immediately in PDF format'
    ],
    applicationFee: '₹0 if reported within 21 days. ₹35 statutory service fee at MeeSeva counter if downloaded in physical embossed card format.',
    effectiveDate: '2025-04-01',
    officialSourceUrl: 'https://ghmc.gov.in/citizen-charter/birth-death-registration',
    pdfTitle: 'GHMC_Citizen_Charter_Birth_Certificate_2026.pdf',
    pdfSummary: 'Legal framework under Registration of Births and Deaths Act detailing zero delay timelines and statutory appeal mechanisms.',
    verification: {
      sourceName: 'Greater Hyderabad Municipal Corporation Citizen Services',
      sourceUrl: 'https://ghmc.gov.in',
      createdDate: '2026-02-15',
      lastUpdated: '2026-11-08T09:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2025-04-01',
      validUntil: '2028-03-31',
      verifiedBy: 'Municipal Registrar K. Shailaja',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'gov-rule-3',
    title: 'Solar Rooftop Subsidy Scheme (PM Surya Ghar: Muft Bijli Yojana)',
    department: 'Urban Planning & Housing',
    summary: 'Provides direct financial assistance up to ₹78,000 for installing grid-connected residential rooftop solar plants (up to 3kW capacity), offering up to 300 free units of electricity per month.',
    eligibility: [
      'Residential electricity consumer with valid domestic meter connection',
      'Must have adequate shadow-free roof area (approx. 100 sq ft per 1 kW)',
      'Solar panels and inverters must comply with ALMM (Approved List of Models & Manufacturers)'
    ],
    requiredDocuments: [
      'Latest residential electricity bill (with consumer account number)',
      'Proof of ownership of premises or permission letter from landlord/society',
      'Bank passbook copy (cancelled cheque) for direct DBT subsidy credit',
      'Aadhaar card of consumer'
    ],
    applicationSteps: [
      'Register on National Solar Rooftop Portal with Consumer Number and DISCOM name',
      'Choose an empanelled vendor in Ideal City for site feasibility assessment',
      'DISCOM technical sanction issued online within 15 working days',
      'Vendor installs solar system and applies for net meter commissioning',
      'DISCOM inspects net meter and releases direct bank subsidy within 30 days of commissioning'
    ],
    applicationFee: 'Nil portal fee. Net meter inspection fee of ₹1,000 paid to DISCOM.',
    effectiveDate: '2024-03-01',
    expiryDate: '2027-03-31',
    officialSourceUrl: 'https://pmsuryaghar.gov.in/guidelines',
    pdfTitle: 'PM_Surya_Ghar_Operational_Guidelines_2026.pdf',
    pdfSummary: 'Operational guidelines detailing subsidy slabs: ₹30,000 for 1kW, ₹60,000 for 2kW, and ₹78,000 for 3kW systems.',
    verification: {
      sourceName: 'Ministry of New & Renewable Energy & State DISCOM (TSSPDCL)',
      sourceUrl: 'https://tsspdcl.gov.in/solar-rooftop',
      createdDate: '2026-03-10',
      lastUpdated: '2026-11-11T16:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2024-03-01',
      validUntil: '2027-03-31',
      verifiedBy: 'Superintending Engineer (Energy)',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_JOBS: JobListing[] = [
  {
    id: 'job-1',
    title: 'Assistant Executive Engineer (Civil & Public Health) - 240 Posts',
    organization: 'Telangana Public Service Commission (TSPSC)',
    sector: 'Government',
    type: 'Full-time',
    qualification: 'Bachelor’s Degree in Civil Engineering / Environmental Engineering from recognized University',
    vacancies: 240,
    deadline: '2026-12-15',
    applicationLink: 'https://tspsc.gov.in/direct-recruitment/aee-2026',
    location: 'Statewide Urban Development & Irrigation Departments',
    salary: '₹54,220 - ₹1,33,630 / month + State Allowances',
    verification: {
      sourceName: 'TSPSC Official Notification Gazetted Notif. 14/2026',
      sourceUrl: 'https://tspsc.gov.in/notifications/14-2026',
      createdDate: '2026-10-30',
      lastUpdated: '2026-11-11T14:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-10-30',
      validUntil: '2026-12-15',
      verifiedBy: 'Secretary TSPSC',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'job-2',
    title: 'Smart City Data & GIS Analyst Internship (Spring 2027 Cohort)',
    organization: 'Ideal City Digital Innovation Center (Govt-Industry Hub)',
    sector: 'Government',
    type: 'Internship',
    qualification: 'Pursuing or graduated in Computer Science, Data Science, Urban Planning or Geo-Informatics',
    vacancies: 20,
    deadline: '2026-12-10',
    applicationLink: 'https://idealcity360.gov.in/careers/gis-internship',
    location: 'Cyber Gateway Tech Hub, Floor 6',
    salary: '₹25,000 / month Stipend + Certification & PPO Opportunity',
    verification: {
      sourceName: 'Smart City Innovation Society Registry',
      sourceUrl: 'https://idealcity.gov.in/innovation/internships',
      createdDate: '2026-11-02',
      lastUpdated: '2026-11-12T01:30:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-11-02',
      validUntil: '2026-12-10',
      verifiedBy: 'Chief Technology Officer',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'job-3',
    title: 'Dr. BR Ambedkar Merit Scholarship for Professional Higher Education',
    organization: 'Department of Social Welfare & Collegiate Education',
    sector: 'Government',
    type: 'Scholarship',
    qualification: 'Enrolled in 1st year B.Tech, MBBS, Law, or MBA with 80%+ in intermediate / 12th',
    vacancies: 1500,
    deadline: '2026-12-31',
    applicationLink: 'https://telanganaepass.cgg.gov.in/scholarships-2026',
    location: 'Colleges across Ideal City & State',
    salary: '100% Tuition Fee Reimbursement + ₹20,000 / year Maintenance Allowance',
    verification: {
      sourceName: 'Telangana ePass Official Portal',
      sourceUrl: 'https://telanganaepass.cgg.gov.in',
      createdDate: '2026-09-01',
      lastUpdated: '2026-11-10T11:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-09-01',
      validUntil: '2026-12-31',
      verifiedBy: 'Director of Social Welfare',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_EDUCATION: EducationService[] = [
  {
    id: 'edu-1',
    title: 'Smart City Digital Skills & AI Literacy Mission',
    institution: 'Ideal City Skills Academy in collaboration with IIT Hyderabad',
    category: 'Skill Programme',
    description: 'Free 12-week comprehensive bootcamp in Python, AI Prompt Engineering, Cloud Infrastructure, and Digital Citizen Tools for students and working professionals.',
    eligibility: 'Residents of Ideal City aged 18-35; basic computer knowledge',
    applicationLink: 'https://skills.idealcity.gov.in/ai-mission-2026',
    deadline: '2026-12-01',
    contactEmail: 'admissions@skills.idealcity.gov.in',
    verification: {
      sourceName: 'Telangana Academy for Skill and Knowledge (TASK)',
      sourceUrl: 'https://task.telangana.gov.in/ideal-city-bootcamp',
      createdDate: '2026-10-15',
      lastUpdated: '2026-11-11T12:00:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-10-15',
      validUntil: '2026-12-01',
      verifiedBy: 'TASK Director',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'edu-2',
    title: 'Ideal City Public Central Digital Library & Competitive Study Center',
    institution: 'City Grandhalaya Samstha (Public Libraries Board)',
    category: 'Online Resource',
    description: 'Access to 1,20,000+ digital books, UPSC/TSPSC competitive examination mock tests, IEEE journals, high-speed Wi-Fi, and soundproof study cubicles.',
    eligibility: 'All students and citizens; Free biometric library membership card',
    applicationLink: 'https://library.idealcity.gov.in/membership-portal',
    contactEmail: 'librarian@idealcity.gov.in',
    verification: {
      sourceName: 'State Grandhalaya Parishad',
      sourceUrl: 'https://publiclibraries.ts.gov.in',
      createdDate: '2026-01-10',
      lastUpdated: '2026-11-05T08:00:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'Chief Librarian',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_SOCIAL_WELFARE: SocialWelfareService[] = [
  {
    id: 'welf-1',
    title: 'Senior Citizen Day Care, Physiotherapy & Legal Support Center',
    category: 'Senior Citizen',
    provider: 'Department for Empowerment of Senior Citizens & Vridha Mitra NGO',
    contactPhone: '040-2345-9988 / Toll-Free: 14567 (Elder Line)',
    address: 'Near Gandhi Park, Road No. 3, Jubilee Enclave',
    description: 'Free daily health check-ups, geriatric physiotherapy, emotional counseling, nutritious lunch, recreation room, and free legal aid for property dispute protection under the Maintenance and Welfare of Parents Act.',
    timings: '08:30 AM - 05:30 PM (Monday to Saturday)',
    eligibility: 'Senior citizens aged 60 and above with valid ID',
    verification: {
      sourceName: 'Elder Line 14567 National Registry',
      sourceUrl: 'https://elderline.dosje.gov.in',
      createdDate: '2026-01-20',
      lastUpdated: '2026-11-10T10:00:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'Senior Citizen Welfare Officer',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'welf-2',
    title: 'SHE Team Women Safety & Rapid Crisis Response Center',
    category: 'Women Safety',
    provider: 'Ideal City Police Commissionerate Women Safety Wing',
    contactPhone: 'Emergency: 100 / WhatsApp Hotline: 9441669988 / SHE Team Desk: 040-2785-2345',
    address: 'Police Headquarters Campus, Basheerbagh',
    description: 'Dedicated 24x7 crisis intervention, safe shelter accommodation, immediate legal & police protection against harassment/stalking, trauma psychological counseling, and cyber forensics support for women and children.',
    timings: '24 Hours Open Every Day',
    eligibility: 'Open to any woman facing distress, threat, harassment, or domestic violence',
    verification: {
      sourceName: 'Telangana Police Women Safety Wing',
      sourceUrl: 'https://womensafetywing.telangana.gov.in/she-teams',
      createdDate: '2026-01-01',
      lastUpdated: '2026-11-12T04:30:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'DCP Women Safety Wing',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'welf-3',
    title: 'Annapurna Community Kitchen & Food Rescue Hub',
    category: 'Food Donation & Kitchen',
    provider: 'Hare Krishna Movement in partnership with GHMC Municipal Corporation',
    contactPhone: '040-2339-4455',
    address: '150 Distribution Kiosks across General Hospitals, Labor Hubs & Railway Stations',
    description: 'Provides hot, hygienic, wholesome meals (Rice, Sambar, Vegetable Curry) for just ₹5 to laborers, patient attendants, and citizens. Also collects surplus hygienic banquet food for distribution to homeless shelters.',
    timings: 'Lunch: 11:30 AM - 02:30 PM | Dinner: 07:00 PM - 09:00 PM',
    verification: {
      sourceName: 'GHMC Community Welfare Division',
      sourceUrl: 'https://ghmc.gov.in/annapurna-meals',
      createdDate: '2026-02-01',
      lastUpdated: '2026-11-11T13:00:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'Municipal Welfare Officer',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_EMERGENCY_CONTACTS: EmergencyContact[] = [
  { id: 'em-1', serviceName: 'Police Emergency Response Control', phone: '100 / 112', availableHours: '24 Hours', category: 'Police', tollFree: true },
  { id: 'em-2', serviceName: 'Government Emergency Medical Ambulance', phone: '108', availableHours: '24 Hours', category: 'Ambulance', tollFree: true },
  { id: 'em-3', serviceName: 'City Fire & Disaster Rescue Services', phone: '101', availableHours: '24 Hours', category: 'Fire', tollFree: true },
  { id: 'em-4', serviceName: 'Women in Distress National Helpline', phone: '1091 / 181', availableHours: '24 Hours', category: 'Women Helpline', tollFree: true },
  { id: 'em-5', serviceName: 'Childline Care & Protection', phone: '1098', availableHours: '24 Hours', category: 'Childcare Helpline', tollFree: true },
  { id: 'em-6', serviceName: 'City Disaster Management & Waterlogging Desk', phone: '040-2111-1111 / 1077', availableHours: '24 Hours', category: 'Disaster Management', tollFree: true }
];

export const SEED_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'Drinking Water Pipeline Interconnection at Central Hub: Scheduled Pressure Modulation',
    category: 'Civic',
    summary: 'Water Board is carrying out 24-inch pipeline interconnection at Central Spine. Water supplies will maintain optimal gravity pressure with no complete shutdown.',
    detailedText: 'Ideal City Water Supply & Sewerage Board (HMWSSB) confirms technical upgrade work between 06:00 AM on Nov 14 to 06:00 PM on Nov 14. Citizens are advised to store adequate water as a precautionary step. Free municipal water tankers can be booked via Dial-A-Tanker 155313.',
    publishedAt: '2026-11-12T04:00:00Z',
    isUrgent: false,
    officialSource: 'HMWSSB Engineering Operations Notice',
    verification: {
      sourceName: 'HMWSSB Press Bureau',
      sourceUrl: 'https://hyderabadwater.gov.in/press/notice-nov12',
      createdDate: '2026-11-12',
      lastUpdated: '2026-11-12T04:00:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'HMWSSB Public Relations Officer',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'ann-2',
    title: 'Intensified Pulse Polio & Measles-Rubella Vaccination Drive Announced',
    category: 'Health',
    summary: 'National immunization booths will operate across 850 metro stations, bus terminals, parks and primary health centers on Sunday, Nov 23.',
    detailedText: 'All children under 5 years of age must be administered oral polio drops irrespective of previous doses. Mobile transit vaccination teams will cover airport gates, railway stations and interstate bus terminals.',
    publishedAt: '2026-11-11T10:00:00Z',
    isUrgent: true,
    officialSource: 'State Immunization Bureau & WHO India',
    verification: {
      sourceName: 'Directorate of Public Health (DPH)',
      sourceUrl: 'https://dph.telangana.gov.in/pulse-polio-2026',
      createdDate: '2026-11-11',
      lastUpdated: '2026-11-11T10:00:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'State Immunization Officer Dr. Nirmala',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'ann-3',
    title: 'Smart E-Bus Corridor 100E Green Fleet Expansion Inauguration',
    category: 'Transport',
    summary: '40 new ultra-low floor zero-emission electric buses inducted into the Cyber Corridor route with contactless tap-and-pay and wheelchair ramps.',
    detailedText: 'Minister for Transport dedicated 40 new 12-meter electric air-conditioned buses to the public. Headway reduced from 15 minutes to 8 minutes during morning and evening rush hours.',
    publishedAt: '2026-11-10T14:30:00Z',
    isUrgent: false,
    officialSource: 'TSRTC Managing Director Communique',
    verification: {
      sourceName: 'TSRTC Public Relations Office',
      sourceUrl: 'https://tsrtc.telangana.gov.in/ev-expansion-2026',
      createdDate: '2026-11-10',
      lastUpdated: '2026-11-10T14:30:00Z',
      verificationStatus: 'Verified',
      verifiedBy: 'TSRTC PRO',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_COMPLAINTS: Complaint[] = [
  {
    id: 'cmp-101',
    ticketNumber: 'IDC-2026-08912',
    citizenId: 'usr-citizen-1',
    citizenName: 'Srinivas Rao',
    citizenEmail: 'citizen@idealcity360.gov.in',
    title: 'Streetlight failure and pothole on Hospital Access Road near Gate 2',
    category: 'Sanitation & Roads',
    description: 'Three continuous sodium streetlights are non-functional for past 4 days, causing severe visibility issues for ambulances and pedestrians turning into the emergency gate.',
    location: 'Sector 4, Raj Bhavan Road, outside Ideal City Central Hospital',
    imageUrl: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600&auto=format&fit=crop&q=80',
    status: 'In Progress',
    priority: 'High',
    createdAt: '2026-11-10T18:20:00Z',
    updatedAt: '2026-11-11T09:40:00Z',
    adminNotes: 'Assigned to Electrical Engineering Wing Ward 92. Replacement LED fixtures dispatched. Expected resolution within 24 hours.'
  },
  {
    id: 'cmp-102',
    ticketNumber: 'IDC-2026-08744',
    citizenId: 'usr-citizen-1',
    citizenName: 'Srinivas Rao',
    citizenEmail: 'citizen@idealcity360.gov.in',
    title: 'Bus display screen blank at Paradise Metro Bus Shelter',
    category: 'Public Transport',
    description: 'The real-time arrival countdown display screen at bay 3 has been powered off since yesterday morning.',
    location: 'Paradise Metro Interchange Bus Bay 3',
    status: 'Resolved',
    priority: 'Medium',
    createdAt: '2026-11-08T11:15:00Z',
    updatedAt: '2026-11-09T16:30:00Z',
    resolvedAt: '2026-11-09T16:30:00Z',
    adminNotes: 'Technician rebooted telematics gateway and replaced fuse. Real-time arrival schedule feed is now working normally.'
  }
];

export const SEED_WELLBEING_METRICS: CityWellBeingMetric[] = [
  {
    id: 'wb-1',
    category: 'Healthcare Accessibility',
    name: 'Healthcare Accessibility & ICU Readiness',
    score: 92,
    target: 95,
    unit: '%',
    status: 'Excellent',
    trend: 'up',
    historicalData: [
      { month: 'Jun', value: 85 },
      { month: 'Jul', value: 87 },
      { month: 'Aug', value: 89 },
      { month: 'Sep', value: 90 },
      { month: 'Oct', value: 91 },
      { month: 'Nov', value: 92 }
    ],
    keyHighlights: ['100% tertiary hospital beds integrated into live digital roster', 'Average emergency ambulance response time down to 8.4 minutes', 'Universal cashless Aarogyasri coverage for 1.8M families']
  },
  {
    id: 'wb-2',
    category: 'Public Transit & Mobility',
    name: 'Public Transit On-Time & Electrification',
    score: 87,
    target: 90,
    unit: '%',
    status: 'Good',
    trend: 'up',
    historicalData: [
      { month: 'Jun', value: 78 },
      { month: 'Jul', value: 81 },
      { month: 'Aug', value: 83 },
      { month: 'Sep', value: 85 },
      { month: 'Oct', value: 86 },
      { month: 'Nov', value: 87 }
    ],
    keyHighlights: ['62% of public transit fleet converted to electric zero-emission', 'GPS telematics coverage at 98.4% across urban stops', 'Metro-feeder synchronization within 3 minutes']
  },
  {
    id: 'wb-3',
    category: 'Public Safety & Women Security',
    name: 'Public Safety & Emergency Response Index',
    score: 94,
    target: 95,
    unit: '%',
    status: 'Excellent',
    trend: 'up',
    historicalData: [
      { month: 'Jun', value: 88 },
      { month: 'Jul', value: 90 },
      { month: 'Aug', value: 91 },
      { month: 'Sep', value: 92 },
      { month: 'Oct', value: 93 },
      { month: 'Nov', value: 94 }
    ],
    keyHighlights: ['Dial 100 response time: under 5 minutes citywide', '18,400 smart AI surveillance cameras covering dark spots', '24x7 SHE Team mobile patrols active across all 6 zones']
  },
  {
    id: 'wb-4',
    category: 'Environment & Air Quality',
    name: 'Air Quality & Clean Energy Index',
    score: 81,
    target: 85,
    unit: '%',
    status: 'Good',
    trend: 'stable',
    historicalData: [
      { month: 'Jun', value: 84 },
      { month: 'Jul', value: 85 },
      { month: 'Aug', value: 83 },
      { month: 'Sep', value: 82 },
      { month: 'Oct', value: 80 },
      { month: 'Nov', value: 81 }
    ],
    keyHighlights: ['Average AQI: 64 (Satisfactory - Green Zone)', '42 MW residential rooftop solar capacity installed this year', '100% mechanized street sweeping in high-traffic corridors']
  },
  {
    id: 'wb-5',
    category: 'Education & Digital Literacy',
    name: 'Education & Youth Skill Index',
    score: 89,
    target: 92,
    unit: '%',
    status: 'Good',
    trend: 'up',
    historicalData: [
      { month: 'Jun', value: 82 },
      { month: 'Jul', value: 84 },
      { month: 'Aug', value: 85 },
      { month: 'Sep', value: 87 },
      { month: 'Oct', value: 88 },
      { month: 'Nov', value: 89 }
    ],
    keyHighlights: ['100% digital classrooms in government schools', '98,000 students enrolled in free AI & technical skills mission', '15 public digital libraries opened 24x7']
  },
  {
    id: 'wb-6',
    category: 'Social Inclusion & Senior Welfare',
    name: 'Social Inclusion & Happiness Index',
    score: 88,
    target: 90,
    unit: '%',
    status: 'Good',
    trend: 'up',
    historicalData: [
      { month: 'Jun', value: 83 },
      { month: 'Jul', value: 85 },
      { month: 'Aug', value: 86 },
      { month: 'Sep', value: 87 },
      { month: 'Oct', value: 87 },
      { month: 'Nov', value: 88 }
    ],
    keyHighlights: ['Elder Line 14567 100% resolution rate within 48h', '150 Annapurna community kitchens serving 45,000 subsidized meals daily', 'Universal accessible ramps & tactile paving across municipal parks']
  }
];

export const SEED_BLOOD_BANKS: BloodBank[] = [
  {
    id: 'bb-1',
    name: 'Ideal City Central Government Blood Bank & Component Center',
    hospitalId: 'hosp-1',
    address: 'Block B, Ground Floor, Sector 4, Raj Bhavan Road, Central Medical Enclave',
    zone: 'Central Zone',
    lat: 17.4065,
    lng: 78.4772,
    phone: '040-2345-6790',
    emergencyPhone: '104 / 040-2345-6701',
    openHours: '24x7 Emergency Blood Issue & Donor Lounge (08:00 AM - 08:00 PM)',
    licenseNumber: 'TS-SBTC-LIC-2026-001',
    is24x7: true,
    componentSeparation: true,
    inventory: {
      'A+': 28,
      'A-': 5,
      'B+': 34,
      'B-': 7,
      'AB+': 14,
      'AB-': 2,
      'O+': 42,
      'O-': 3
    },
    verification: {
      sourceName: 'State Blood Transfusion Council (e-RaktKosh Sync)',
      sourceUrl: 'https://eraktkosh.idealcity.gov.in/central-govt-blood-bank',
      createdDate: '2026-01-12',
      lastUpdated: '2026-11-18T14:30:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-01-01',
      validUntil: '2027-12-31',
      verifiedBy: 'Dr. Vikramaditya Reddy (Blood Bank Medical Officer)',
      isDemoData: true,
      updateHistory: [
        { timestamp: '2026-11-18T14:30:00Z', action: 'Live unit inventory verified via e-RaktKosh', user: 'hospital.admin@idealcity360.gov.in' }
      ]
    }
  },
  {
    id: 'bb-2',
    name: 'Indian Red Cross Society — Ideal City Regional Blood Center',
    address: 'Red Cross Bhavan, Vidyanagar Cross Roads, North Zone',
    zone: 'North Zone',
    lat: 17.4048,
    lng: 78.5105,
    phone: '040-2763-3087',
    emergencyPhone: '040-2763-3099',
    openHours: '24x7 Component & Whole Blood Dispatch | Walk-in Donation 09:00 AM - 06:00 PM',
    licenseNumber: 'TS-SBTC-LIC-2026-014',
    is24x7: true,
    componentSeparation: true,
    inventory: {
      'A+': 22,
      'A-': 6,
      'B+': 26,
      'B-': 4,
      'AB+': 11,
      'AB-': 3,
      'O+': 31,
      'O-': 4
    },
    verification: {
      sourceName: 'Indian Red Cross Society & DMHO',
      sourceUrl: 'https://ircs.idealcity.gov.in/blood-center',
      createdDate: '2026-01-18',
      lastUpdated: '2026-11-18T15:10:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-01-01',
      validUntil: '2027-12-31',
      verifiedBy: 'State Blood Safety Auditor',
      isDemoData: true,
      updateHistory: [
        { timestamp: '2026-11-18T15:10:00Z', action: 'Platelet & PRBC stock refreshed', user: 'verifier@idealcity360.gov.in' }
      ]
    }
  },
  {
    id: 'bb-3',
    name: 'Apollo Health City Blood Bank & Apheresis Unit',
    hospitalId: 'hosp-2',
    address: 'Plot 12, Jubilee Valley Boulevard, Cyber Corridor',
    zone: 'Cyber Zone',
    lat: 17.4258,
    lng: 78.4116,
    phone: '040-2980-4450',
    emergencyPhone: '1066 / 040-2980-4499',
    openHours: '24x7 Trauma & Single Donor Platelet (SDP) Support',
    licenseNumber: 'TS-SBTC-LIC-2026-029',
    is24x7: true,
    componentSeparation: true,
    inventory: {
      'A+': 19,
      'A-': 3,
      'B+': 24,
      'B-': 2,
      'AB+': 9,
      'AB-': 1,
      'O+': 25,
      'O-': 2
    },
    verification: {
      sourceName: 'NABH Accredited Blood Services Registry',
      sourceUrl: 'https://apollo.idealcity.gov.in/blood-bank',
      createdDate: '2026-02-05',
      lastUpdated: '2026-11-18T13:45:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-01-01',
      validUntil: '2027-06-30',
      verifiedBy: 'Dr. Meera Krishnan (Transfusion Medicine)',
      isDemoData: true,
      updateHistory: []
    }
  },
  {
    id: 'bb-4',
    name: 'South Zone Maternal & Pediatric Blood Bank (Niloufer Annex)',
    hospitalId: 'hosp-4',
    address: 'Red Hills, Hospital Road, South Zone',
    zone: 'South Zone',
    lat: 17.398,
    lng: 78.4621,
    phone: '040-2339-1155',
    emergencyPhone: '040-2339-1199',
    openHours: '24x7 Emergency Maternal & Neonatal Transfusion Unit',
    licenseNumber: 'TS-SBTC-LIC-2026-042',
    is24x7: true,
    componentSeparation: false,
    inventory: {
      'A+': 14,
      'A-': 2,
      'B+': 19,
      'B-': 1,
      'AB+': 6,
      'AB-': 0,
      'O+': 21,
      'O-': 1
    },
    verification: {
      sourceName: 'Commissioner of Family Welfare, Govt of Telangana',
      sourceUrl: 'https://familywelfare.ts.gov.in/niloufer-blood-bank',
      createdDate: '2026-02-20',
      lastUpdated: '2026-11-18T12:15:00Z',
      verificationStatus: 'Verified',
      validFrom: '2026-01-01',
      validUntil: '2027-12-31',
      verifiedBy: 'State Maternal Health Officer',
      isDemoData: true,
      updateHistory: []
    }
  }
];

export const SEED_BLOOD_REQUESTS: BloodRequest[] = [
  {
    id: 'breq-1',
    requestCode: 'BLD-REQ-48219',
    patientName: 'Lakshmi Narayana',
    bloodGroup: 'O-',
    unitsNeeded: 2,
    urgency: 'Emergency',
    hospitalName: 'Ideal City Central Government Super-Specialty Hospital',
    bloodBankId: 'bb-1',
    zone: 'Central Zone',
    lat: 17.4065,
    lng: 78.4772,
    contactName: 'Prakash Narayana',
    contactPhone: '+91 98480 33412',
    notes: 'Scheduled bypass surgery in Cardiac ICU Ward 3.',
    status: 'Matched',
    createdAt: '2026-11-18T14:20:00Z'
  },
  {
    id: 'breq-2',
    requestCode: 'BLD-REQ-48224',
    patientName: 'Ananya Deshmukh',
    bloodGroup: 'B+',
    unitsNeeded: 1,
    urgency: 'Urgent',
    hospitalName: 'Ideal City Mother & Child Welfare Hospital (Niloufer Annex)',
    bloodBankId: 'bb-4',
    zone: 'South Zone',
    lat: 17.398,
    lng: 78.4621,
    contactName: 'Rajesh Deshmukh',
    contactPhone: '+91 90001 77821',
    notes: 'Maternity ward hemoglobin support.',
    status: 'Pending',
    createdAt: '2026-11-18T16:45:00Z'
  },
  {
    id: 'breq-3',
    requestCode: 'BLD-REQ-48231',
    patientName: 'Mohammed Azeem',
    bloodGroup: 'O+',
    unitsNeeded: 2,
    urgency: 'Urgent',
    hospitalName: 'Apollo Health City & Research Institute',
    bloodBankId: 'bb-3',
    zone: 'Cyber Zone',
    lat: 17.4258,
    lng: 78.4116,
    contactName: 'Imran Siddiqui',
    contactPhone: '+91 98480 55112',
    notes: 'Trauma orthopedic surgery — 2 units PRBC required within 6 hours.',
    status: 'Pending',
    createdAt: '2026-11-18T17:15:00Z'
  },
  {
    id: 'breq-4',
    requestCode: 'BLD-REQ-48239',
    patientName: 'Kavitha Suryanarayana',
    bloodGroup: 'A+',
    unitsNeeded: 1,
    urgency: 'Urgent',
    hospitalName: 'KIMS Sunshine Advanced Bone & Heart Institute',
    bloodBankId: 'bb-2',
    zone: 'North Zone',
    lat: 17.4435,
    lng: 78.4983,
    contactName: 'Suresh Babu',
    contactPhone: '+91 98661 88210',
    notes: 'Post-operative critical care transfusion — immediate donor requested.',
    status: 'Pending',
    createdAt: '2026-11-18T18:05:00Z'
  }
];

export const SEED_BLOOD_DONATIONS: BloodDonationPledge[] = [
  {
    id: 'bdon-1',
    pledgeCode: 'BLD-DON-77102',
    donorName: 'Srinivas Rao',
    bloodGroup: 'O+',
    age: 32,
    weightKg: 71,
    phone: '+91 98480 12345',
    email: 'citizen@idealcity360.gov.in',
    preferredBankId: 'bb-1',
    preferredBankName: 'Ideal City Central Government Blood Bank & Component Center',
    preferredDate: '2026-11-21',
    preferredSlot: '10:00 AM - 12:00 PM',
    status: 'Scheduled',
    createdAt: '2026-11-18T11:30:00Z'
  },
  {
    id: 'bdon-2',
    pledgeCode: 'BLD-DON-77115',
    donorName: 'Deepika Sharma',
    bloodGroup: 'AB-',
    age: 26,
    weightKg: 57,
    phone: '+91 98661 44510',
    email: 'deepika.s@idealcity.in',
    preferredBankId: 'bb-2',
    preferredBankName: 'Indian Red Cross Society — Ideal City Regional Blood Center',
    preferredDate: '2026-11-22',
    preferredSlot: '02:00 PM - 04:00 PM',
    status: 'Scheduled',
    createdAt: '2026-11-18T15:05:00Z'
  }
];

export const SEED_DONOR_LEADERBOARD: DonorLeaderboardEntry[] = [
  {
    id: 'ldr-1',
    name: 'Dr. Kavya Menon',
    email: 'kavya.menon@idealcity.in',
    bloodGroup: 'O-',
    zone: 'Central Zone',
    totalDonations: 14,
    lastDonationDate: '2026-10-18',
    verified: true
  },
  {
    id: 'ldr-2',
    name: 'Mohammed Farhan Ali',
    email: 'farhan.ali@idealcity.in',
    bloodGroup: 'B+',
    zone: 'South Zone',
    totalDonations: 11,
    lastDonationDate: '2026-10-04',
    verified: true
  },
  {
    id: 'ldr-3',
    name: 'Priyanka Choudhary',
    email: 'priyanka.c@idealcity.in',
    bloodGroup: 'A+',
    zone: 'North Zone',
    totalDonations: 8,
    lastDonationDate: '2026-09-28',
    verified: true
  },
  {
    id: 'ldr-4',
    name: 'Srinivas Rao',
    email: 'citizen@idealcity360.gov.in',
    bloodGroup: 'O+',
    zone: 'Cyber Zone',
    totalDonations: 5,
    lastDonationDate: '2026-08-14',
    verified: true
  },
  {
    id: 'ldr-5',
    name: 'Karthikeya Sharma',
    email: 'karthik.sharma@idealcity.in',
    bloodGroup: 'AB+',
    zone: 'Central Zone',
    totalDonations: 5,
    lastDonationDate: '2026-07-30',
    verified: true
  },
  {
    id: 'ldr-6',
    name: 'Deepika Sharma',
    email: 'deepika.s@idealcity.in',
    bloodGroup: 'AB-',
    zone: 'North Zone',
    totalDonations: 4,
    lastDonationDate: '2026-08-22',
    verified: true
  },
  {
    id: 'ldr-7',
    name: 'Venkatesh Goud',
    email: 'venkatesh.g@idealcity.in',
    bloodGroup: 'B-',
    zone: 'South Zone',
    totalDonations: 3,
    lastDonationDate: '2026-09-10',
    verified: true
  },
  {
    id: 'ldr-8',
    name: 'Anjali Deshpande',
    email: 'anjali.d@idealcity.in',
    bloodGroup: 'A-',
    zone: 'Cyber Zone',
    totalDonations: 2,
    lastDonationDate: '2026-10-02',
    verified: true
  }
];

export const SEED_POLICE_STATIONS: PoliceStation[] = [
  {
    id: 'pol-1',
    name: 'Cyber Corridor Traffic & Law Police Station',
    zone: 'Cyber Zone',
    address: 'Plot 8, Jubilee Valley Arterial Junction, Cyber Corridor',
    phone: '040-2785-3301',
    controlRoomPhone: '100 / 112',
    lat: 17.4292,
    lng: 78.4085,
    officerInCharge: 'Inspector M. Anitha, IPS Traffic Wing'
  },
  {
    id: 'pol-2',
    name: 'Central Secretariat Traffic Police Station',
    zone: 'Central Zone',
    address: 'Raj Bhavan Circle, Sector 3, Central Enclave',
    phone: '040-2785-4410',
    controlRoomPhone: '100 / 112',
    lat: 17.4094,
    lng: 78.4741,
    officerInCharge: 'Inspector V. Srinivasulu'
  },
  {
    id: 'pol-3',
    name: 'North Zone Paradise Circle Police Station',
    zone: 'North Zone',
    address: 'Secunderabad Station Road, Near Paradise Flyover',
    phone: '040-2785-5520',
    controlRoomPhone: '100 / 112',
    lat: 17.4418,
    lng: 78.4946,
    officerInCharge: 'Inspector R. Prabhakar'
  },
  {
    id: 'pol-4',
    name: 'South Zone Old City Traffic Command Station',
    zone: 'South Zone',
    address: 'Red Hills Link Road, South Division',
    phone: '040-2785-6630',
    controlRoomPhone: '100 / 112',
    lat: 17.3962,
    lng: 78.4648,
    officerInCharge: 'Inspector Farooq Ahmed'
  }
];

export const SEED_AMBULANCE_UNITS: AmbulanceUnit[] = [
  {
    id: 'amb-1',
    callSign: 'EMS-108-CYBER-01',
    stationName: 'Cyber Corridor Trauma Staging Post',
    zone: 'Cyber Zone',
    phone: '108',
    vehicleNumber: 'TS-09-EM-1081',
    type: 'ALS Trauma ICU',
    lat: 17.4221,
    lng: 78.4194,
    status: 'Available'
  },
  {
    id: 'amb-2',
    callSign: 'EMS-108-CENTRAL-02',
    stationName: 'Central Government Hospital EMS Bay',
    zone: 'Central Zone',
    phone: '108',
    vehicleNumber: 'TS-09-EM-1082',
    type: 'ALS Trauma ICU',
    lat: 17.4068,
    lng: 78.4764,
    status: 'Available'
  },
  {
    id: 'amb-3',
    callSign: 'EMS-108-NORTH-03',
    stationName: 'Paradise Circle Rapid Response Base',
    zone: 'North Zone',
    phone: '108',
    vehicleNumber: 'TS-09-EM-1083',
    type: 'BLS Rapid Response',
    lat: 17.4404,
    lng: 78.4912,
    status: 'Available'
  },
  {
    id: 'amb-4',
    callSign: 'EMS-108-SOUTH-04',
    stationName: 'Red Hills South Trauma Hub',
    zone: 'South Zone',
    phone: '108',
    vehicleNumber: 'TS-09-EM-1084',
    type: 'ALS Trauma ICU',
    lat: 17.3992,
    lng: 78.4601,
    status: 'Available'
  }
];

export const DEMO_TRACKING_CREDENTIALS = [
  {
    incidentCode: 'ACC-2026-84102',
    trackingToken: 'TRK-DEMO-8410-CYBR-2026',
    label: 'Active Cyber Corridor Incident'
  },
  {
    incidentCode: 'ACC-2026-83945',
    trackingToken: 'TRK-DEMO-8394-CNTL-2026',
    label: 'Resolved Central Zone Incident'
  }
] as const;

export const SEED_ACCIDENT_REPORTS: AccidentReport[] = [
  {
    id: 'acc-seed-1',
    incidentCode: 'ACC-2026-84102',
    reportedAt: '2026-11-12T08:42:00Z',
    incidentDate: '2026-11-12',
    incidentTime: '08:42 AM',
    latitude: 17.4264,
    longitude: 78.4141,
    locationLabel: 'Jubilee Valley Metro Pillar 42, Cyber Corridor',
    locationSource: 'gps',
    googleMapsUrl: 'https://www.google.com/maps?q=17.426400,78.414100',
    securePhotoId: 'med-seed-bike-car',
    securePhotoUrl: '/api/accidents/media/med-seed-bike-car',
    aiAnalysis: {
      isAccidentDetected: true,
      accidentType: 'Two-Wheeler & Car Collision',
      severity: 'Critical',
      confidenceLabel: 'High',
      visibleIndicators: [
        'Motorcycle downed on urban roadway near intersection',
        'Compact car front-right bumper impact damage with hazard lights active',
        'Traffic cones and safety cordon visible on lane'
      ],
      estimatedInjuredHint: '1-2 riders potentially affected (requires on-site triage)',
      shortDescription:
        'Possible two-wheeler and car collision detected. Visible front-end vehicle damage and downed motorcycle on carriageway. Accident severity requires human assessment. Location: 17.42640, 78.41410.',
      disclaimer:
        'AI visual assessment only: exact cause of an accident cannot be determined from a photograph alone. Accident severity requires human assessment.',
      analyzedAt: '2026-11-12T08:41:42Z',
      modelUsed: 'gemini-4-hydrogen'
    },
    accidentType: 'Two-Wheeler & Car Collision',
    severity: 'Critical',
    possibleInjuredCount: 1,
    reporterConfirmed: true,
    confirmedAt: '2026-11-12T08:41:58Z',
    reporterIdentityMode: 'anonymous',
    reporterIdentityLabel: 'Anonymous',
    optionalCallbackConsented: false,
    sceneNotes: 'Rider conscious near divider, traffic slowing down along metro corridor.',
    authorityAlertText: [
      'NEW ROAD ACCIDENT ALERT',
      '',
      'Report ID: ACC-2026-84102',
      'Accident Type: Possible Two-Wheeler & Car Collision',
      'Severity: Critical – AI Estimate (Requires Human Assessment)',
      'Location: 17.42640, 78.41410',
      'Map: https://www.google.com/maps?q=17.426400,78.414100',
      'Reported At: 2026-11-12 08:42 AM',
      'Possible Injured: 1',
      'Photograph: /api/accidents/media/med-seed-bike-car (Authorized Emergency Access Only)',
      '',
      'Reporter Identity: Anonymous'
    ].join('\n'),
    overallStatus: 'Response Dispatched',
    demoMode: true,
    retentionExpiresAt: '2027-12-31T23:59:59Z',
    privacyCompliance: {
      exifMetadataStripped: true,
      strippedMetadataSegments: 2,
      encryptedAtRest: true,
      noAiTrainingWithoutConsent: true,
      piiCollected: false,
      retentionDays: 30,
      dpdpActCompliant: true
    },
    notifiedHospitals: [
      {
        hospitalId: 'hosp-2',
        hospitalName: 'Apollo Health City & Research Institute',
        distanceKm: 0.27,
        emergencyPhone: '1066 / 040-2980-4499',
        lat: 17.4258,
        lng: 78.4116,
        status: 'Trauma Bay Ready',
        deliveryConfirmed: true,
        deliveryMode: 'demo_simulated',
        notifiedAt: '2026-11-12T08:42:02Z',
        updatedAt: '2026-11-12T08:44:15Z',
        bedsReserved: 1,
        notes: 'Emergency Trauma Bay #2 prepped with orthopedic & neuro team on standby.'
      },
      {
        hospitalId: 'hosp-1',
        hospitalName: 'Ideal City Central Government Super-Specialty Hospital',
        distanceKm: 7.05,
        emergencyPhone: '108 / 040-2345-6700',
        lat: 17.4065,
        lng: 78.4772,
        status: 'Notified',
        deliveryConfirmed: true,
        deliveryMode: 'demo_simulated',
        notifiedAt: '2026-11-12T08:42:02Z',
        updatedAt: '2026-11-12T08:42:02Z'
      }
    ],
    ambulanceDispatch: {
      unitId: 'amb-1',
      callSign: 'EMS-108-CYBER-01',
      stationName: 'Cyber Corridor Trauma Staging Post',
      vehicleNumber: 'TS-09-EM-1081',
      phone: '108',
      originLat: 17.4221,
      originLng: 78.4194,
      distanceKm: 0.92,
      etaMinutes: 4,
      routeWaypoints: [
        { lat: 17.4221, lng: 78.4194 },
        { lat: 17.4234, lng: 78.4182 },
        { lat: 17.4249, lng: 78.4169 },
        { lat: 17.4258, lng: 78.4153 },
        { lat: 17.4264, lng: 78.4141 }
      ],
      status: 'En Route',
      deliveryConfirmed: true,
      deliveryMode: 'demo_simulated',
      notifiedAt: '2026-11-12T08:42:02Z',
      updatedAt: '2026-11-12T08:43:30Z',
      notes: 'ALS Trauma Unit navigating via Jubilee Valley green corridor.'
    },
    policeDispatch: {
      stationId: 'pol-1',
      stationName: 'Cyber Corridor Traffic & Law Police Station',
      zone: 'Cyber Zone',
      phone: '040-2785-3301',
      lat: 17.4292,
      lng: 78.4085,
      distanceKm: 0.67,
      status: 'Patrol Dispatched',
      deliveryConfirmed: true,
      deliveryMode: 'demo_simulated',
      notifiedAt: '2026-11-12T08:42:02Z',
      updatedAt: '2026-11-12T08:43:45Z',
      officerNotes: 'Traffic interceptor unit PC-14 proceeding to secure lane and clear congestion.'
    },
    responseHistory: [
      {
        id: 'evt-1',
        timestamp: '2026-11-12T08:42:00Z',
        actor: 'Anonymous Reporter',
        agency: 'Citizen',
        message: 'Verified & submitted anonymous accident report with incident coordinates (17.42640, 78.41410). EXIF metadata stripped.',
        statusBadge: 'Confirmed · Anonymous'
      },
      {
        id: 'evt-2',
        timestamp: '2026-11-12T08:42:02Z',
        actor: 'IDEAL 360 Dispatch Engine',
        agency: 'Command Center',
        message: 'Backend confirmed simulated anonymous alerts delivered to 2 nearby hospitals, EMS-108-CYBER-01, and Cyber Corridor Traffic PS.',
        statusBadge: 'Alerts Delivered (Demo)'
      },
      {
        id: 'evt-3',
        timestamp: '2026-11-12T08:43:30Z',
        actor: 'S. Narayana (108 EMS Lead)',
        agency: 'Ambulance',
        message: 'EMS-108-CYBER-01 (TS-09-EM-1081) En Route via shortest corridor. Estimated arrival: 4 mins.',
        statusBadge: 'En Route'
      },
      {
        id: 'evt-4',
        timestamp: '2026-11-12T08:44:15Z',
        actor: 'Dr. Vikramaditya Reddy',
        agency: 'Hospital',
        message: 'Apollo Health City Trauma Bay #2 prepared; 1 trauma bed reserved.',
        statusBadge: 'Trauma Bay Ready'
      }
    ]
  },
  {
    id: 'acc-seed-2',
    incidentCode: 'ACC-2026-83945',
    reportedAt: '2026-11-12T07:15:00Z',
    incidentDate: '2026-11-12',
    incidentTime: '07:15 AM',
    latitude: 17.4088,
    longitude: 78.4754,
    locationLabel: 'Raj Bhavan Boulevard Signal, Central Zone',
    locationSource: 'manual_map',
    googleMapsUrl: 'https://www.google.com/maps?q=17.408800,78.475400',
    securePhotoId: 'med-seed-car-van',
    securePhotoUrl: '/api/accidents/media/med-seed-car-van',
    aiAnalysis: {
      isAccidentDetected: true,
      accidentType: 'Car Collision',
      severity: 'Medium',
      confidenceLabel: 'High',
      visibleIndicators: [
        'White sedan and commercial van contact at signalized intersection',
        'Front hood crumple and road debris visible',
        'Hazard lights activated on both vehicles'
      ],
      estimatedInjuredHint: 'No visible injuries in frame; medical check advised',
      shortDescription:
        'Possible sedan and commercial van collision detected at urban signal. Visible hood and bumper damage with debris on asphalt. Accident severity requires human assessment. Location: 17.40880, 78.47540.',
      disclaimer:
        'AI visual assessment only: exact cause of an accident cannot be determined from a photograph alone. Accident severity requires human assessment.',
      analyzedAt: '2026-11-12T07:14:40Z',
      modelUsed: 'gemini-4-hydrogen'
    },
    accidentType: 'Car Collision',
    severity: 'Medium',
    possibleInjuredCount: 0,
    reporterConfirmed: true,
    confirmedAt: '2026-11-12T07:14:55Z',
    reporterIdentityMode: 'anonymous',
    reporterIdentityLabel: 'Anonymous',
    optionalCallbackConsented: false,
    sceneNotes: 'Both drivers out of vehicles safely; intersection lane partially blocked.',
    authorityAlertText: [
      'NEW ROAD ACCIDENT ALERT',
      '',
      'Report ID: ACC-2026-83945',
      'Accident Type: Possible Car Collision',
      'Severity: Medium – AI Estimate (Requires Human Assessment)',
      'Location: 17.40880, 78.47540',
      'Map: https://www.google.com/maps?q=17.408800,78.475400',
      'Reported At: 2026-11-12 07:15 AM',
      'Possible Injured: 0',
      'Photograph: /api/accidents/media/med-seed-car-van (Authorized Emergency Access Only)',
      '',
      'Reporter Identity: Anonymous'
    ].join('\n'),
    overallStatus: 'Resolved',
    demoMode: true,
    retentionExpiresAt: '2027-12-31T23:59:59Z',
    privacyCompliance: {
      exifMetadataStripped: true,
      strippedMetadataSegments: 1,
      encryptedAtRest: true,
      noAiTrainingWithoutConsent: true,
      piiCollected: false,
      retentionDays: 30,
      dpdpActCompliant: true
    },
    notifiedHospitals: [
      {
        hospitalId: 'hosp-1',
        hospitalName: 'Ideal City Central Government Super-Specialty Hospital',
        distanceKm: 0.32,
        emergencyPhone: '108 / 040-2345-6700',
        lat: 17.4065,
        lng: 78.4772,
        status: 'Acknowledged',
        deliveryConfirmed: true,
        deliveryMode: 'demo_simulated',
        notifiedAt: '2026-11-12T07:15:02Z',
        updatedAt: '2026-11-12T07:22:00Z',
        notes: 'EMS reported no hospital admission required after on-scene vitals check.'
      }
    ],
    ambulanceDispatch: {
      unitId: 'amb-2',
      callSign: 'EMS-108-CENTRAL-02',
      stationName: 'Central Government Hospital EMS Bay',
      vehicleNumber: 'TS-09-EM-1082',
      phone: '108',
      originLat: 17.4068,
      originLng: 78.4764,
      distanceKm: 0.36,
      etaMinutes: 0,
      routeWaypoints: [
        { lat: 17.4068, lng: 78.4764 },
        { lat: 17.4074, lng: 78.4761 },
        { lat: 17.408, lng: 78.4758 },
        { lat: 17.4085, lng: 78.4756 },
        { lat: 17.4088, lng: 78.4754 }
      ],
      status: 'Completed',
      deliveryConfirmed: true,
      deliveryMode: 'demo_simulated',
      notifiedAt: '2026-11-12T07:15:02Z',
      updatedAt: '2026-11-12T07:34:00Z',
      notes: 'On-scene triage completed; minor bruises treated, no transport needed.'
    },
    policeDispatch: {
      stationId: 'pol-2',
      stationName: 'Central Secretariat Traffic Police Station',
      zone: 'Central Zone',
      phone: '040-2785-4410',
      lat: 17.4094,
      lng: 78.4741,
      distanceKm: 0.15,
      status: 'Scene Cleared',
      deliveryConfirmed: true,
      deliveryMode: 'demo_simulated',
      notifiedAt: '2026-11-12T07:15:02Z',
      updatedAt: '2026-11-12T07:48:00Z',
      officerNotes: 'Vehicles towed to shoulder, debris cleared, traffic restored and GD entry logged.'
    },
    responseHistory: [
      {
        id: 'evt-201',
        timestamp: '2026-11-12T07:15:02Z',
        actor: 'IDEAL 360 Dispatch Engine',
        agency: 'Command Center',
        message: 'Dispatched anonymous alerts to Central Govt Hospital, EMS-108-CENTRAL-02, and Central Secretariat Traffic PS.',
        statusBadge: 'Alerts Delivered (Demo)'
      },
      {
        id: 'evt-202',
        timestamp: '2026-11-12T07:34:00Z',
        actor: 'S. Narayana (108 EMS Lead)',
        agency: 'Ambulance',
        message: 'On-scene vitals check completed; no casualties requiring hospital transfer.',
        statusBadge: 'Completed'
      },
      {
        id: 'evt-203',
        timestamp: '2026-11-12T07:48:00Z',
        actor: 'Insp. M. Anitha (Traffic Police)',
        agency: 'Police',
        message: 'Scene cleared, vehicles moved, and incident marked Resolved.',
        statusBadge: 'Resolved'
      }
    ]
  }
];




