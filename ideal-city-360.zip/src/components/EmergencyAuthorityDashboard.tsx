import React, { useEffect, useMemo, useState } from 'react';
import type {
  AccidentOverallStatus,
  AccidentReport,
  AmbulanceResponseStatus,
  AmbulanceUnit,
  Hospital,
  HospitalResponseStatus,
  PoliceResponseStatus,
  PoliceStation,
  User,
} from '../types';
import {
  buildGoogleMapsDirectionsUrl,
  canRoleAccessAuthorityDashboard,
  canRoleUpdateAgency,
} from '../utils/accidentEmergency';
import { AccidentLocationMap } from './AccidentLocationMap';
import {
  Activity,
  Ambulance,
  Building2,
  CheckCircle2,
  Clock,
  ExternalLink,
  EyeOff,
  Lock,
  Navigation,
  RefreshCw,
  Shield,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';

interface Props {
  currentUser: User;
  reports: AccidentReport[];
  hospitals: Hospital[];
  policeStations: PoliceStation[];
  ambulanceUnits: AmbulanceUnit[];
  onSwitchUserRole: (role: string) => void;
  onRefresh: () => void;
  onUpdateResponse: (
    reportId: string,
    payload: {
      agency: 'hospital' | 'ambulance' | 'police' | 'overall';
      status?: string;
      hospitalId?: string;
      etaMinutes?: number | null;
      bedsReserved?: number;
      notes?: string;
      overallStatus?: AccidentOverallStatus;
    }
  ) => Promise<void>;
  isRefreshing: boolean;
}

const HOSPITAL_STATUSES: HospitalResponseStatus[] = [
  'Notified',
  'Acknowledged',
  'Trauma Bay Ready',
  'Patient Admitted',
];

const AMBULANCE_STATUSES: AmbulanceResponseStatus[] = [
  'Notified',
  'Dispatched',
  'En Route',
  'On Scene',
  'Transporting',
  'Completed',
];

const POLICE_STATUSES: PoliceResponseStatus[] = [
  'Notified',
  'Patrol Dispatched',
  'Investigating',
  'Scene Cleared',
  'Case Closed',
];

const OVERALL_STATUSES: AccidentOverallStatus[] = [
  'Active Emergency',
  'Response Dispatched',
  'Resolved',
];

export const EmergencyAuthorityDashboard: React.FC<Props> = ({
  currentUser,
  reports,
  hospitals,
  policeStations,
  ambulanceUnits,
  onSwitchUserRole,
  onRefresh,
  onUpdateResponse,
  isRefreshing,
}) => {
  const hasAccess = canRoleAccessAuthorityDashboard(currentUser.role);
  const [statusFilter, setStatusFilter] = useState<'ALL' | AccidentOverallStatus>('ALL');
  const [severityFilter, setSeverityFilter] = useState<'ALL' | AccidentReport['severity']>('ALL');
  const [selectedId, setSelectedId] = useState<string | null>(reports[0]?.id || null);

  // Authority update form state
  const [hospitalStatus, setHospitalStatus] = useState<HospitalResponseStatus>('Trauma Bay Ready');
  const [bedsReserved, setBedsReserved] = useState<string>('1');
  const [hospitalNotes, setHospitalNotes] = useState<string>('');

  const [ambStatus, setAmbStatus] = useState<AmbulanceResponseStatus>('En Route');
  const [ambEta, setAmbEta] = useState<string>('5');
  const [ambNotes, setAmbNotes] = useState<string>('');

  const [polStatus, setPolStatus] = useState<PoliceResponseStatus>('Investigating');
  const [polNotes, setPolNotes] = useState<string>('');
  const [overallStatus, setOverallStatus] = useState<AccidentOverallStatus>('Response Dispatched');
  const [savingAgency, setSavingAgency] = useState<string | null>(null);

  const filteredReports = useMemo(() => {
    return reports.filter((r) => {
      if (statusFilter !== 'ALL' && r.overallStatus !== statusFilter) return false;
      if (severityFilter !== 'ALL' && r.severity !== severityFilter) return false;
      return true;
    });
  }, [reports, statusFilter, severityFilter]);

  const selectedReport =
    filteredReports.find((r) => r.id === selectedId) || filteredReports[0] || null;

  useEffect(() => {
    if (!selectedReport) return;
    setSelectedId(selectedReport.id);
    const primaryHosp = selectedReport.notifiedHospitals[0];
    setHospitalStatus(primaryHosp?.status === 'Pending' ? 'Acknowledged' : primaryHosp?.status || 'Acknowledged');
    setBedsReserved(String(primaryHosp?.bedsReserved ?? 1));
    setHospitalNotes(primaryHosp?.notes || '');

    setAmbStatus(selectedReport.ambulanceDispatch.status === 'Pending' ? 'Dispatched' : selectedReport.ambulanceDispatch.status);
    setAmbEta(
      selectedReport.ambulanceDispatch.etaMinutes !== null
        ? String(selectedReport.ambulanceDispatch.etaMinutes)
        : ''
    );
    setAmbNotes(selectedReport.ambulanceDispatch.notes || '');

    setPolStatus(selectedReport.policeDispatch.status === 'Pending' ? 'Patrol Dispatched' : selectedReport.policeDispatch.status);
    setPolNotes(selectedReport.policeDispatch.officerNotes || '');
    setOverallStatus(selectedReport.overallStatus);
  }, [selectedReport?.id]);

  const counts = useMemo(() => {
    const active = reports.filter((r) => r.overallStatus === 'Active Emergency').length;
    const pending = reports.filter((r) => r.overallStatus === 'Response Dispatched').length;
    const resolved = reports.filter((r) => r.overallStatus === 'Resolved').length;
    return { active, pending, resolved };
  }, [reports]);

  const handleAgencySave = async (
    agency: 'hospital' | 'ambulance' | 'police' | 'overall'
  ) => {
    if (!selectedReport) return;
    setSavingAgency(agency);
    try {
      if (agency === 'hospital') {
        await onUpdateResponse(selectedReport.id, {
          agency: 'hospital',
          hospitalId: selectedReport.notifiedHospitals[0]?.hospitalId,
          status: hospitalStatus,
          bedsReserved: Number(bedsReserved) || 0,
          notes: hospitalNotes,
        });
      } else if (agency === 'ambulance') {
        await onUpdateResponse(selectedReport.id, {
          agency: 'ambulance',
          status: ambStatus,
          etaMinutes: ambEta.trim() === '' ? null : Number(ambEta),
          notes: ambNotes,
        });
      } else if (agency === 'police') {
        await onUpdateResponse(selectedReport.id, {
          agency: 'police',
          status: polStatus,
          notes: polNotes,
        });
      } else {
        await onUpdateResponse(selectedReport.id, {
          agency: 'overall',
          overallStatus,
          notes: polNotes || 'Status updated by emergency command',
        });
      }
    } finally {
      setSavingAgency(null);
    }
  };

  const authorityRoles = [
    { role: 'super_admin', label: 'Command Super Admin' },
    { role: 'hospital_admin', label: 'Hospital Trauma Admin' },
    { role: 'ambulance_service', label: '108 Ambulance EMS' },
    { role: 'police_officer', label: 'Traffic Police' },
  ];

  // RBAC Guard for non-authority roles
  if (!hasAccess) {
    return (
      <div
        data-testid="authority-rbac-gate"
        className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-5"
      >
        <div className="flex items-start gap-3">
          <div className="w-11 h-11 rounded-xl bg-red-50 dark:bg-red-950/50 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900 flex items-center justify-center shrink-0">
            <Lock className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
              Emergency Authority Command Access Required
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
              To protect accident photographs, incident locations, and live emergency dispatch controls from unauthorized access, the Emergency Response Dashboard is restricted to verified <strong>Hospital</strong>, <strong>108 Ambulance</strong>, <strong>Traffic Police</strong>, and <strong>Command Admin</strong> personnel. Reporter identities remain strictly <strong>Anonymous</strong> even to emergency authorities. You are currently signed in as <strong>{currentUser.name} ({currentUser.role})</strong>.
            </p>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
          <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
            Demo Role Switcher — Sign in as an authorized emergency responder:
          </div>
          <div className="flex flex-wrap gap-2">
            {authorityRoles.map((ar) => (
              <button
                key={ar.role}
                type="button"
                data-testid={`switch-authority-${ar.role}`}
                onClick={() => onSwitchUserRole(ar.role)}
                className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-teal-600 hover:bg-slate-800 dark:hover:bg-teal-700 text-white text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Switch to {ar.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="emergency-authority-dashboard">
      {/* Authority Header & Quick Role Switcher */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-wider text-red-600 dark:text-red-400">
            Authorized Responder Portal · RBAC Active
          </div>
          <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
            Emergency Response Command Dashboard
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Active Officer: <strong className="text-slate-800 dark:text-slate-200">{currentUser.name}</strong> ({currentUser.role}) · Demo Dispatch Mode enabled
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {authorityRoles.map((ar) => {
            const active = currentUser.role === ar.role;
            return (
              <button
                key={ar.role}
                type="button"
                data-testid={`authority-role-pill-${ar.role}`}
                onClick={() => onSwitchUserRole(ar.role)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                  active
                    ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 border-slate-900 dark:border-white'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                }`}
              >
                {ar.label}
              </button>
            );
          })}
          <button
            type="button"
            onClick={onRefresh}
            disabled={isRefreshing}
            className="px-3 py-1.5 rounded-lg text-xs font-bold border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Sync</span>
          </button>
        </div>
      </div>

      {/* KPI Metric Strip — Flat single-elevation surfaces with tabular numerals */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-red-200 dark:border-red-900/70 p-4">
          <div className="text-[11px] font-bold uppercase tracking-wider text-red-600 dark:text-red-400">
            Active Emergencies
          </div>
          <div className="text-2xl font-black text-red-600 dark:text-red-400 font-mono tabular-nums mt-1">
            {counts.active}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            Immediate dispatch needed
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-orange-200 dark:border-orange-900/70 p-4">
          <div className="text-[11px] font-bold uppercase tracking-wider text-orange-600 dark:text-orange-400">
            Pending / Dispatched
          </div>
          <div className="text-2xl font-black text-orange-600 dark:text-orange-400 font-mono tabular-nums mt-1">
            {counts.pending}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            Units en route / investigating
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-emerald-200 dark:border-emerald-900/70 p-4">
          <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
            Resolved Cases
          </div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-mono tabular-nums mt-1">
            {counts.resolved}
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            Scene cleared & closed
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Connected Network
          </div>
          <div className="text-sm font-extrabold text-slate-900 dark:text-white font-mono tabular-nums mt-1.5">
            {hospitals.length} Hosp · {ambulanceUnits.length} EMS · {policeStations.length} PS
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
            City-wide emergency grid
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 px-4 py-2.5">
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="font-bold text-slate-500 dark:text-slate-400 mr-1">Status:</span>
          {(['ALL', 'Active Emergency', 'Response Dispatched', 'Resolved'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                statusFilter === st
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {st === 'ALL' ? 'All Cases' : st}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="font-bold text-slate-500 dark:text-slate-400 mr-1">Severity:</span>
          {(['ALL', 'Critical', 'Medium', 'Low'] as const).map((sev) => (
            <button
              key={sev}
              type="button"
              onClick={() => setSeverityFilter(sev)}
              className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                severityFilter === sev
                  ? sev === 'Critical'
                    ? 'bg-red-600 text-white'
                    : sev === 'Medium'
                      ? 'bg-orange-500 text-white'
                      : sev === 'Low'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {sev === 'ALL' ? 'All' : sev}
            </button>
          ))}
        </div>
      </div>

      {/* Live Map + Incident Queue + Dossier */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Live Map & Notifications Queue */}
        <div className="lg:col-span-5 space-y-4">
          <AccidentLocationMap
            mode="command"
            reports={filteredReports}
            selectedReportId={selectedReport?.id || null}
            onSelectReport={(id) => setSelectedId(id)}
            hospitals={hospitals}
            policeStations={policeStations}
            ambulanceUnits={ambulanceUnits}
            heightClass="h-72"
          />

          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Live Accident Notifications ({filteredReports.length})
              </h3>
            </div>

            {filteredReports.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500 dark:text-slate-400">
                No incidents match the selected filters.
              </div>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[420px] overflow-y-auto">
                {filteredReports.map((rep) => {
                  const isSelected = selectedReport?.id === rep.id;
                  const statusColor =
                    rep.overallStatus === 'Resolved'
                      ? 'text-emerald-700 dark:text-emerald-400'
                      : rep.overallStatus === 'Active Emergency'
                        ? 'text-red-600 dark:text-red-400'
                        : 'text-orange-600 dark:text-orange-400';

                  return (
                    <button
                      key={rep.id}
                      type="button"
                      onClick={() => setSelectedId(rep.id)}
                      className={`w-full text-left p-3.5 transition-colors cursor-pointer ${
                        isSelected
                          ? 'bg-red-50/70 dark:bg-red-950/25 border-l-4 border-l-red-600'
                          : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 text-[11px]">
                        <span className="font-mono font-bold text-slate-900 dark:text-white">
                          {rep.incidentCode}
                        </span>
                        <span className={`font-bold ${statusColor}`}>{rep.overallStatus}</span>
                      </div>
                      <div className="text-xs font-bold text-slate-800 dark:text-slate-100 mt-1">
                        {rep.accidentType} ·{' '}
                        <span
                          className={
                            rep.severity === 'Critical'
                              ? 'text-red-600 dark:text-red-400'
                              : rep.severity === 'Medium'
                                ? 'text-orange-600 dark:text-orange-400'
                                : 'text-emerald-600 dark:text-emerald-400'
                          }
                        >
                          {rep.severity}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                        {rep.locationLabel}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono tabular-nums mt-1">
                        {rep.incidentDate} · {rep.incidentTime} · Injured:{' '}
                        {rep.possibleInjuredCount ?? 'Unknown'}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right: Selected Incident Dossier & Role-Gated Response Controls */}
        <div className="lg:col-span-7 space-y-4">
          {!selectedReport ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 text-center text-xs text-slate-500">
              Select an incident from the notifications queue to inspect evidence and update response status.
            </div>
          ) : (
            <>
              {/* Incident Evidence & Metadata */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-sm font-black text-slate-900 dark:text-white">
                        {selectedReport.incidentCode}
                      </span>
                      <span
                        className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                          selectedReport.severity === 'Critical'
                            ? 'bg-red-600 text-white'
                            : selectedReport.severity === 'Medium'
                              ? 'bg-orange-500 text-white'
                              : 'bg-emerald-600 text-white'
                        }`}
                      >
                        {selectedReport.severity} Severity
                      </span>
                      <span
                        className={`text-[11px] font-bold px-2 py-0.5 rounded border ${
                          selectedReport.overallStatus === 'Resolved'
                            ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                            : selectedReport.overallStatus === 'Active Emergency'
                              ? 'bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 border-red-200 dark:border-red-800'
                              : 'bg-orange-50 dark:bg-orange-950 text-orange-700 dark:text-orange-300 border-orange-200 dark:border-orange-800'
                        }`}
                      >
                        {selectedReport.overallStatus}
                      </span>
                    </div>
                    <h3 className="text-base font-extrabold text-slate-900 dark:text-white mt-1">
                      {selectedReport.accidentType} — {selectedReport.locationLabel}
                    </h3>
                  </div>

                  <div className="flex items-center gap-2">
                    <a
                      href={selectedReport.googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Google Maps</span>
                    </a>
                    <a
                      href={buildGoogleMapsDirectionsUrl(
                        selectedReport.ambulanceDispatch.originLat,
                        selectedReport.ambulanceDispatch.originLng,
                        selectedReport.latitude,
                        selectedReport.longitude
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>EMS Route</span>
                    </a>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                  <div className="md:col-span-5">
                    <img
                      src={selectedReport.securePhotoUrl}
                      alt="Restricted emergency accident photograph"
                      draggable={false}
                      onContextMenu={(e) => e.preventDefault()}
                      data-testid="authority-protected-photo"
                      className="w-full h-44 object-cover rounded-xl border border-slate-200 dark:border-slate-700 select-none"
                    />
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-1.5 flex items-center justify-between gap-2 font-mono">
                      <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-sans font-semibold">
                        <Lock className="w-3 h-3" />
                        EXIF Stripped · Authorized View
                      </span>
                      <span>
                        {selectedReport.latitude.toFixed(5)}, {selectedReport.longitude.toFixed(5)}
                      </span>
                    </div>
                  </div>

                  <div className="md:col-span-7 space-y-2.5 text-xs">
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-1">
                      <div className="font-bold text-slate-900 dark:text-white">
                        AI Visual Incident Description
                      </div>
                      <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                        {selectedReport.aiAnalysis.shortDescription}
                      </p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 italic">
                        {selectedReport.aiAnalysis.disclaimer}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700">
                        <span className="text-slate-400 block">Possible Injured</span>
                        <strong className="text-slate-900 dark:text-white font-mono">
                          {selectedReport.possibleInjuredCount ?? 'Unknown (Assess on scene)'}
                        </strong>
                      </div>
                      <div
                        data-testid="authority-reporter-identity-box"
                        className="p-2.5 rounded-lg bg-emerald-50/70 dark:bg-emerald-950/35 border border-emerald-200 dark:border-emerald-800/80"
                      >
                        <span className="text-emerald-700 dark:text-emerald-400 block font-semibold">
                          Reporter Identity
                        </span>
                        <strong className="text-emerald-950 dark:text-emerald-100 inline-flex items-center gap-1">
                          <EyeOff className="w-3.5 h-3.5" />
                          <span>{selectedReport.reporterIdentityLabel}</span>
                        </strong>
                        {selectedReport.optionalCallbackConsented && selectedReport.optionalCallbackPhone ? (
                          <span className="block font-mono text-[10px] text-emerald-800 dark:text-emerald-300 mt-0.5">
                            Consented Callback: {selectedReport.optionalCallbackPhone}
                          </span>
                        ) : (
                          <span className="block text-[10px] text-emerald-700/80 dark:text-emerald-400/80 mt-0.5">
                            Protected · Zero PII Disclosed
                          </span>
                        )}
                      </div>
                    </div>

                    {selectedReport.sceneNotes && (
                      <div className="text-[11px] text-slate-600 dark:text-slate-300">
                        <strong>Scene Safety Notes:</strong> {selectedReport.sceneNotes}
                      </div>
                    )}
                  </div>
                </div>

                {/* Standardized Anonymous Emergency Alert & DPDP Retention Strip */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                    <span className="font-bold text-slate-700 dark:text-slate-300 inline-flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Standardized Authority Notification (Zero Reporter PII)</span>
                    </span>
                    <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400">
                      DPDP Act 2023 · {selectedReport.privacyCompliance.retentionDays}-Day Auto-Delete ({selectedReport.retentionExpiresAt.split('T')[0]})
                    </span>
                  </div>
                  <pre className="text-[11px] font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 overflow-x-auto whitespace-pre-wrap text-slate-700 dark:text-slate-300 leading-relaxed">
                    {selectedReport.authorityAlertText}
                  </pre>
                </div>
              </div>

              {/* Role-Gated Authority Status Update Controls */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-red-600" />
                  <span>Agency Dispatch & Investigation Controls</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Hospital Panel */}
                  <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 space-y-2.5">
                    <div className="flex items-center gap-1.5 text-xs font-extrabold text-teal-700 dark:text-teal-400">
                      <Building2 className="w-4 h-4" />
                      <span>Hospital Triage</span>
                    </div>
                    <div className="text-[11px] text-slate-600 dark:text-slate-300 font-semibold line-clamp-2">
                      {selectedReport.notifiedHospitals[0]?.hospitalName}
                    </div>
                    <select
                      value={hospitalStatus}
                      onChange={(e) => setHospitalStatus(e.target.value as HospitalResponseStatus)}
                      disabled={!canRoleUpdateAgency(currentUser.role, 'hospital')}
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 px-2.5 py-1.5 text-xs disabled:opacity-60"
                    >
                      {HOSPITAL_STATUSES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                    <input
                      type="number"
                      min={0}
                      max={20}
                      value={bedsReserved}
                      onChange={(e) => setBedsReserved(e.target.value)}
                      disabled={!canRoleUpdateAgency(currentUser.role, 'hospital')}
                      placeholder="Trauma beds reserved"
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 px-2.5 py-1.5 text-xs font-mono disabled:opacity-60"
                    />
                    <input
                      type="text"
                      value={hospitalNotes}
                      onChange={(e) => setHospitalNotes(e.target.value)}
                      disabled={!canRoleUpdateAgency(currentUser.role, 'hospital')}
                      placeholder="Trauma team readiness note..."
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 px-2.5 py-1.5 text-xs disabled:opacity-60"
                    />
                    <button
                      type="button"
                      disabled={!canRoleUpdateAgency(currentUser.role, 'hospital') || savingAgency === 'hospital'}
                      data-testid="update-hospital-btn"
                      onClick={() => handleAgencySave('hospital')}
                      className="w-full py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 dark:disabled:bg-slate-700 text-white text-xs font-bold cursor-pointer disabled:cursor-not-allowed"
                    >
                      {savingAgency === 'hospital' ? 'Updating...' : 'Update Hospital'}
                    </button>
                  </div>

                  {/* Ambulance Panel */}
                  <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 space-y-2.5">
                    <div className="flex items-center gap-1.5 text-xs font-extrabold text-orange-700 dark:text-orange-400">
                      <Ambulance className="w-4 h-4" />
                      <span>108 Ambulance EMS</span>
                    </div>
                    <div className="text-[11px] text-slate-600 dark:text-slate-300 font-mono">
                      {selectedReport.ambulanceDispatch.callSign} ({selectedReport.ambulanceDispatch.distanceKm} km)
                    </div>
                    <select
                      value={ambStatus}
                      onChange={(e) => setAmbStatus(e.target.value as AmbulanceResponseStatus)}
                      disabled={!canRoleUpdateAgency(currentUser.role, 'ambulance')}
                      data-testid="authority-ambulance-status-select"
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 px-2.5 py-1.5 text-xs disabled:opacity-60"
                    >
                      {AMBULANCE_STATUSES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                    <input
                      type="number"
                      min={0}
                      max={180}
                      value={ambEta}
                      onChange={(e) => setAmbEta(e.target.value)}
                      disabled={!canRoleUpdateAgency(currentUser.role, 'ambulance')}
                      data-testid="authority-ambulance-eta-input"
                      placeholder="ETA in minutes"
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 px-2.5 py-1.5 text-xs font-mono disabled:opacity-60"
                    />
                    <input
                      type="text"
                      value={ambNotes}
                      onChange={(e) => setAmbNotes(e.target.value)}
                      disabled={!canRoleUpdateAgency(currentUser.role, 'ambulance')}
                      placeholder="Dispatch / route update..."
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 px-2.5 py-1.5 text-xs disabled:opacity-60"
                    />
                    <button
                      type="button"
                      disabled={!canRoleUpdateAgency(currentUser.role, 'ambulance') || savingAgency === 'ambulance'}
                      data-testid="update-ambulance-btn"
                      onClick={() => handleAgencySave('ambulance')}
                      className="w-full py-1.5 rounded-lg bg-orange-600 hover:bg-orange-700 disabled:bg-slate-300 dark:disabled:bg-slate-700 text-white text-xs font-bold cursor-pointer disabled:cursor-not-allowed"
                    >
                      {savingAgency === 'ambulance' ? 'Updating...' : 'Update Ambulance'}
                    </button>
                  </div>

                  {/* Police Panel */}
                  <div className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 space-y-2.5">
                    <div className="flex items-center gap-1.5 text-xs font-extrabold text-blue-700 dark:text-blue-400">
                      <Shield className="w-4 h-4" />
                      <span>Police Investigation</span>
                    </div>
                    <div className="text-[11px] text-slate-600 dark:text-slate-300 font-semibold line-clamp-2">
                      {selectedReport.policeDispatch.stationName}
                    </div>
                    <select
                      value={polStatus}
                      onChange={(e) => setPolStatus(e.target.value as PoliceResponseStatus)}
                      disabled={!canRoleUpdateAgency(currentUser.role, 'police')}
                      data-testid="authority-police-status-select"
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 px-2.5 py-1.5 text-xs disabled:opacity-60"
                    >
                      {POLICE_STATUSES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      value={polNotes}
                      onChange={(e) => setPolNotes(e.target.value)}
                      disabled={!canRoleUpdateAgency(currentUser.role, 'police')}
                      placeholder="Traffic cordon / FIR / clearance note..."
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 px-2.5 py-1.5 text-xs disabled:opacity-60"
                    />
                    <button
                      type="button"
                      disabled={!canRoleUpdateAgency(currentUser.role, 'police') || savingAgency === 'police'}
                      data-testid="update-police-btn"
                      onClick={() => handleAgencySave('police')}
                      className="w-full py-1.5 rounded-lg bg-blue-700 hover:bg-blue-800 disabled:bg-slate-300 dark:disabled:bg-slate-700 text-white text-xs font-bold cursor-pointer disabled:cursor-not-allowed"
                    >
                      {savingAgency === 'police' ? 'Updating...' : 'Update Police Status'}
                    </button>
                  </div>
                </div>

                {/* Overall Case Resolution Bar (Police Officer or Super Admin) */}
                {canRoleUpdateAgency(currentUser.role, 'overall') && (
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2 text-xs">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span className="font-bold text-slate-700 dark:text-slate-300">
                        Overall Incident Resolution:
                      </span>
                      <select
                        value={overallStatus}
                        onChange={(e) => setOverallStatus(e.target.value as AccidentOverallStatus)}
                        data-testid="authority-overall-status-select"
                        className="rounded-lg border border-slate-300 dark:border-slate-700 px-2.5 py-1 text-xs font-semibold"
                      >
                        {OVERALL_STATUSES.map((st) => (
                          <option key={st} value={st}>
                            {st}
                          </option>
                        ))}
                      </select>
                    </div>

                    <button
                      type="button"
                      disabled={savingAgency === 'overall'}
                      data-testid="update-overall-status-btn"
                      onClick={() => handleAgencySave('overall')}
                      className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer"
                    >
                      {savingAgency === 'overall' ? 'Saving...' : 'Save Case Status'}
                    </button>
                  </div>
                )}
              </div>

              {/* Notification Delivery & Response History */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-3">
                <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-red-600" />
                  <span>Notification & Incident Audit History</span>
                </h3>
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {selectedReport.responseHistory.map((evt) => (
                    <div
                      key={evt.id}
                      className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/70 text-xs flex items-start justify-between gap-3"
                    >
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white">
                          [{evt.agency}] {evt.actor}:
                        </span>{' '}
                        <span className="text-slate-600 dark:text-slate-300">{evt.message}</span>
                      </div>
                      <span className="font-mono text-[10px] text-slate-400 shrink-0 inline-flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(evt.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
