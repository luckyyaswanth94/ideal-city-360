import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { BusRoute, BusStop } from '../types';
import { 
  Bus, 
  MapPin, 
  Navigation, 
  ExternalLink, 
  Clock, 
  Zap, 
  ChevronRight, 
  RotateCcw,
  Maximize2,
  Info,
  Radio,
  Layers
} from 'lucide-react';

interface Props {
  routes: BusRoute[];
  initialRouteId?: string;
  isGoogleMapsDisabled?: boolean;
  onClose?: () => void;
}

export const BusRouteLeafletMap: React.FC<Props> = ({
  routes,
  initialRouteId,
  isGoogleMapsDisabled = false,
  onClose
}) => {
  const [selectedRouteId, setSelectedRouteId] = useState<string>(
    initialRouteId || (routes.length > 0 ? routes[0].id : '')
  );
  const [selectedStop, setSelectedStop] = useState<BusStop | null>(null);
  const [simulatedLiveActive, setSimulatedLiveActive] = useState<boolean>(true);

  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const routeLayerGroupRef = useRef<L.LayerGroup | null>(null);
  const markersMapRef = useRef<{ [stopId: string]: L.Marker }>({});

  const activeRoute = routes.find(r => r.id === selectedRouteId) || routes[0];

  // Update selected route when initialRouteId changes externally
  useEffect(() => {
    if (initialRouteId) {
      setSelectedRouteId(initialRouteId);
    }
  }, [initialRouteId]);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const defaultCenter: [number, number] = [17.4200, 78.4400]; // Ideal City central transit coords
      const map = L.map(mapContainerRef.current, {
        center: defaultCenter,
        zoom: 12,
        zoomControl: true,
        scrollWheelZoom: true
      });

      // CartoDB Voyager / OpenStreetMap standard tile provider
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        maxZoom: 19,
        subdomains: 'abcd'
      }).addTo(map);

      const layerGroup = L.layerGroup().addTo(map);
      routeLayerGroupRef.current = layerGroup;
      mapInstanceRef.current = map;
    }

    return () => {
      // Map cleanup on unmount
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Draw Route Polyline & Stops whenever activeRoute changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    const layerGroup = routeLayerGroupRef.current;
    if (!map || !layerGroup || !activeRoute || !activeRoute.stops || activeRoute.stops.length === 0) return;

    // Clear previous route layers and markers
    layerGroup.clearLayers();
    markersMapRef.current = {};

    const stops = activeRoute.stops;
    const latLngs: [number, number][] = stops.map(s => [s.lat, s.lng]);

    // 1. Polyline Outer Glow Line (Electric Transit Corridor)
    L.polyline(latLngs, {
      color: '#38bdf8',
      weight: 8,
      opacity: 0.45,
      lineCap: 'round',
      lineJoin: 'round'
    }).addTo(layerGroup);

    // 2. Main Polyline (Vibrant transit path)
    const mainLine = L.polyline(latLngs, {
      color: '#0284c7',
      weight: 4,
      opacity: 0.95,
      dashArray: '6, 8',
      lineCap: 'round',
      lineJoin: 'round'
    }).addTo(layerGroup);

    // 3. Sequential Stop Markers
    stops.forEach((stop, index) => {
      const isOrigin = index === 0;
      const isDestination = index === stops.length - 1;

      // Custom HTML Marker with Tailwind Badges
      let bgColor = 'bg-sky-600 text-white border-white';
      let label = `${stop.order}`;
      let badgeStyle = 'w-7 h-7';

      if (isOrigin) {
        bgColor = 'bg-emerald-600 text-white border-white';
        label = '1';
        badgeStyle = 'w-8 h-8 ring-4 ring-emerald-400/40';
      } else if (isDestination) {
        bgColor = 'bg-rose-600 text-white border-white';
        label = `${stops.length}`;
        badgeStyle = 'w-8 h-8 ring-4 ring-rose-400/40';
      }

      const customIcon = L.divIcon({
        className: 'custom-stop-div-icon',
        html: `
          <div class="flex flex-col items-center group cursor-pointer" style="transform: translate(-50%, -50%);">
            <div class="${badgeStyle} ${bgColor} rounded-full flex items-center justify-center font-bold text-xs shadow-md border-2 transition-transform hover:scale-125">
              ${label}
            </div>
            <div class="mt-1 bg-slate-900/90 text-white text-[10px] font-semibold px-1.5 py-0.5 rounded shadow-sm whitespace-nowrap pointer-events-none">
              ${stop.name}
            </div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      });

      const marker = L.marker([stop.lat, stop.lng], { icon: customIcon });

      // Interactive popup
      const popupHtml = `
        <div style="font-family: inherit; min-width: 200px; padding: 4px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
            <span style="font-size: 10px; font-weight: 800; text-transform: uppercase; padding: 2px 6px; border-radius: 4px; ${
              isOrigin 
                ? 'background: #ecfdf5; color: #047857; border: 1px solid #a7f3d0;' 
                : isDestination 
                ? 'background: #fff1f2; color: #be123c; border: 1px solid #fecdd3;' 
                : 'background: #f0f9ff; color: #0369a1; border: 1px solid #bae6fd;'
            }">
              ${isOrigin ? 'Origin Station' : isDestination ? 'Terminal Station' : `Stop #${stop.order}`}
            </span>
            <span style="font-size: 11px; font-weight: 700; color: #0284c7;">Route ${activeRoute.routeNumber}</span>
          </div>
          <h4 style="font-size: 13px; font-weight: 700; color: #0f172a; margin: 0 0 4px 0;">${stop.name}</h4>
          <p style="font-size: 11px; color: #64748b; margin: 0 0 8px 0;">
            Station ${stop.order} of ${stops.length} on corridor
          </p>
          <div style="display: flex; align-items: center; justify-content: space-between; font-size: 10px; border-top: 1px solid #e2e8f0; padding-top: 6px; color: #475569;">
            <span>GPS: ${stop.lat.toFixed(4)}°, ${stop.lng.toFixed(4)}°</span>
            <a 
              href="https://www.google.com/maps/search/?api=1&query=${stop.lat},${stop.lng}" 
              target="_blank" 
              rel="noopener noreferrer"
              style="color: #0284c7; font-weight: 700; text-decoration: underline;"
            >
              Directions ➔
            </a>
          </div>
        </div>
      `;

      marker.bindPopup(popupHtml);
      marker.on('click', () => {
        setSelectedStop(stop);
      });

      marker.addTo(layerGroup);
      markersMapRef.current[stop.id] = marker;
    });

    // 4. Simulated Live Telematics Bus Marker on stop #2 or middle stop
    if (simulatedLiveActive && stops.length >= 2) {
      const liveStopIndex = Math.min(2, stops.length - 1);
      const liveStop = stops[liveStopIndex];
      const liveBusIcon = L.divIcon({
        className: 'live-bus-div-icon',
        html: `
          <div class="relative flex items-center justify-center cursor-pointer" style="transform: translate(-50%, -50%);">
            <span class="absolute w-8 h-8 rounded-full bg-emerald-500 animate-ping opacity-75"></span>
            <div class="relative w-8 h-8 rounded-xl bg-gradient-to-tr from-slate-900 via-sky-900 to-teal-600 text-white flex items-center justify-center shadow-lg border-2 border-emerald-400">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M8 6v6"/>
                <path d="M15 6v6"/>
                <path d="M2 12h19.6"/>
                <path d="M18 18h3s.5-1.7.8-2.8c.1-.4.2-.8.2-1.2 0-.4-.1-.8-.2-1.2l-1.4-5C20.1 6.8 19.1 6 18 6H4c-1.1 0-2.1.8-2.4 1.8l-1.4 5C0 13.2 0 13.6 0 14c0 .4.1.8.2 1.2.3 1.1.8 2.8.8 2.8h3"/>
                <circle cx="7" cy="18" r="2"/>
                <circle cx="15" cy="18" r="2"/>
              </svg>
            </div>
            <div class="absolute -top-5 bg-emerald-600 text-white text-[9px] font-black px-1.5 py-0.2 rounded-full uppercase tracking-wider shadow-sm">
              LIVE GPS
            </div>
          </div>
        `,
        iconSize: [36, 36],
        iconAnchor: [18, 18]
      });

      const liveMarker = L.marker([liveStop.lat + 0.001, liveStop.lng + 0.001], { icon: liveBusIcon });
      liveMarker.bindPopup(`
        <div style="font-family: inherit; padding: 4px;">
          <div style="font-size: 10px; font-weight: 800; color: #047857; text-transform: uppercase;">● Live In-Service Telematics</div>
          <h4 style="font-size: 13px; font-weight: 700; color: #0f172a; margin: 2px 0;">Bus #${activeRoute.routeNumber} - Unit TG-09-EV-4421</h4>
          <p style="font-size: 11px; color: #475569; margin: 0 0 4px 0;">Current Station: <strong>${liveStop.name}</strong></p>
          <div style="font-size: 10px; color: #059669; font-weight: 600;">Status: On Schedule • Next Stop: ${stops[Math.min(liveStopIndex + 1, stops.length - 1)].name}</div>
        </div>
      `);
      liveMarker.addTo(layerGroup);
    }

    // Fit map bounds to show full route path with padding
    try {
      const bounds = mainLine.getBounds();
      if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
      }
    } catch {
      map.setView(latLngs[0], 12);
    }
  }, [selectedRouteId, activeRoute, simulatedLiveActive]);

  // Handle clicking a stop from the sidebar list
  const handleSelectStop = (stop: BusStop) => {
    setSelectedStop(stop);
    const map = mapInstanceRef.current;
    if (map) {
      map.flyTo([stop.lat, stop.lng], 15, { duration: 0.8 });
      const marker = markersMapRef.current[stop.id];
      if (marker) {
        marker.openPopup();
      }
    }
  };

  const handleResetBounds = () => {
    const map = mapInstanceRef.current;
    if (!map || !activeRoute) return;
    const latLngs: [number, number][] = activeRoute.stops.map(s => [s.lat, s.lng]);
    const polyline = L.polyline(latLngs);
    try {
      map.fitBounds(polyline.getBounds(), { padding: [50, 50] });
    } catch {
      map.setView(latLngs[0], 12);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-lg border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col">
      {/* Top Header & Route Switcher */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white flex flex-wrap items-center justify-between gap-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-400 animate-pulse"></span>
            <span className="text-xs font-bold uppercase tracking-wider text-sky-300 flex items-center gap-1">
              <Bus className="w-3.5 h-3.5" /> Leaflet Visual Route Path & Stop Overlay
            </span>
            {isGoogleMapsDisabled ? (
              <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                Google Maps Offline • OpenStreetMap Active
              </span>
            ) : (
              <span className="bg-teal-500/20 text-teal-300 border border-teal-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                Synchronized Transit GIS
              </span>
            )}
          </div>
          <h2 className="text-lg sm:text-xl font-extrabold text-white flex items-center gap-2">
            <span>Route {activeRoute?.routeNumber}:</span>
            <span className="text-sky-200 font-semibold text-sm sm:text-base truncate max-w-md">
              {activeRoute?.name}
            </span>
          </h2>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleResetBounds}
            title="Reset Map Bounds"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors text-xs font-semibold flex items-center gap-1 border border-slate-700 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Fit Route</span>
          </button>
          
          <button
            type="button"
            onClick={() => setSimulatedLiveActive(!simulatedLiveActive)}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border ${
              simulatedLiveActive 
                ? 'bg-emerald-600/30 text-emerald-300 border-emerald-500/40' 
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
          >
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>{simulatedLiveActive ? 'Live Telematics Active' : 'Hide Live Bus'}</span>
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-rose-900/60 text-slate-300 hover:text-rose-200 transition-colors text-xs font-bold border border-slate-700 cursor-pointer"
            >
              Close
            </button>
          )}
        </div>
      </div>

      {/* Route Quick Selector Tabs */}
      <div className="px-4 py-2.5 bg-slate-100 dark:bg-slate-950/80 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar">
        <span className="text-xs font-bold text-slate-500 dark:text-slate-400 shrink-0">
          Select Corridor:
        </span>
        {routes.map(route => {
          const isCurrent = route.id === activeRoute?.id;
          return (
            <button
              key={route.id}
              type="button"
              onClick={() => {
                setSelectedRouteId(route.id);
                setSelectedStop(null);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 cursor-pointer ${
                isCurrent
                  ? 'bg-sky-600 text-white shadow-xs scale-102'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-sky-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
              }`}
            >
              <span>Route {route.routeNumber}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded ${
                isCurrent ? 'bg-sky-800 text-sky-200' : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400'
              }`}>
                {route.stops.length} stops
              </span>
            </button>
          );
        })}
      </div>

      {/* Main Map Body: Leaflet Map + Stop Timeline Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-4 min-h-[500px]">
        {/* Left / Main: Leaflet Map View */}
        <div className="lg:col-span-3 relative h-[420px] sm:h-[480px] lg:h-[540px] w-full bg-slate-200 dark:bg-slate-950">
          <div ref={mapContainerRef} className="w-full h-full z-10" />

          {/* Map Overlay Badge */}
          <div className="absolute bottom-4 left-4 z-20 pointer-events-none">
            <div className="bg-slate-900/90 backdrop-blur-md text-white px-3 py-2 rounded-xl text-xs shadow-lg border border-slate-700/80 flex items-center gap-3">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block"></span>
                <span className="font-semibold text-[11px]">1. Origin</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-sky-500 inline-block"></span>
                <span className="font-semibold text-[11px]">Transit Stops</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-500 inline-block"></span>
                <span className="font-semibold text-[11px]">N. Terminus</span>
              </div>
            </div>
          </div>

          {/* Fallback Placeholder Notice if Google Maps is Disabled */}
          {isGoogleMapsDisabled && (
            <div className="absolute top-4 right-4 z-20 max-w-xs">
              <div className="bg-amber-50 dark:bg-slate-900/95 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-800/80 rounded-xl p-3 shadow-md text-xs">
                <div className="font-bold flex items-center gap-1 mb-1">
                  <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                  <span>OpenStreetMap Transit Engine Active</span>
                </div>
                <p className="text-[11px] text-amber-800 dark:text-amber-300/90 leading-tight">
                  Google Maps is currently unconfigured or offline. Leaflet OpenStreetMap is providing zero-downtime path rendering and stop telematics.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Right: Sequential Stop Sequence & Station Timeline */}
        <div className="lg:col-span-1 bg-slate-50 dark:bg-slate-950 border-t lg:border-t-0 lg:border-l border-slate-200 dark:border-slate-800 p-4 flex flex-col h-[340px] lg:h-[540px]">
          <div className="pb-3 border-b border-slate-200 dark:border-slate-800 mb-2 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-xs text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-sky-600" />
                Route Stations ({activeRoute?.stops.length})
              </h3>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Click any station to focus camera & view details
              </p>
            </div>
            <span className="text-[11px] font-extrabold text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950 px-2 py-0.5 rounded-md border border-sky-200 dark:border-sky-800">
              {activeRoute?.distanceKm} km
            </span>
          </div>

          {/* Station List with connecting timeline line */}
          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {activeRoute?.stops.map((stop, idx) => {
              const isFirst = idx === 0;
              const isLast = idx === activeRoute.stops.length - 1;
              const isSelected = selectedStop?.id === stop.id;

              return (
                <button
                  key={stop.id}
                  type="button"
                  onClick={() => handleSelectStop(stop)}
                  className={`w-full text-left p-2.5 rounded-xl border transition-all text-xs flex items-start gap-2.5 cursor-pointer ${
                    isSelected
                      ? 'bg-sky-100/80 dark:bg-sky-950/80 border-sky-400 dark:border-sky-700 shadow-xs'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-sky-300 dark:hover:border-slate-700'
                  }`}
                >
                  {/* Sequence pill */}
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5 ${
                    isFirst 
                      ? 'bg-emerald-600 text-white' 
                      : isLast 
                      ? 'bg-rose-600 text-white' 
                      : 'bg-sky-100 dark:bg-sky-900/60 text-sky-800 dark:text-sky-300'
                  }`}>
                    {stop.order}
                  </span>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-800 dark:text-slate-200 truncate">
                        {stop.name}
                      </span>
                      {isFirst && (
                        <span className="text-[9px] font-bold text-emerald-700 dark:text-emerald-400 uppercase bg-emerald-50 dark:bg-emerald-950/60 px-1 py-0.2 rounded shrink-0">
                          Start
                        </span>
                      )}
                      {isLast && (
                        <span className="text-[9px] font-bold text-rose-700 dark:text-rose-400 uppercase bg-rose-50 dark:bg-rose-950/60 px-1 py-0.2 rounded shrink-0">
                          Terminus
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5 flex items-center justify-between">
                      <span>{stop.lat.toFixed(4)}°N, {stop.lng.toFixed(4)}°E</span>
                      <span className="text-sky-600 dark:text-sky-400 font-semibold flex items-center gap-0.5">
                        Inspect <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Route Metrics Summary Footer */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 mt-2 text-[11px] text-slate-600 dark:text-slate-300 grid grid-cols-2 gap-2">
            <div className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-800">
              <span className="text-[10px] text-slate-400 block">Frequency</span>
              <strong className="text-slate-900 dark:text-white">Every {activeRoute?.frequencyMinutes} mins</strong>
            </div>
            <div className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-800">
              <span className="text-[10px] text-slate-400 block">Travel Duration</span>
              <strong className="text-slate-900 dark:text-white">{activeRoute?.travelTimeMinutes} mins</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
