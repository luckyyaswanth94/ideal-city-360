import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type {
  AccidentReport,
  AmbulanceUnit,
  Hospital,
  PoliceStation,
} from '../types';
import {
  buildGoogleMapsDirectionsUrl,
  buildGoogleMapsUrl,
  DEFAULT_CITY_CENTER,
} from '../utils/accidentEmergency';
import { Crosshair, ExternalLink, Navigation } from 'lucide-react';

interface Props {
  mode: 'picker' | 'command';
  latitude?: number;
  longitude?: number;
  onSelectLocation?: (lat: number, lng: number) => void;
  reports?: AccidentReport[];
  selectedReportId?: string | null;
  onSelectReport?: (reportId: string) => void;
  hospitals?: Hospital[];
  policeStations?: PoliceStation[];
  ambulanceUnits?: AmbulanceUnit[];
  heightClass?: string;
}

export const AccidentLocationMap: React.FC<Props> = ({
  mode,
  latitude = DEFAULT_CITY_CENTER.lat,
  longitude = DEFAULT_CITY_CENTER.lng,
  onSelectLocation,
  reports = [],
  selectedReportId = null,
  onSelectReport,
  hospitals = [],
  policeStations = [],
  ambulanceUnits = [],
  heightClass = 'h-72 sm:h-80',
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);
  const onSelectLocationRef = useRef(onSelectLocation);
  const onSelectReportRef = useRef(onSelectReport);

  onSelectLocationRef.current = onSelectLocation;
  onSelectReportRef.current = onSelectReport;

  const selectedReport =
    mode === 'command'
      ? reports.find((r) => r.id === selectedReportId) || reports[0] || null
      : null;

  // Initialize Leaflet map once
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [latitude, longitude],
      zoom: 13,
      zoomControl: true,
      scrollWheelZoom: false,
    });

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    const group = L.layerGroup().addTo(map);
    mapRef.current = map;
    layerGroupRef.current = group;

    if (mode === 'picker') {
      map.on('click', (e: L.LeafletMouseEvent) => {
        if (onSelectLocationRef.current) {
          onSelectLocationRef.current(
            Number(e.latlng.lat.toFixed(6)),
            Number(e.latlng.lng.toFixed(6))
          );
        }
      });
    }

    const resizeTimer = window.setTimeout(() => {
      map.invalidateSize();
    }, 180);

    return () => {
      window.clearTimeout(resizeTimer);
      map.remove();
      mapRef.current = null;
      layerGroupRef.current = null;
    };
  }, [mode]);

  // Render markers & ambulance route polyline
  useEffect(() => {
    const map = mapRef.current;
    const group = layerGroupRef.current;
    if (!map || !group) return;

    group.clearLayers();
    const bounds: [number, number][] = [];

    if (mode === 'picker') {
      const pinIcon = L.divIcon({
        className: 'accident-pin-icon',
        html: `
          <div style="display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:9999px;background:#dc2626;border:3px solid #ffffff;box-shadow:0 6px 16px rgba(220,38,38,0.45);color:#ffffff;font-weight:900;font-size:13px;">
            SOS
          </div>
        `,
        iconSize: [36, 36],
        iconAnchor: [18, 18],
      });

      const marker = L.marker([latitude, longitude], { icon: pinIcon }).addTo(group);
      marker.bindPopup(
        `<div style="font-size:12px;line-height:1.4"><strong>Accident Location Pin</strong><br/><span style="font-family:monospace">${latitude.toFixed(5)}, ${longitude.toFixed(5)}</span><br/><span style="color:#64748b">Click anywhere on the map to move pin</span></div>`
      );

      // Nearby hospitals as subtle reference pins
      hospitals.forEach((h) => {
        const hIcon = L.divIcon({
          className: 'trauma-hospital-pin-icon',
          html: `<div style="width:24px;height:24px;border-radius:6px;background:#0f766e;border:2px solid #ffffff;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:12px;box-shadow:0 3px 8px rgba(0,0,0,0.2);">H</div>`,
          iconSize: [24, 24],
          iconAnchor: [12, 12],
        });
        L.marker([h.location.lat, h.location.lng], { icon: hIcon })
          .bindPopup(`<div style="font-size:12px"><strong>${h.name}</strong><br/>Emergency: ${h.emergencyPhone}</div>`)
          .addTo(group);
      });

      map.setView([latitude, longitude], Math.max(map.getZoom(), 14), { animate: false });
      return;
    }

    // Command / Tracking mode
    reports.forEach((rep) => {
      const isSelected = selectedReport?.id === rep.id;
      const color =
        rep.overallStatus === 'Resolved'
          ? '#16a34a'
          : rep.severity === 'Critical' || rep.overallStatus === 'Active Emergency'
            ? '#dc2626'
            : '#ea580c';

      const size = isSelected ? 38 : 30;
      const icon = L.divIcon({
        className: 'accident-pin-icon',
        html: `
          <div style="display:flex;align-items:center;justify-content:center;width:${size}px;height:${size}px;border-radius:9999px;background:${color};border:${isSelected ? '3.5px' : '2.5px'} solid #ffffff;box-shadow:0 6px 16px rgba(0,0,0,0.3);color:#ffffff;font-weight:900;font-size:${isSelected ? '11px' : '10px'};">
            ${rep.overallStatus === 'Resolved' ? 'OK' : 'SOS'}
          </div>
        `,
        iconSize: [size, size],
        iconAnchor: [size / 2, size / 2],
      });

      const m = L.marker([rep.latitude, rep.longitude], { icon }).addTo(group);
      m.bindPopup(
        `<div style="font-size:12px;min-width:190px;line-height:1.45">
          <div style="font-weight:800;color:${color}">${rep.incidentCode} · ${rep.severity}</div>
          <div style="font-weight:700;margin-top:2px">${rep.accidentType}</div>
          <div style="color:#475569;margin-top:2px">${rep.locationLabel}</div>
          <div style="font-family:monospace;font-size:11px;margin-top:4px">${rep.latitude.toFixed(5)}, ${rep.longitude.toFixed(5)}</div>
          <div style="margin-top:4px;font-weight:600">Status: ${rep.overallStatus}</div>
        </div>`
      );
      m.on('click', () => {
        if (onSelectReportRef.current) {
          onSelectReportRef.current(rep.id);
        }
      });
      bounds.push([rep.latitude, rep.longitude]);
    });

    if (selectedReport) {
      // Draw Ambulance shortest route polyline
      const amb = selectedReport.ambulanceDispatch;
      if (amb.routeWaypoints && amb.routeWaypoints.length >= 2) {
        const latLngs = amb.routeWaypoints.map((w) => [w.lat, w.lng] as [number, number]);
        L.polyline(latLngs, {
          color: '#ea580c',
          weight: 5,
          opacity: 0.9,
          dashArray: selectedReport.overallStatus === 'Resolved' ? '6 8' : undefined,
        }).addTo(group);
        latLngs.forEach((pt) => bounds.push(pt));
      }

      // Ambulance origin marker
      const ambIcon = L.divIcon({
        className: 'ambulance-pin-icon',
        html: `<div style="padding:2px 7px;border-radius:9999px;background:#ea580c;border:2px solid #ffffff;color:#ffffff;font-weight:800;font-size:10px;white-space:nowrap;box-shadow:0 4px 10px rgba(234,88,12,0.4);">108 EMS</div>`,
        iconSize: [64, 22],
        iconAnchor: [32, 11],
      });
      L.marker([amb.originLat, amb.originLng], { icon: ambIcon })
        .bindPopup(
          `<div style="font-size:12px"><strong>${amb.callSign}</strong> (${amb.vehicleNumber})<br/>${amb.stationName}<br/>Status: <strong>${amb.status}</strong>${amb.etaMinutes !== null ? `<br/>ETA: <strong>${amb.etaMinutes} min</strong> (${amb.distanceKm} km)` : ''}</div>`
        )
        .addTo(group);
      bounds.push([amb.originLat, amb.originLng]);

      // Notified nearest hospitals
      selectedReport.notifiedHospitals.forEach((h) => {
        const hIcon = L.divIcon({
          className: 'trauma-hospital-pin-icon',
          html: `<div style="width:26px;height:26px;border-radius:7px;background:#0d9488;border:2px solid #ffffff;color:#ffffff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:12px;box-shadow:0 4px 10px rgba(13,148,136,0.35);">H</div>`,
          iconSize: [26, 26],
          iconAnchor: [13, 13],
        });
        L.marker([h.lat, h.lng], { icon: hIcon })
          .bindPopup(
            `<div style="font-size:12px"><strong>${h.hospitalName}</strong><br/>Distance: ${h.distanceKm} km<br/>Status: <strong>${h.status}</strong><br/>Emergency: ${h.emergencyPhone}</div>`
          )
          .addTo(group);
        bounds.push([h.lat, h.lng]);
      });

      // Nearest police station
      const pol = selectedReport.policeDispatch;
      const polIcon = L.divIcon({
        className: 'police-pin-icon',
        html: `<div style="width:26px;height:26px;border-radius:7px;background:#1d4ed8;border:2px solid #ffffff;color:#ffffff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:11px;box-shadow:0 4px 10px rgba(29,78,216,0.35);">P</div>`,
        iconSize: [26, 26],
        iconAnchor: [13, 13],
      });
      L.marker([pol.lat, pol.lng], { icon: polIcon })
        .bindPopup(
          `<div style="font-size:12px"><strong>${pol.stationName}</strong><br/>Distance: ${pol.distanceKm} km<br/>Status: <strong>${pol.status}</strong><br/>Phone: ${pol.phone}</div>`
        )
        .addTo(group);
      bounds.push([pol.lat, pol.lng]);
    } else {
      // Fallback city stations if no incident selected
      policeStations.forEach((p) => bounds.push([p.lat, p.lng]));
      ambulanceUnits.forEach((a) => bounds.push([a.lat, a.lng]));
    }

    if (bounds.length >= 2) {
      map.fitBounds(L.latLngBounds(bounds), { padding: [36, 36], maxZoom: 15, animate: false });
    } else if (bounds.length === 1) {
      map.setView(bounds[0], 14, { animate: false });
    }
  }, [mode, latitude, longitude, reports, selectedReport, hospitals, policeStations, ambulanceUnits]);

  const activeLat = mode === 'picker' ? latitude : selectedReport?.latitude ?? DEFAULT_CITY_CENTER.lat;
  const activeLng = mode === 'picker' ? longitude : selectedReport?.longitude ?? DEFAULT_CITY_CENTER.lng;
  const gmapsPinUrl = buildGoogleMapsUrl(activeLat, activeLng);
  const gmapsDirUrl =
    mode === 'command' && selectedReport
      ? buildGoogleMapsDirectionsUrl(
          selectedReport.ambulanceDispatch.originLat,
          selectedReport.ambulanceDispatch.originLng,
          selectedReport.latitude,
          selectedReport.longitude
        )
      : null;

  const handleRecenter = () => {
    if (!mapRef.current) return;
    mapRef.current.setView([activeLat, activeLng], 14, { animate: true });
  };

  return (
    <div className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
      <div className="relative z-0 isolate">
        <div
          ref={containerRef}
          data-testid={`accident-map-${mode}`}
          className={`w-full ${heightClass} z-0`}
        />
        <button
          type="button"
          onClick={handleRecenter}
          className="absolute top-3 right-3 z-[400] bg-white/95 dark:bg-slate-900/95 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-semibold shadow-sm flex items-center gap-1.5 cursor-pointer"
        >
          <Crosshair className="w-3.5 h-3.5 text-red-600" />
          <span>Center Pin</span>
        </button>
      </div>

      {/* Dedicated Legend & Google Maps Link Bar beneath canvas (never overlaps map controls) */}
      <div className="px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/90 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-600 dark:text-slate-300">
        <div className="flex flex-wrap items-center gap-3">
          <span className="inline-flex items-center gap-1.5 font-medium">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 inline-block" />
            Accident / Active
          </span>
          {mode === 'command' && (
            <>
              <span className="inline-flex items-center gap-1.5 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-orange-600 inline-block" />
                108 Ambulance Route
              </span>
              <span className="inline-flex items-center gap-1.5 font-medium">
                <span className="w-2.5 h-2.5 rounded-sm bg-teal-600 inline-block" />
                Hospital
              </span>
              <span className="inline-flex items-center gap-1.5 font-medium">
                <span className="w-2.5 h-2.5 rounded-sm bg-blue-700 inline-block" />
                Police Station
              </span>
              <span className="inline-flex items-center gap-1.5 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block" />
                Resolved
              </span>
            </>
          )}
          {mode === 'picker' && (
            <span className="text-slate-500 dark:text-slate-400">
              Click map to adjust exact accident pin
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <a
            href={gmapsPinUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-teal-700 dark:text-teal-400 hover:underline font-semibold"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Google Maps Pin</span>
          </a>
          {gmapsDirUrl && (
            <a
              href={gmapsDirUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-orange-700 dark:text-orange-400 hover:underline font-semibold"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Shortest Route</span>
            </a>
          )}
        </div>
      </div>
    </div>
  );
};
