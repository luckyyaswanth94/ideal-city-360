import React, { useEffect, useRef, useState } from 'react';
import type {
  AccidentAiAnalysis,
  AccidentReport,
  AccidentSeverity,
  AccidentType,
  Hospital,
} from '../types';
import {
  AI_CAUSE_DISCLAIMER,
  buildGoogleMapsUrl,
  DEFAULT_CITY_CENTER,
  formatSafeIncidentDescription,
  PRIVACY_ASSURANCE_MESSAGE,
  RETENTION_POLICY_DAYS,
  VALID_ACCIDENT_SEVERITIES,
  VALID_ACCIDENT_TYPES,
} from '../utils/accidentEmergency';
import { AccidentLocationMap } from './AccidentLocationMap';
import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  ExternalLink,
  EyeOff,
  Loader2,
  Lock,
  MapPin,
  PhoneCall,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Upload,
} from 'lucide-react';

interface Props {
  hospitals: Hospital[];
  onReportSubmitted: (report: AccidentReport, trackingToken: string) => void;
}

const CITY_QUICK_ZONES = [
  { label: 'Cyber Corridor (Jubilee Valley)', lat: 17.4264, lng: 78.4141 },
  { label: 'Central Secretariat Circle', lat: 17.4088, lng: 78.4754 },
  { label: 'North Zone Paradise Flyover', lat: 17.4419, lng: 78.4962 },
  { label: 'South Zone Red Hills Road', lat: 17.3976, lng: 78.4628 },
];

const EMERGENCY_HELPLINES = [
  { label: '108 Ambulance', number: '108', desc: 'Trauma EMS' },
  { label: '100 / 112 Police', number: '112', desc: 'National Emergency' },
  { label: '101 Fire & Rescue', number: '101', desc: 'Vehicle Extrication' },
  { label: '1091 Women Safety', number: '1091', desc: 'SHE Teams' },
];

/**
 * Re-encoding through <canvas> compresses large mobile photos and strips client-side
 * EXIF/GPS/camera metadata before network transmission (also re-stripped server-side).
 */
function compressAndStripImageElement(
  img: HTMLImageElement,
  maxDim = 1024,
  quality = 0.8
): string {
  const scale = Math.min(1, maxDim / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
  const width = Math.max(1, Math.round((img.naturalWidth || maxDim) * scale));
  const height = Math.max(1, Math.round((img.naturalHeight || maxDim) * scale));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable');
  ctx.drawImage(img, 0, 0, width, height);
  return canvas.toDataURL('image/jpeg', quality);
}

async function compressDataUrl(rawDataUrl: string): Promise<{ dataUrl: string; mimeType: string }> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const compressed = compressAndStripImageElement(img, 1024, 0.8);
        resolve({ dataUrl: compressed, mimeType: 'image/jpeg' });
      } catch {
        resolve({ dataUrl: rawDataUrl, mimeType: 'image/jpeg' });
      }
    };
    img.onerror = () => resolve({ dataUrl: rawDataUrl, mimeType: 'image/jpeg' });
    img.src = rawDataUrl;
  });
}

async function urlToDataUrl(url: string): Promise<{ dataUrl: string; mimeType: string }> {
  const res = await fetch(url);
  const blob = await res.blob();
  const rawDataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') resolve(reader.result);
      else reject(new Error('Failed to encode image'));
    };
    reader.onerror = () => reject(new Error('Failed to read image blob'));
    reader.readAsDataURL(blob);
  });
  return compressDataUrl(rawDataUrl);
}

export const AccidentReportFlow: React.FC<Props> = ({
  hospitals,
  onReportSubmitted,
}) => {
  const uploadInputRef = useRef<HTMLInputElement | null>(null);
  const captureInputRef = useRef<HTMLInputElement | null>(null);

  const [photoDataUrl, setPhotoDataUrl] = useState<string>('');
  const [photoMimeType, setPhotoMimeType] = useState<string>('image/jpeg');
  const [photoName, setPhotoName] = useState<string>('');
  const [exifVerifiedStripped, setExifVerifiedStripped] = useState<boolean>(false);

  const [latitude, setLatitude] = useState<number>(DEFAULT_CITY_CENTER.lat);
  const [longitude, setLongitude] = useState<number>(DEFAULT_CITY_CENTER.lng);
  const [locationSource, setLocationSource] = useState<'gps' | 'manual_map'>('manual_map');
  const [locationLabel, setLocationLabel] = useState<string>(
    'Ideal City Central Corridor (Click map to refine)'
  );
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'detecting' | 'acquired' | 'unavailable'>('idle');
  const [gpsMessage, setGpsMessage] = useState<string>('');

  const [analyzing, setAnalyzing] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<AccidentAiAnalysis | null>(null);

  const [accidentType, setAccidentType] = useState<AccidentType>('Two-Wheeler & Car Collision');
  const [severity, setSeverity] = useState<AccidentSeverity>('Medium');
  const [possibleInjuredCount, setPossibleInjuredCount] = useState<string>('1');
  const [sceneNotes, setSceneNotes] = useState<string>('');

  // Strictly opt-in optional callback — NEVER prefilled with account info
  const [showOptionalCallback, setShowOptionalCallback] = useState<boolean>(false);
  const [optionalCallbackPhone, setOptionalCallbackPhone] = useState<string>('');
  const [optionalCallbackConsented, setOptionalCallbackConsented] = useState<boolean>(false);

  const [reporterConfirmed, setReporterConfirmed] = useState<boolean>(false);

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const [clockNow, setClockNow] = useState(() => new Date());

  useEffect(() => {
    const timer = window.setInterval(() => setClockNow(new Date()), 30000);
    return () => window.clearInterval(timer);
  }, []);

  const detectGpsLocation = () => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setGpsStatus('unavailable');
      setLocationSource('manual_map');
      setGpsMessage('Device GPS is unavailable. Select the accident location directly on the map below.');
      return;
    }

    setGpsStatus('detecting');
    setGpsMessage('Requesting GPS coordinates for incident pin only...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(6));
        const lng = Number(pos.coords.longitude.toFixed(6));
        setLatitude(lat);
        setLongitude(lng);
        setLocationSource('gps');
        setLocationLabel(`Incident GPS Pin (${lat.toFixed(5)}, ${lng.toFixed(5)})`);
        setGpsStatus('acquired');
        setGpsMessage(`Incident coordinates locked (±${Math.round(pos.coords.accuracy)}m accuracy). Stored separately from image metadata.`);
      },
      () => {
        setGpsStatus('unavailable');
        setLocationSource('manual_map');
        setGpsMessage('GPS unavailable. Click the interactive map or choose a city corridor below.');
      },
      { enableHighAccuracy: true, timeout: 6000, maximumAge: 15000 }
    );
  };

  useEffect(() => {
    detectGpsLocation();
  }, []);

  const runAiAnalysis = async (
    base64DataUrl: string,
    mime: string,
    lat: number,
    lng: number
  ) => {
    setAnalyzing(true);
    setAiError(null);
    setAiAnalysis(null);
    setReporterConfirmed(false);

    try {
      const res = await fetch('/api/accidents/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64DataUrl,
          mimeType: mime,
          latitude: lat,
          longitude: lng,
        }),
      });
      const data = await res.json();
      if (data.exifStripped) {
        setExifVerifiedStripped(true);
      }
      if (!res.ok || !data.analysis) {
        setAiError(
          data.error ||
            'AI visual triage could not be completed. You may retry or use Manual Incident Classification.'
        );
        return;
      }

      const result: AccidentAiAnalysis = data.analysis;
      setAiAnalysis(result);
      setAccidentType(result.accidentType);
      setSeverity(result.severity);
    } catch {
      setAiError(
        'Unable to reach the AI image analysis endpoint. Please retry or select Manual Incident Classification below.'
      );
    } finally {
      setAnalyzing(false);
    }
  };

  const handleFilePicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setAiError('Please select a valid image file (JPEG, PNG, or WebP).');
      return;
    }

    const mime = file.type || 'image/jpeg';
    setPhotoName(file.name);
    setPhotoMimeType(mime);
    setExifVerifiedStripped(true);

    const reader = new FileReader();
    reader.onloadend = async () => {
      if (typeof reader.result === 'string') {
        const compressed = await compressDataUrl(reader.result);
        setPhotoDataUrl(compressed.dataUrl);
        setPhotoMimeType(compressed.mimeType);
        runAiAnalysis(compressed.dataUrl, compressed.mimeType, latitude, longitude);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleLoadSampleScene = async (
    assetPath: string,
    label: string,
    sampleLat: number,
    sampleLng: number,
    zoneLabel: string
  ) => {
    setPhotoName(label);
    setLatitude(sampleLat);
    setLongitude(sampleLng);
    setLocationLabel(zoneLabel);
    setLocationSource('manual_map');
    setExifVerifiedStripped(true);
    try {
      const { dataUrl, mimeType } = await urlToDataUrl(assetPath);
      setPhotoDataUrl(dataUrl);
      setPhotoMimeType(mimeType);
      await runAiAnalysis(dataUrl, mimeType, sampleLat, sampleLng);
    } catch {
      setPhotoDataUrl(assetPath);
      setAiError('Loaded sample image preview, but could not encode it for AI analysis.');
    }
  };

  const handleEnableManualClassification = () => {
    setAiError(null);
    setAiAnalysis({
      isAccidentDetected: true,
      accidentType,
      severity,
      confidenceLabel: 'Low',
      visibleIndicators: ['Manually classified by anonymous reporter (AI vision unavailable)'],
      estimatedInjuredHint: 'Requires on-site human medical assessment',
      shortDescription: formatSafeIncidentDescription(
        `Possible ${accidentType} reported anonymously. Accident severity requires human assessment.`,
        latitude,
        longitude
      ),
      disclaimer: AI_CAUSE_DISCLAIMER,
      analyzedAt: new Date().toISOString(),
      modelUsed: 'manual-anonymous-classification',
      isManualFallback: true,
    });
  };

  const handleMapLocationChange = (lat: number, lng: number) => {
    setLatitude(lat);
    setLongitude(lng);
    setLocationSource('manual_map');
    setLocationLabel(`Manual Map Pin (${lat.toFixed(5)}, ${lng.toFixed(5)})`);
  };

  const trimmedCallback = optionalCallbackPhone.trim();
  const isCallbackShared = showOptionalCallback && Boolean(trimmedCallback) && optionalCallbackConsented;
  const callbackConsentMissing = showOptionalCallback && Boolean(trimmedCallback) && !optionalCallbackConsented;

  const handleSubmitEmergencyReport = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    if (!photoDataUrl) {
      setSubmitError('Please upload or capture an accident photograph first.');
      return;
    }
    if (callbackConsentMissing) {
      setSubmitError(
        'Please check the separate explicit consent box to share your optional callback number, or clear the number to stay completely anonymous.'
      );
      return;
    }
    if (!reporterConfirmed) {
      setSubmitError(
        'Please confirm this is a real road accident before sending emergency alerts.'
      );
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/accidents/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          photoDataUrl,
          latitude,
          longitude,
          locationLabel,
          locationSource,
          accidentType,
          severity,
          possibleInjuredCount:
            possibleInjuredCount.trim() === '' ? null : Number(possibleInjuredCount),
          reporterConfirmed: true,
          sceneNotes,
          optionalCallbackConsented: isCallbackShared,
          optionalCallbackPhone: isCallbackShared ? trimmedCallback : undefined,
          aiAnalysis: aiAnalysis || {
            isAccidentDetected: true,
            accidentType,
            severity,
            confidenceLabel: 'Low',
            visibleIndicators: ['Verified accident photograph uploaded (EXIF stripped)'],
            estimatedInjuredHint: 'Requires on-site human assessment',
            shortDescription: formatSafeIncidentDescription(
              `Possible ${accidentType} reported anonymously. Accident severity requires human assessment.`,
              latitude,
              longitude
            ),
            disclaimer: AI_CAUSE_DISCLAIMER,
            analyzedAt: new Date().toISOString(),
            modelUsed: 'manual-anonymous-classification',
            isManualFallback: true,
          },
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.report || !data.trackingToken) {
        setSubmitError(
          data.error ||
            'Backend could not confirm emergency alert delivery. Please retry or call 108 / 112.'
        );
        return;
      }

      onReportSubmitted(data.report, data.trackingToken);
    } catch {
      setSubmitError(
        'Network error while sending emergency dispatch request. Please dial 108 (Ambulance) or 112 (Police) immediately.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const canSubmit =
    Boolean(photoDataUrl) &&
    reporterConfirmed &&
    !callbackConsentMissing &&
    !submitting &&
    !analyzing;
  const googleMapsUrl = buildGoogleMapsUrl(latitude, longitude);

  return (
    <div className="space-y-5">
      {/* High-Contrast Anonymous SOS Header & Emergency Helplines */}
      <div className="rounded-2xl bg-gradient-to-r from-red-700 via-red-600 to-rose-700 text-white p-5 sm:p-6 border border-red-500/40 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-100">
              <EyeOff className="w-4 h-4 shrink-0" />
              <span>Save Lives Without Exposing Identities · No Login Required</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              REPORT ACCIDENT ANONYMOUSLY
            </h2>
            <p className="text-xs sm:text-sm text-red-50/95 max-w-2xl leading-relaxed">
              No account, name, phone number, email, or address required. Upload a photo, confirm the incident location, and dispatch verified alerts to nearby hospitals, 108 ambulances, and traffic police while keeping your identity protected.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 gap-2 shrink-0">
            {EMERGENCY_HELPLINES.map((line) => (
              <a
                key={line.number}
                href={`tel:${line.number}`}
                className="bg-white/15 hover:bg-white/25 border border-white/25 rounded-xl px-3 py-2 flex items-center gap-2 transition-colors"
              >
                <PhoneCall className="w-4 h-4 text-white shrink-0" />
                <div className="min-w-0">
                  <div className="text-xs font-extrabold leading-tight truncate">
                    {line.label}
                  </div>
                  <div className="text-[10px] text-red-100 truncate">{line.desc}</div>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Mandatory Privacy Assurance Banner */}
      <div
        data-testid="privacy-assurance-banner"
        className="rounded-2xl bg-emerald-50 dark:bg-emerald-950/35 border border-emerald-200 dark:border-emerald-900 p-4 space-y-2"
      >
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <div className="text-xs font-extrabold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
              Complete Reporter Privacy Protection Active
            </div>
            <p className="text-xs sm:text-sm font-medium text-emerald-950 dark:text-emerald-100 leading-relaxed">
              {PRIVACY_ASSURANCE_MESSAGE}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 pl-12 text-[11px] font-semibold text-emerald-800/90 dark:text-emerald-300/90">
          <span>• No Login Required</span>
          <span>• EXIF / Device Metadata Auto-Stripped</span>
          <span>• AES-256 Encrypted Media Vault</span>
          <span>• No AI Training Without Consent</span>
          <span>• {RETENTION_POLICY_DAYS}-Day Auto-Purge (DPDP Act, 2023)</span>
        </div>
      </div>

      {/* Main 2-Column Fast Anonymous Emergency Form */}
      <form
        onSubmit={handleSubmitEmergencyReport}
        className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start"
      >
        {/* LEFT COLUMN: Photo Upload/Capture + AI Triage Analysis */}
        <div className="lg:col-span-6 space-y-5">
          {/* Step 1: Secure Photo Capture & Upload */}
          <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-red-600 dark:text-red-400">
                  Step 1 of 4 · Secure EXIF-Stripped Upload
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Upload or Capture Accident Photograph
                </h3>
              </div>
              {photoDataUrl && (
                <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 inline-flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  {exifVerifiedStripped ? 'EXIF Stripped' : 'Photo Ready'}
                </span>
              )}
            </div>

            <input
              ref={uploadInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={handleFilePicked}
              className="hidden"
              data-testid="accident-photo-upload-input"
            />
            <input
              ref={captureInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleFilePicked}
              className="hidden"
              data-testid="accident-photo-capture-input"
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => captureInputRef.current?.click()}
                className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-bold transition-colors cursor-pointer"
              >
                <Camera className="w-4 h-4" />
                <span>Capture Photo</span>
              </button>
              <button
                type="button"
                onClick={() => uploadInputRef.current?.click()}
                className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-sm font-bold transition-colors cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Upload Accident Photo</span>
              </button>
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
              Camera model, device details, and embedded EXIF GPS tags are stripped automatically both in your browser and on the server. Photographs are encrypted at rest and restricted to authorized emergency personnel only.
            </p>

            {/* Demo Sample Scene Loaders for rapid evaluation */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-2">
                Testing Demo Mode? Load a sample traffic scene photograph:
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  data-testid="load-sample-bike-car"
                  onClick={() =>
                    handleLoadSampleScene(
                      '/assets/accidents/bike-car-collision.jpg',
                      'bike-car-collision.jpg',
                      17.4264,
                      78.4141,
                      'Jubilee Valley Metro Pillar 42, Cyber Corridor'
                    )
                  }
                  className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 hover:border-red-400 transition-colors cursor-pointer"
                >
                  Sample: Two-Wheeler & Car
                </button>
                <button
                  type="button"
                  data-testid="load-sample-car-van"
                  onClick={() =>
                    handleLoadSampleScene(
                      '/assets/accidents/car-van-collision.jpg',
                      'car-van-collision.jpg',
                      17.4088,
                      78.4754,
                      'Raj Bhavan Boulevard Signal, Central Zone'
                    )
                  }
                  className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 hover:border-red-400 transition-colors cursor-pointer"
                >
                  Sample: Sedan & Delivery Van
                </button>
              </div>
            </div>

            {photoDataUrl ? (
              <div className="rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-950 relative">
                <img
                  src={photoDataUrl}
                  alt="Uploaded accident scene preview"
                  draggable={false}
                  onContextMenu={(e) => e.preventDefault()}
                  className="w-full h-56 object-cover select-none"
                />
                <div className="px-3 py-2 bg-slate-900/95 text-slate-200 text-xs flex items-center justify-between gap-2">
                  <span className="truncate font-mono">
                    {photoName || 'Accident photo attached'} · EXIF Cleaned
                  </span>
                  <button
                    type="button"
                    disabled={analyzing}
                    onClick={() => runAiAnalysis(photoDataUrl, photoMimeType, latitude, longitude)}
                    className="inline-flex items-center gap-1 text-teal-300 hover:text-teal-200 font-semibold shrink-0 cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${analyzing ? 'animate-spin' : ''}`} />
                    <span>Re-Analyze</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40 p-6 text-center text-xs text-slate-500 dark:text-slate-400">
                No photograph selected yet. Capture a live photo or upload an image to trigger anonymous AI accident triage.
              </div>
            )}
          </section>

          {/* Step 2: AI Accident Analysis Result */}
          <section
            data-testid="ai-analysis-panel"
            className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4"
          >
            <div className="flex items-center justify-between gap-2">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
                  Step 2 of 4 · AI Visual Triage (Not Used for Training)
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                  <span>AI Accident Detection & Severity Estimate</span>
                </h3>
              </div>
            </div>

            {analyzing && (
              <div className="rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 p-4 flex items-center gap-3">
                <Loader2 className="w-5 h-5 text-red-600 animate-spin shrink-0" />
                <div className="text-xs text-slate-700 dark:text-slate-300">
                  <div className="font-bold">Stripping EXIF & analyzing scene with Gemini Vision...</div>
                  <div className="text-slate-500 dark:text-slate-400">
                    Checking for road collision indicators, possible accident type, and visible severity.
                  </div>
                </div>
              </div>
            )}

            {aiError && !analyzing && (
              <div className="rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 p-4 space-y-3">
                <div className="flex items-start gap-2.5 text-xs text-amber-900 dark:text-amber-200">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold">AI Vision Analysis Unavailable</div>
                    <p className="mt-0.5 leading-relaxed">{aiError}</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {photoDataUrl && (
                    <button
                      type="button"
                      onClick={() => runAiAnalysis(photoDataUrl, photoMimeType, latitude, longitude)}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-800 text-white text-xs font-semibold cursor-pointer"
                    >
                      Retry AI Analysis
                    </button>
                  )}
                  <button
                    type="button"
                    data-testid="manual-classification-btn"
                    onClick={handleEnableManualClassification}
                    className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold cursor-pointer"
                  >
                    Continue with Manual Classification
                  </button>
                </div>
              </div>
            )}

            {aiAnalysis && !analyzing && (
              <div className="space-y-3">
                <div
                  className={`rounded-xl p-3.5 border text-xs flex items-start justify-between gap-3 ${
                    aiAnalysis.isAccidentDetected
                      ? 'bg-red-50 dark:bg-red-950/35 border-red-200 dark:border-red-900 text-red-950 dark:text-red-100'
                      : 'bg-amber-50 dark:bg-amber-950/35 border-amber-200 dark:border-amber-900 text-amber-950 dark:text-amber-100'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="font-extrabold text-sm">
                      {aiAnalysis.isAccidentDetected
                        ? 'Possible Road Accident Detected'
                        : 'No Road Accident Clearly Detected'}
                    </div>
                    <p className="leading-relaxed">{aiAnalysis.shortDescription}</p>
                  </div>
                  <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-white/80 dark:bg-slate-900/80 text-slate-700 dark:text-slate-300 shrink-0">
                    {aiAnalysis.isManualFallback ? 'Manual Mode' : aiAnalysis.modelUsed}
                  </span>
                </div>

                {aiAnalysis.visibleIndicators.length > 0 && (
                  <div className="text-xs space-y-1">
                    <div className="font-bold text-slate-700 dark:text-slate-300">
                      Visible Indicators Observed:
                    </div>
                    <ul className="list-disc pl-5 text-slate-600 dark:text-slate-400 space-y-0.5">
                      {aiAnalysis.visibleIndicators.map((ind, idx) => (
                        <li key={idx}>{ind}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="text-[11px] text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-xl p-3 flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
                  <span>{aiAnalysis.disclaimer}</span>
                </div>
              </div>
            )}

            {/* Human-editable classification & severity controls */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Possible Accident Type
                </label>
                <select
                  value={accidentType}
                  onChange={(e) => setAccidentType(e.target.value as AccidentType)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-medium text-slate-900 dark:text-slate-100"
                >
                  {VALID_ACCIDENT_TYPES.map((typeOpt) => (
                    <option key={typeOpt} value={typeOpt}>
                      {typeOpt}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Estimated Severity (Human Review)
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {VALID_ACCIDENT_SEVERITIES.map((lvl) => {
                    const active = severity === lvl;
                    const activeStyles =
                      lvl === 'Critical'
                        ? 'bg-red-600 text-white border-red-600'
                        : lvl === 'Medium'
                          ? 'bg-orange-500 text-white border-orange-500'
                          : 'bg-emerald-600 text-white border-emerald-600';
                    return (
                      <button
                        key={lvl}
                        type="button"
                        onClick={() => setSeverity(lvl)}
                        className={`py-2 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                          active
                            ? activeStyles
                            : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {lvl}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* RIGHT COLUMN: Automatic Location Detection + Anonymous Confirmation Gate & Submit */}
        <div className="lg:col-span-6 space-y-5">
          {/* Step 3: Automatic Location Detection & Map */}
          <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
                  Step 3 of 4 · Verified Incident Location
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-red-600" />
                  <span>Accident Location & Timestamp</span>
                </h3>
              </div>

              <button
                type="button"
                onClick={detectGpsLocation}
                disabled={gpsStatus === 'detecting'}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-colors cursor-pointer disabled:opacity-60"
              >
                {gpsStatus === 'detecting' ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <MapPin className="w-3.5 h-3.5" />
                )}
                <span>Detect Live GPS</span>
              </button>
            </div>

            {gpsMessage && (
              <div
                className={`text-xs px-3 py-2 rounded-xl border ${
                  gpsStatus === 'acquired'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300'
                    : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                {gpsMessage}
              </div>
            )}

            <AccidentLocationMap
              mode="picker"
              latitude={latitude}
              longitude={longitude}
              onSelectLocation={handleMapLocationChange}
              hospitals={hospitals}
              heightClass="h-60"
            />

            {/* Quick Manual City Zone Buttons */}
            <div className="flex flex-wrap gap-1.5">
              {CITY_QUICK_ZONES.map((z) => (
                <button
                  key={z.label}
                  type="button"
                  onClick={() => {
                    setLatitude(z.lat);
                    setLongitude(z.lng);
                    setLocationSource('manual_map');
                    setLocationLabel(z.label);
                  }}
                  className="text-[11px] font-semibold px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-teal-50 dark:hover:bg-teal-950/60 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
                >
                  {z.label}
                </button>
              ))}
            </div>

            {/* Structured Coordinate, Timestamp & Google Maps Link Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Latitude</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                  {latitude.toFixed(5)}
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Longitude</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                  {longitude.toFixed(5)}
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Date</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                  {clockNow.toISOString().split('T')[0]}
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Time</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums inline-flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  {clockNow.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 items-end">
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Road / Landmark Description
                </label>
                <input
                  type="text"
                  value={locationLabel}
                  onChange={(e) => setLocationLabel(e.target.value)}
                  placeholder="e.g., Near Metro Pillar 42, Main Arterial Road"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 px-3 py-2 text-xs"
                />
              </div>
              <a
                href={googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl border border-teal-200 dark:border-teal-800 bg-teal-50 dark:bg-teal-950/50 text-teal-800 dark:text-teal-300 text-xs font-bold hover:bg-teal-100 transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Google Maps Link</span>
              </a>
            </div>
          </section>

          {/* Step 4: Anonymous Verification Gate & Submit Emergency Report */}
          <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-red-600 dark:text-red-400">
                  Step 4 of 4 · Anonymous Confirmation Gate
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Confirm Incident & Send Anonymous Emergency Alert
                </h3>
              </div>
              <span
                data-testid="anonymous-mode-indicator"
                className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 shrink-0"
              >
                {isCallbackShared ? 'Callback Consented' : 'Identity: Anonymous'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Possible Injured People (if known)
                </label>
                <input
                  type="number"
                  min={0}
                  max={200}
                  value={possibleInjuredCount}
                  onChange={(e) => setPossibleInjuredCount(e.target.value)}
                  placeholder="Leave blank if unknown"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 px-3 py-2 text-xs font-mono"
                />
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-[11px] text-slate-600 dark:text-slate-300 flex items-center gap-2">
                <Lock className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>
                  <strong>Zero Personal Details Required:</strong> Name, phone, email &amp; device ID are not collected.
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Scene Safety Notes (Optional — Do not enter personal names or numbers)
              </label>
              <textarea
                rows={2}
                value={sceneNotes}
                onChange={(e) => setSceneNotes(e.target.value)}
                placeholder="e.g., Traffic blocked in left lane, rider conscious near median..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 px-3 py-2 text-xs"
              />
            </div>

            {/* Strictly Optional Callback Opt-In (Collapsed by Default, Separate Explicit Consent) */}
            <div className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/40 overflow-hidden">
              <button
                type="button"
                aria-expanded={showOptionalCallback}
                data-testid="toggle-optional-callback-btn"
                onClick={() => {
                  const next = !showOptionalCallback;
                  setShowOptionalCallback(next);
                  if (!next) {
                    setOptionalCallbackPhone('');
                    setOptionalCallbackConsented(false);
                  }
                }}
                className="w-full px-3.5 py-2.5 flex items-center justify-between gap-2 text-left text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100/80 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <span>Optional: Provide Emergency Callback Number (Not Required)</span>
                {showOptionalCallback ? (
                  <ChevronUp className="w-4 h-4 shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 shrink-0" />
                )}
              </button>

              {showOptionalCallback && (
                <div className="px-3.5 pb-3.5 pt-2 border-t border-slate-200 dark:border-slate-700 space-y-2.5">
                  <p className="text-[11px] text-amber-800 dark:text-amber-300 leading-relaxed">
                    <strong>Anonymity Notice:</strong> Leave this empty to remain completely anonymous. If you optionally provide a phone number below, it will be encrypted in storage and shared only with authorized emergency responders for follow-up.
                  </p>
                  <input
                    type="tel"
                    value={optionalCallbackPhone}
                    onChange={(e) => setOptionalCallbackPhone(e.target.value)}
                    data-testid="optional-callback-phone-input"
                    placeholder="Optional callback phone (leave blank for full anonymity)"
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs font-mono"
                  />
                  {trimmedCallback && (
                    <label className="flex items-start gap-2.5 text-[11px] text-slate-700 dark:text-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={optionalCallbackConsented}
                        onChange={(e) => setOptionalCallbackConsented(e.target.checked)}
                        data-testid="optional-callback-consent-checkbox"
                        className="mt-0.5 w-4 h-4 accent-teal-600 cursor-pointer shrink-0"
                      />
                      <span>
                        <strong>Explicit Callback Consent:</strong> I voluntarily consent to share this phone number with authorized Hospital, 108 Ambulance, and Police responders for this incident only (this report will not be completely anonymous).
                      </span>
                    </label>
                  )}
                </div>
              )}
            </div>

            {/* Human-in-the-loop Confirmation Gate */}
            <label
              className={`flex items-start gap-3 p-3.5 rounded-xl border-2 cursor-pointer transition-colors ${
                reporterConfirmed
                  ? 'border-red-600 bg-red-50/70 dark:bg-red-950/30'
                  : 'border-slate-200 dark:border-slate-700 bg-slate-50/60 dark:bg-slate-800/40'
              }`}
            >
              <input
                type="checkbox"
                checked={reporterConfirmed}
                onChange={(e) => setReporterConfirmed(e.target.checked)}
                data-testid="confirm-accident-checkbox"
                className="mt-0.5 w-4 h-4 accent-red-600 cursor-pointer shrink-0"
              />
              <span className="text-xs text-slate-800 dark:text-slate-200 leading-relaxed">
                <strong>I confirm this is a real road accident</strong> requiring emergency review and authorize dispatching only the accident photograph (EXIF stripped), verified incident location, and severity estimate to nearby Hospitals, 108 Ambulance Services, and Police.
              </span>
            </label>

            {submitError && (
              <div className="text-xs text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-xl p-3 font-semibold">
                {submitError}
              </div>
            )}

            <button
              type="submit"
              disabled={!canSubmit}
              data-testid="submit-accident-report-btn"
              className="w-full py-3.5 px-5 rounded-xl bg-red-600 hover:bg-red-700 disabled:bg-slate-300 dark:disabled:bg-slate-800 disabled:text-slate-500 text-white font-extrabold text-sm tracking-wide shadow-sm transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Encrypting Photo & Dispatching Anonymous Alert...</span>
                </>
              ) : (
                <>
                  <ShieldAlert className="w-4 h-4" />
                  <span>
                    {isCallbackShared
                      ? 'Submit Emergency Report (Callback Consented)'
                      : 'Submit Anonymous Report'}
                  </span>
                </>
              )}
            </button>
          </section>
        </div>
      </form>
    </div>
  );
};
