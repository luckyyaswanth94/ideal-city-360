import React, { useState } from 'react';
import { VerificationMeta } from '../types';
import { formatRelativeTime } from '../utils/verification';
import { ShieldCheck, Clock, AlertTriangle, XCircle, ExternalLink, History, Info } from 'lucide-react';

interface Props {
  verification: VerificationMeta;
  showDetails?: boolean;
}

export const VerificationBadge: React.FC<Props> = ({ verification, showDetails = true }) => {
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  const status = verification.verificationStatus;

  const getStatusBadge = () => {
    switch (status) {
      case 'Verified':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            Verified
          </span>
        );
      case 'Pending':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
            <Clock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
            Pending Verification
          </span>
        );
      case 'Expired':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700">
            <AlertTriangle className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
            Expired Record
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 dark:bg-rose-950/70 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
            <XCircle className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
            Rejected
          </span>
        );
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
      {getStatusBadge()}

      {verification.isDemoData && (
        <span 
          title="Fictional sample record created for prototype demonstration. Follows real government schemas."
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-blue-50 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800"
        >
          <Info className="w-3 h-3 text-blue-500 dark:text-blue-400" />
          Demo Data
        </span>
      )}

      {showDetails && (
        <>
          <span className="text-slate-400 dark:text-slate-600">•</span>
          <span className="truncate max-w-[220px] text-slate-600 dark:text-slate-400 font-medium" title={verification.sourceName}>
            Source: {verification.sourceName}
          </span>

          {verification.sourceUrl && (
            <a
              href={verification.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center text-teal-700 dark:text-teal-400 hover:text-teal-900 dark:hover:text-teal-300 font-medium underline"
              title="Open Official Source"
            >
              <ExternalLink className="w-3 h-3 ml-0.5" />
            </a>
          )}

          <span className="text-slate-400 dark:text-slate-600">•</span>
          <span className="text-slate-500 dark:text-slate-400 text-[11px]">
            Updated {formatRelativeTime(verification.lastUpdated)}
          </span>

          <button
            type="button"
            onClick={() => setShowHistoryModal(true)}
            className="inline-flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 hover:text-navy-800 dark:hover:text-teal-300 hover:underline cursor-pointer ml-1"
            title="View verification audit trail"
          >
            <History className="w-3 h-3" />
            Audit Trail
          </button>
        </>
      )}

      {/* Audit History Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <h3 className="font-bold text-slate-900 dark:text-white text-base">Information Verification Record</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowHistoryModal(false)}
                className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 p-1 rounded-md text-lg leading-none cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 bg-slate-50 dark:bg-slate-800/80 p-3 rounded-lg border border-slate-200 dark:border-slate-700">
                <div>
                  <span className="text-slate-400 dark:text-slate-500 block font-medium">Status</span>
                  <span className="font-bold text-slate-800 dark:text-slate-100">{verification.verificationStatus}</span>
                </div>
                <div>
                  <span className="text-slate-400 dark:text-slate-500 block font-medium">Verified Officer</span>
                  <span className="font-bold text-slate-800 dark:text-slate-100">{verification.verifiedBy || 'Designated Verifier'}</span>
                </div>
                <div>
                  <span className="text-slate-400 dark:text-slate-500 block font-medium">Created On</span>
                  <span className="text-slate-700 dark:text-slate-300">{new Date(verification.createdDate).toLocaleDateString()}</span>
                </div>
                <div>
                  <span className="text-slate-400 dark:text-slate-500 block font-medium">Last Audited</span>
                  <span className="text-slate-700 dark:text-slate-300">{new Date(verification.lastUpdated).toLocaleString()}</span>
                </div>
                {verification.validUntil && (
                  <div className="col-span-2">
                    <span className="text-slate-400 dark:text-slate-500 block font-medium">Validity Period</span>
                    <span className="text-slate-700 dark:text-slate-300">Valid until {new Date(verification.validUntil).toLocaleDateString()}</span>
                  </div>
                )}
              </div>

              <div>
                <h4 className="font-semibold text-slate-800 dark:text-slate-200 mb-2 flex items-center gap-1.5">
                  <History className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                  Audit & Modification History
                </h4>
                {verification.updateHistory && verification.updateHistory.length > 0 ? (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {verification.updateHistory.map((item, i) => (
                      <div key={i} className="p-2.5 rounded bg-slate-50 dark:bg-slate-800/80 border-l-2 border-teal-500 text-slate-700 dark:text-slate-300">
                        <div className="flex justify-between font-medium">
                          <span className="text-slate-900 dark:text-white font-semibold">{item.action}</span>
                          <span className="text-slate-400 dark:text-slate-500 text-[10px]">{formatRelativeTime(item.timestamp)}</span>
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">By: {item.user}</div>
                        {item.details && <div className="text-[11px] text-slate-600 dark:text-slate-300 mt-1 italic">{item.details}</div>}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-400 dark:text-slate-500 italic">Initial verified baseline entry recorded.</p>
                )}
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setShowHistoryModal(false)}
                className="px-4 py-1.5 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
              >
                Close Audit Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
