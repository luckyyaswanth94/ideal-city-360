import React from 'react';
import { ShieldCheck, Phone, Mail, MapPin, ExternalLink, Heart } from 'lucide-react';

interface Props {
  setActiveTab: (tab: string) => void;
}

export const Footer: React.FC<Props> = ({ setActiveTab }) => {
  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800 text-xs">
      {/* Emergency Strip */}
      <div className="bg-teal-950/80 border-b border-teal-800/40 py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
            <span className="font-bold text-white tracking-wide uppercase text-[11px]">
              24x7 City Emergency Directory:
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-slate-200">
            <span>Ambulance: <strong className="text-white font-mono bg-teal-900/60 px-1.5 py-0.5 rounded">108</strong></span>
            <span>Police Control: <strong className="text-white font-mono bg-teal-900/60 px-1.5 py-0.5 rounded">100 / 112</strong></span>
            <span>Fire & Rescue: <strong className="text-white font-mono bg-teal-900/60 px-1.5 py-0.5 rounded">101</strong></span>
            <span>Women Helpline: <strong className="text-white font-mono bg-teal-900/60 px-1.5 py-0.5 rounded">1091 / 181</strong></span>
            <span>Senior Citizen ElderLine: <strong className="text-white font-mono bg-teal-900/60 px-1.5 py-0.5 rounded">14567</strong></span>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-white border border-slate-700 flex items-center justify-center shadow-sm overflow-hidden shrink-0">
                <img
                  src="/assets/aistudio/ideal_d2f8ccb0.jpeg"
                  alt="IDEAL CITY 360 Logo"
                  data-testid="app-logo-footer"
                  className="w-full h-full object-contain scale-110"
                />
              </div>
              <span className="font-extrabold text-white text-base tracking-tight">IDEAL CITY 360</span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              An AI-powered Smart Citizen Information and Society Management Platform. Dedicated to improving public health, lifestyle, happiness, safety and quality of life by making reliable, updated information accessible to everyone from one centralized platform.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-teal-400 font-semibold">
              <ShieldCheck className="w-4 h-4" /> Strict Information Verification Standard
            </div>
          </div>

          {/* Sectors */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">Public Services</h4>
            <ul className="space-y-2 text-slate-400">
              <li><button type="button" onClick={() => setActiveTab('healthcare')} className="hover:text-white">Smart Healthcare</button></li>
              <li><button type="button" onClick={() => setActiveTab('transport')} className="hover:text-white">Electric Bus Transit</button></li>
              <li><button type="button" onClick={() => setActiveTab('government')} className="hover:text-white">Government Schemes</button></li>
              <li><button type="button" onClick={() => setActiveTab('employment')} className="hover:text-white">Public Jobs & Internships</button></li>
              <li><button type="button" onClick={() => setActiveTab('education')} className="hover:text-white">Education & Libraries</button></li>
              <li><button type="button" onClick={() => setActiveTab('socialWelfare')} className="hover:text-white">Social Welfare Centers</button></li>
            </ul>
          </div>

          {/* Citizen & Admin */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">Citizen Portals</h4>
            <ul className="space-y-2 text-slate-400">
              <li><button type="button" onClick={() => setActiveTab('citizenPortal')} className="hover:text-white">Submit Grievance / Complaint</button></li>
              <li><button type="button" onClick={() => setActiveTab('citizenPortal')} className="hover:text-white">Track Ticket Status</button></li>
              <li><button type="button" onClick={() => setActiveTab('citizenPortal')} className="hover:text-white">Saved Hospitals & Rules</button></li>
              <li><button type="button" onClick={() => setActiveTab('wellbeing')} className="hover:text-white">City Well-Being Index</button></li>
              <li><button type="button" onClick={() => setActiveTab('adminPortal')} className="hover:text-white">Information Audit Cell</button></li>
            </ul>
          </div>

          {/* Official Contact */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">Secretariat Contact</h4>
            <div className="space-y-2 text-slate-400 text-xs">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
                <span>Central Citizen Services Secretariat, Sector 1, Smart City Complex</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                <span>040-2345-0000 (Citizen Helpdesk)</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                <span>support@idealcity360.gov.in</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Disclaimers */}
        <div className="mt-10 pt-6 border-t border-slate-800/80 flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            &copy; 2026 IDEAL CITY 360. All rights reserved. Platform developed under the Smart City Urban Governance Initiative.
          </div>
          <div className="bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-400">
            <strong>Data Disclosure:</strong> Fictional demonstration and verified simulation datasets are clearly labelled as <span className="text-teal-400 font-semibold">[Demo Data]</span>.
          </div>
        </div>

      </div>
    </footer>
  );
};
