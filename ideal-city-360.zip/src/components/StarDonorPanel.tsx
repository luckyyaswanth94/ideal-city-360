import React, { useState } from 'react';
import {
  BloodDonationPledge,
  BloodGroup,
  DonorLeaderboardEntry,
  User
} from '../types';
import {
  buildDonorLeaderboard,
  getCitizenDonationSummary,
  STAR_DONOR_TIERS,
  StarDonorBadgeInfo,
  StarDonorTierId
} from '../utils/starDonor';
import { BLOOD_GROUPS } from '../utils/bloodBank';
import {
  Star,
  Award,
  Trophy,
  Droplet,
  HeartHandshake,
  CheckCircle2,
  Calendar,
  MapPin,
  Sparkles,
  Crown,
  ShieldCheck
} from 'lucide-react';

function getTierStyles(tierId: StarDonorTierId) {
  switch (tierId) {
    case 'platinum':
      return {
        pill: 'bg-indigo-100 dark:bg-indigo-950/80 text-indigo-800 dark:text-indigo-200 border-indigo-300 dark:border-indigo-700',
        banner: 'from-indigo-950 via-slate-900 to-purple-950 border-indigo-500/40',
        iconBg: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/40',
        starColor: 'text-indigo-300 fill-indigo-300',
        bar: 'bg-indigo-500'
      };
    case 'gold':
      return {
        pill: 'bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-200 border-amber-300 dark:border-amber-700',
        banner: 'from-amber-950 via-slate-900 to-rose-950 border-amber-500/40',
        iconBg: 'bg-amber-500/20 text-amber-300 border-amber-400/40',
        starColor: 'text-amber-400 fill-amber-400',
        bar: 'bg-amber-500'
      };
    case 'silver':
      return {
        pill: 'bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border-slate-300 dark:border-slate-600',
        banner: 'from-slate-900 via-slate-800 to-teal-950 border-slate-500/40',
        iconBg: 'bg-slate-400/20 text-slate-200 border-slate-400/40',
        starColor: 'text-slate-300 fill-slate-300',
        bar: 'bg-teal-500'
      };
    case 'bronze':
      return {
        pill: 'bg-orange-100 dark:bg-orange-950/80 text-orange-800 dark:text-orange-200 border-orange-300 dark:border-orange-700',
        banner: 'from-orange-950 via-slate-900 to-slate-950 border-orange-500/40',
        iconBg: 'bg-orange-500/20 text-orange-300 border-orange-400/40',
        starColor: 'text-orange-400 fill-orange-400',
        bar: 'bg-orange-500'
      };
    default:
      return {
        pill: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700',
        banner: 'from-slate-900 via-teal-950 to-slate-900 border-teal-500/30',
        iconBg: 'bg-teal-500/20 text-teal-300 border-teal-400/40',
        starColor: 'text-teal-400',
        bar: 'bg-emerald-500'
      };
  }
}

export const StarDonorBadgePill: React.FC<{ badge: StarDonorBadgeInfo; compact?: boolean }> = ({
  badge,
  compact = false
}) => {
  const styles = getTierStyles(badge.tier.id);
  const starCount = Math.max(1, Math.min(badge.tier.stars, 5));

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-bold ${styles.pill} ${
        compact ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs'
      }`}
    >
      <span className="inline-flex items-center gap-0.5" aria-hidden="true">
        {badge.isStarDonor ? (
          Array.from({ length: compact ? 1 : starCount }).map((_, idx) => (
            <Star key={idx} className={`${compact ? 'w-3 h-3' : 'w-3.5 h-3.5'} fill-current`} />
          ))
        ) : (
          <Droplet className={`${compact ? 'w-3 h-3' : 'w-3.5 h-3.5'}`} />
        )}
      </span>
      <span>{compact ? badge.tier.shortLabel : badge.tier.label}</span>
    </span>
  );
};

interface ProfileCardProps {
  currentUser: User;
  donorLeaderboard: DonorLeaderboardEntry[];
  bloodDonations: BloodDonationPledge[];
  onCompleteDonation: (donationId: string) => void;
  onGoToBloodBank: () => void;
}

export const StarDonorProfileCard: React.FC<ProfileCardProps> = ({
  currentUser,
  donorLeaderboard,
  bloodDonations,
  onCompleteDonation,
  onGoToBloodBank
}) => {
  const summary = getCitizenDonationSummary(currentUser, donorLeaderboard, bloodDonations);
  const styles = getTierStyles(summary.badge.tier.id);

  return (
    <div className="space-y-5">
      {/* Star Donor Hero Banner Card */}
      <div
        className={`bg-gradient-to-br ${styles.banner} text-white rounded-3xl p-6 sm:p-7 border shadow-md space-y-5`}
        data-testid="star-donor-profile-card"
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="flex items-start gap-4">
            <div className={`w-14 h-14 rounded-2xl border flex items-center justify-center shrink-0 ${styles.iconBg}`}>
              <Award className="w-8 h-8" />
            </div>
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/10 border border-white/20 text-[11px] font-bold uppercase tracking-wider text-amber-300">
                  <Sparkles className="w-3 h-3" />
                  Star Donor Recognition
                </span>
                <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-200 border border-rose-400/30">
                  Blood Group: {summary.bloodGroup}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white">
                  {summary.badge.tier.label}
                </h2>
                {summary.badge.isStarDonor && (
                  <div className="flex items-center gap-0.5" aria-label={`${summary.badge.tier.stars} Star Donor rating`}>
                    {Array.from({ length: summary.badge.tier.stars }).map((_, idx) => (
                      <Star key={idx} className={`w-4 h-4 ${styles.starColor}`} />
                    ))}
                  </div>
                )}
              </div>

              <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
                {summary.badge.tier.description}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onGoToBloodBank}
            className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-xs sm:text-sm px-5 py-3 rounded-xl shadow-sm flex items-center justify-center gap-2 transition-colors cursor-pointer shrink-0 self-start lg:self-auto"
          >
            <HeartHandshake className="w-4 h-4" />
            <span>Donate Blood Now</span>
          </button>
        </div>

        {/* Key Gamification Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="bg-white/10 rounded-2xl p-3.5 border border-white/10">
            <span className="text-[11px] text-slate-300 block">Total Donations Made</span>
            <span
              className="text-2xl font-black text-white mt-0.5 block"
              data-testid="citizen-total-donations"
            >
              {summary.totalDonations}
            </span>
            <span className="text-[10px] text-emerald-300 font-semibold">Verified Blood Units</span>
          </div>

          <div className="bg-white/10 rounded-2xl p-3.5 border border-white/10">
            <span className="text-[11px] text-slate-300 block">Estimated Lives Saved</span>
            <span
              className="text-2xl font-black text-rose-300 mt-0.5 block"
              data-testid="citizen-lives-saved"
            >
              {summary.badge.livesImpacted}
            </span>
            <span className="text-[10px] text-slate-300 font-medium">Up to 3 lives per unit</span>
          </div>

          <div className="bg-white/10 rounded-2xl p-3.5 border border-white/10">
            <span className="text-[11px] text-slate-300 block">City Leaderboard Rank</span>
            <span
              className="text-2xl font-black text-amber-300 mt-0.5 block"
              data-testid="citizen-leaderboard-rank"
            >
              {summary.cityRank ? `#${summary.cityRank}` : 'Unranked'}
            </span>
            <span className="text-[10px] text-slate-300 font-medium">
              of {summary.totalRankedDonors} Active Donors
            </span>
          </div>

          <div className="bg-white/10 rounded-2xl p-3.5 border border-white/10">
            <span className="text-[11px] text-slate-300 block">Scheduled Pledges</span>
            <span className="text-2xl font-black text-teal-300 mt-0.5 block">
              {summary.scheduledPledges.length}
            </span>
            <span className="text-[10px] text-slate-300 font-medium">Upcoming appointments</span>
          </div>
        </div>

        {/* Next Tier Progress Bar */}
        <div className="bg-slate-950/50 rounded-2xl p-4 border border-white/10 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="font-bold text-white">
              {summary.badge.tier.nextTierLabel
                ? `Progress to ${summary.badge.tier.nextTierLabel}`
                : 'Maximum Tier Unlocked — Platinum Star Donor!'}
            </span>
            <span className="text-amber-300 font-bold">
              {summary.badge.tier.nextTierLabel
                ? `${summary.badge.donationsToNextTier} more ${summary.badge.donationsToNextTier === 1 ? 'donation' : 'donations'} needed (${summary.badge.progressPercent}%)`
                : '100% Complete'}
            </span>
          </div>
          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${styles.bar}`}
              style={{ width: `${summary.badge.progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Star Donor Badge Milestones */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
          <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Star className="w-4 h-4 text-amber-500 fill-amber-500 shrink-0" />
            <span>Star Donor Badge Milestones</span>
          </h3>
          <span className="text-[11px] text-slate-500 dark:text-slate-400">
            Earn higher tiers through regular verified donations
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {STAR_DONOR_TIERS.filter(t => t.minDonations > 0).map(tier => {
            const unlocked = summary.totalDonations >= tier.minDonations;
            return (
              <div
                key={tier.id}
                className={`p-3.5 rounded-xl border transition-all ${
                  unlocked
                    ? 'bg-amber-50/60 dark:bg-amber-950/30 border-amber-300 dark:border-amber-800'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 opacity-70'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-0.5 text-amber-500">
                    {Array.from({ length: tier.stars }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${unlocked ? 'fill-amber-500 text-amber-500' : 'text-slate-400'}`}
                      />
                    ))}
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      unlocked
                        ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {unlocked ? 'Unlocked' : `${tier.minDonations}+ Donations`}
                  </span>
                </div>
                <div className="font-bold text-slate-900 dark:text-white text-xs">{tier.label}</div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Requires {tier.minDonations}+ verified donations
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* User's Scheduled & Recent Donation Pledges */}
      {(summary.scheduledPledges.length > 0 || summary.completedPledges.length > 0) && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
            <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>Your Recent Blood Donation Appointments</span>
            </h3>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Complete appointments to earn +1 verified donation
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[...summary.scheduledPledges, ...summary.completedPledges].map(pledge => (
              <div
                key={pledge.id}
                className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex flex-col justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs font-bold text-slate-700 dark:text-slate-200">
                      {pledge.pledgeCode}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        pledge.status === 'Completed'
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                          : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                      }`}
                    >
                      {pledge.status}
                    </span>
                  </div>
                  <div className="font-bold text-slate-900 dark:text-white text-xs sm:text-sm">
                    {pledge.preferredBankName}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    {pledge.preferredDate} • {pledge.preferredSlot} • Group {pledge.bloodGroup}
                  </div>
                </div>

                {pledge.status === 'Scheduled' && (
                  <button
                    type="button"
                    onClick={() => onCompleteDonation(pledge.id)}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2 px-3 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Mark Completed (+1 Donation)</span>
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

interface LeaderboardProps {
  donorLeaderboard: DonorLeaderboardEntry[];
  bloodDonations: BloodDonationPledge[];
  currentUser: User;
  compact?: boolean;
}

export const StarDonorLeaderboard: React.FC<LeaderboardProps> = ({
  donorLeaderboard,
  bloodDonations,
  currentUser,
  compact = false
}) => {
  const [zoneFilter, setZoneFilter] = useState<string>('all');
  const [groupFilter, setGroupFilter] = useState<BloodGroup | 'all'>('all');

  const ranked = buildDonorLeaderboard(donorLeaderboard, bloodDonations, currentUser, {
    zone: zoneFilter,
    bloodGroup: groupFilter
  });

  const topThree = ranked.slice(0, 3);

  return (
    <div
      className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5"
      data-testid="star-donor-leaderboard"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
              Ideal City Star Donor Leaderboard
            </h3>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Celebrating verified citizen heroes who regularly donate blood across municipal &amp; Red Cross centers
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <select
            value={zoneFilter}
            onChange={e => setZoneFilter(e.target.value)}
            aria-label="Filter leaderboard by zone"
            className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-slate-700 dark:text-slate-200 text-xs focus:outline-hidden"
          >
            <option value="all">All Zones</option>
            <option value="Central Zone">Central Zone</option>
            <option value="Cyber Zone">Cyber Zone</option>
            <option value="North Zone">North Zone</option>
            <option value="South Zone">South Zone</option>
          </select>

          <select
            value={groupFilter}
            onChange={e => setGroupFilter(e.target.value as BloodGroup | 'all')}
            aria-label="Filter leaderboard by blood group"
            className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-slate-700 dark:text-slate-200 text-xs focus:outline-hidden"
          >
            <option value="all">All Blood Groups</option>
            {BLOOD_GROUPS.map(g => (
              <option key={g} value={g}>{g}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Top 3 Podium Cards */}
      {!compact && topThree.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {topThree.map(entry => (
            <div
              key={entry.id}
              className={`rounded-2xl p-4 border flex flex-col justify-between gap-3 ${
                entry.rank === 1
                  ? 'bg-gradient-to-br from-amber-50 to-orange-50/70 dark:from-amber-950/50 dark:to-slate-900 border-amber-300 dark:border-amber-700'
                  : entry.rank === 2
                  ? 'bg-gradient-to-br from-slate-50 to-slate-100/70 dark:from-slate-800/80 dark:to-slate-900 border-slate-300 dark:border-slate-700'
                  : 'bg-gradient-to-br from-orange-50/60 to-rose-50/40 dark:from-orange-950/30 dark:to-slate-900 border-orange-200 dark:border-orange-800/70'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-sm shrink-0 ${
                      entry.rank === 1
                        ? 'bg-amber-500 text-white'
                        : entry.rank === 2
                        ? 'bg-slate-500 text-white'
                        : 'bg-orange-500 text-white'
                    }`}
                  >
                    {entry.rank === 1 ? <Crown className="w-5 h-5" /> : `#${entry.rank}`}
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
                      <span>{entry.name}</span>
                      {entry.isCurrentUser && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-teal-600 text-white">You</span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> {entry.zone}
                    </div>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-lg bg-rose-600 text-white text-xs font-black shrink-0">
                  {entry.bloodGroup}
                </span>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-200/70 dark:border-slate-700/70">
                <StarDonorBadgePill badge={entry.badge} compact />
                <div className="text-right">
                  <div className="text-base font-black text-slate-900 dark:text-white leading-none">
                    {entry.totalDonations} Donations
                  </div>
                  <div className="text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold mt-0.5">
                    {entry.badge.livesImpacted} Lives Saved
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Full Ranked List */}
      {ranked.length === 0 ? (
        <div className="text-center py-8 text-xs text-slate-500 dark:text-slate-400">
          No verified Star Donors match the selected zone and blood group filters.
        </div>
      ) : (
        <div className="space-y-2">
          {ranked.map(entry => (
            <div
              key={entry.id}
              data-testid={entry.isCurrentUser ? 'leaderboard-current-user-row' : undefined}
              className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                entry.isCurrentUser
                  ? 'bg-teal-50/80 dark:bg-teal-950/50 border-teal-400 dark:border-teal-600 ring-1 ring-teal-500/20'
                  : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-black shrink-0 ${
                    entry.rank === 1
                      ? 'bg-amber-500 text-white'
                      : entry.rank === 2
                      ? 'bg-slate-500 text-white'
                      : entry.rank === 3
                      ? 'bg-orange-500 text-white'
                      : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  #{entry.rank}
                </div>

                <div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="font-bold text-slate-900 dark:text-white text-sm">{entry.name}</span>
                    {entry.isCurrentUser && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-600 text-white">
                        You
                      </span>
                    )}
                    {entry.verified && (
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" aria-label="Verified Donor" />
                    )}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-2 mt-0.5">
                    <span>{entry.zone}</span>
                    <span>•</span>
                    <span>Last donated: {entry.lastDonationDate}</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between sm:justify-end gap-2.5">
                <span className="px-2 py-0.5 rounded-md bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 text-xs font-black border border-rose-200 dark:border-rose-800">
                  {entry.bloodGroup}
                </span>
                <StarDonorBadgePill badge={entry.badge} compact />
                <div className="text-right min-w-[92px]">
                  <div className="font-extrabold text-slate-900 dark:text-white text-sm">
                    {entry.totalDonations} {entry.totalDonations === 1 ? 'Donation' : 'Donations'}
                  </div>
                  <div className="text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold">
                    {entry.badge.livesImpacted} lives saved
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
