import React, { useState, useEffect } from 'react';
import { APIProvider, Map, AdvancedMarker, Pin, InfoWindow } from '@vis.gl/react-google-maps';
import { Hospital, BusRoute } from '../types.ts';
import { 
  Building2, 
  Bus, 
  MapPin, 
  ExternalLink, 
  Navigation, 
  Sparkles, 
  Search, 
  AlertCircle,
  Phone,
  Bed,
  CheckCircle2,
  Compass
} from 'lucide-react';

interface GroundedPlace {
  title: string;
  uri: string;
  placeId: string;
  address: string;
  snippets?: string[];
  lat?: number;
  lng?: number;
}

interface Props {
  hospitals: Hospital[];
  routes: BusRoute[];
  selectedCategory?: 'all' | 'hospitals' | 'buses' | 'emergency';
}

export const InteractiveCityMap: React.FC<Props> = ({ 
  hospitals, 
  routes, 
  selectedCategory = 'all' 
}) => {
  const [apiKey, setApiKey] = useState<string>(import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '');
  const [filter, setFilter] = useState<'all' | 'hospitals' | 'buses' | 'emergency'>(selectedCategory);
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);
  const [selectedRouteStop, setSelectedRouteStop] = useState<{
    route: BusRoute;
    stop: { id: string; name: string; lat: number; lng: number; order: number };
  } | null>(null);
  const [selectedGroundedPlace, setSelectedGroundedPlace] = useState<GroundedPlace | null>(null);

  // Search facilities via Gemini with Google Maps Grounding
  const [searchFacilityQuery, setSearchFacilityQuery] = useState('');
  const [isSearchingFacilities, setIsSearchingFacilities] = useState(false);
  const [groundedPlaces, setGroundedPlaces] = useState<GroundedPlace[]>([]);
  const [groundingSummary, setGroundingSummary] = useState<string>('');

  // Center of Ideal City (Hyderabad metro area: 17.4150, 78.4600)
  const defaultCenter = { lat: 17.4150, lng: 78.4600 };

  // Fetch API key from backend if not directly available in client env
  useEffect(() => {
    if (!apiKey) {
      fetch('/api/maps/config')
        .then(res => res.json())
        .then(data => {
          if (data?.apiKey) {
            setApiKey(data.apiKey);
          }
        })
        .catch(() => {});
    }
  }, [apiKey]);

  const handleSearchGrounding = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchFacilityQuery.trim()) return;

    setIsSearchingFacilities(true);
    setGroundingSummary('');
    try {
      const res = await fetch('/api/maps/grounded-facilities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: searchFacilityQuery,
          lat: defaultCenter.lat,
          lng: defaultCenter.lng
        })
      });
      const data = await res.json();
      if (data?.places) {
        setGroundedPlaces(data.places);
        setGroundingSummary(data.summary || '');
      }
    } catch (err) {
      console.warn('Grounding search failed:', err);
    } finally {
      setIsSearchingFacilities(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden">
      {/* Map Control Toolbar */}
      <div className="p-4 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">
              Google Maps Smart Infrastructure Map
            </h3>
            <span className="text-[10px] bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 px-2 py-0.5 rounded-full font-semibold border border-blue-200 dark:border-blue-800">
              Google Maps Platform
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Verified geo-spatial view with Google Maps Advanced Markers, live transit nodes & Maps Grounding
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 p-1 rounded-lg border border-slate-200 dark:border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => { setFilter('all'); setSelectedHospital(null); setSelectedRouteStop(null); }}
            className={`px-3 py-1 rounded-md font-medium transition-colors ${
              filter === 'all' 
                ? 'bg-slate-900 dark:bg-emerald-600 text-white shadow-xs' 
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            All Infrastructure
          </button>
          <button
            type="button"
            onClick={() => { setFilter('hospitals'); setSelectedHospital(null); setSelectedRouteStop(null); }}
            className={`px-3 py-1 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
              filter === 'hospitals' 
                ? 'bg-emerald-600 text-white shadow-xs' 
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            Hospitals ({hospitals.length})
          </button>
          <button
            type="button"
            onClick={() => { setFilter('buses'); setSelectedHospital(null); setSelectedRouteStop(null); }}
            className={`px-3 py-1 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
              filter === 'buses' 
                ? 'bg-sky-600 text-white shadow-xs' 
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Bus className="w-3.5 h-3.5" />
            Smart Transit Routes ({routes.length})
          </button>
        </div>
      </div>

      {/* Real-time Maps Grounding Facility Search Bar */}
      <div className="px-4 py-3 bg-blue-50/70 dark:bg-slate-900/90 border-b border-blue-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <form onSubmit={handleSearchGrounding} className="flex-1 flex items-center gap-2 max-w-xl">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchFacilityQuery}
              onChange={(e) => setSearchFacilityQuery(e.target.value)}
              placeholder="Search facilities via Gemini Google Maps Grounding (e.g. 24h trauma center, pharmacy)..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <button
            type="submit"
            disabled={isSearchingFacilities}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            {isSearchingFacilities ? 'Grounding...' : 'Maps Grounding Search'}
          </button>
        </form>

        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <Compass className="w-3.5 h-3.5 text-emerald-600" />
          <span>Coordinates: 17.4150° N, 78.4600° E (Central Cyber Corridor)</span>
        </div>
      </div>

      {/* Grounded Places Result Chips */}
      {groundedPlaces.length > 0 && (
        <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/20 border-b border-emerald-100 dark:border-emerald-900/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              Verified Google Maps Grounding Results ({groundedPlaces.length} places found):
            </span>
            <button 
              type="button" 
              onClick={() => setGroundedPlaces([])}
              className="text-[11px] text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
            >
              Clear
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {groundedPlaces.map((place, idx) => (
              <a
                key={idx}
                href={place.uri}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-white dark:bg-slate-800 rounded-lg border border-emerald-200 dark:border-emerald-800/60 shadow-xs hover:border-emerald-500 transition-all text-xs group"
              >
                <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span className="font-semibold text-slate-800 dark:text-slate-200 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                  {place.title}
                </span>
                {place.address && (
                  <span className="text-[10px] text-slate-400 truncate max-w-[140px]">
                    • {place.address}
                  </span>
                )}
                <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-emerald-600 shrink-0 ml-1" />
              </a>
            ))}
          </div>
        </div>
      )}

      {/* Google Maps Container or Placeholder if Disabled */}
      <div className="relative w-full h-[520px] bg-slate-100 dark:bg-slate-950">
        {!apiKey ? (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-slate-900 text-white">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center mb-4 shadow-lg">
              <Compass className="w-7 h-7" />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-950/80 px-2.5 py-1 rounded-full border border-amber-800 mb-2">
              Google Maps Offline Placeholder
            </span>
            <h3 className="text-lg font-bold text-white mb-2">Google Maps Platform is not configured or disabled</h3>
            <p className="text-xs text-slate-300 max-w-md mb-6 leading-relaxed">
              Google Maps Platform API key is currently unavailable or disabled. Use the Leaflet OpenStreetMap visual overlay in the Bus Routes section for live path rendering and station tracking.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg w-full text-left text-xs">
              <div className="p-3 bg-slate-800 rounded-xl border border-slate-700">
                <span className="font-bold text-emerald-400 block mb-1">Hospitals & Trauma Centers ({hospitals.length})</span>
                <span className="text-slate-300 text-[11px] block">Central Super-Specialty, Apollo, KIMS Sunshine</span>
              </div>
              <div className="p-3 bg-slate-800 rounded-xl border border-slate-700">
                <span className="font-bold text-sky-400 block mb-1">Transit Nodes ({routes.length})</span>
                <span className="text-slate-300 text-[11px] block">Secunderabad, Charminar, Cyber Towers</span>
              </div>
            </div>
          </div>
        ) : (
          <APIProvider apiKey={apiKey}>
            <Map
              style={{ width: '100%', height: '100%' }}
              defaultCenter={defaultCenter}
              defaultZoom={12}
              mapId="DEMO_MAP_ID"
              internalUsageAttributionIds={["gmp_mcp_codeassist_v1_aistudio"]}
              gestureHandling="greedy"
              disableDefaultUI={false}
            >
              {/* 1. Hospital Advanced Markers */}
              {(filter === 'all' || filter === 'hospitals') && hospitals.map(hosp => (
              <AdvancedMarker
                key={hosp.id}
                position={{ lat: hosp.location.lat, lng: hosp.location.lng }}
                onClick={() => {
                  setSelectedHospital(hosp);
                  setSelectedRouteStop(null);
                }}
                title={hosp.name}
              >
                <Pin 
                  background="#059669" 
                  borderColor="#064e3b" 
                  glyphColor="#ffffff" 
                  scale={1.15}
                />
              </AdvancedMarker>
            ))}

            {/* 2. Transit Route Stop Advanced Markers */}
            {(filter === 'all' || filter === 'buses') && routes.map(route => 
              route.stops.map(stop => (
                <AdvancedMarker
                  key={`${route.id}-${stop.id}`}
                  position={{ lat: stop.lat, lng: stop.lng }}
                  onClick={() => {
                    setSelectedRouteStop({ route, stop });
                    setSelectedHospital(null);
                  }}
                  title={`Route ${route.routeNumber}: ${stop.name}`}
                >
                  <Pin 
                    background="#0284c7" 
                    borderColor="#0369a1" 
                    glyphColor="#ffffff" 
                    scale={0.9}
                  />
                </AdvancedMarker>
              ))
            )}

            {/* Hospital InfoWindow */}
            {selectedHospital && (
              <InfoWindow
                position={{ lat: selectedHospital.location.lat, lng: selectedHospital.location.lng }}
                onCloseClick={() => setSelectedHospital(null)}
              >
                <div className="p-1 min-w-[240px] max-w-[280px] text-slate-900">
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-700 uppercase tracking-wider">
                    <Building2 className="w-3 h-3" />
                    {selectedHospital.type}
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 mt-1 leading-snug">
                    {selectedHospital.name}
                  </h4>
                  <p className="text-xs text-slate-600 mt-1 flex items-start gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                    <span>{selectedHospital.address}</span>
                  </p>

                  <div className="my-2 p-2 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                    <div className="flex items-center justify-between font-medium text-slate-700">
                      <span className="flex items-center gap-1">
                        <Bed className="w-3.5 h-3.5 text-emerald-600" />
                        Available Beds:
                      </span>
                      <strong className="text-emerald-700">
                        {selectedHospital.bedCount.available} / {selectedHospital.bedCount.total}
                      </strong>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
                      <span>ICU Beds:</span>
                      <span className="font-semibold text-slate-700">{selectedHospital.bedCount.icu}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100">
                    <a
                      href={`tel:${selectedHospital.emergencyPhone}`}
                      className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1"
                    >
                      <Phone className="w-3 h-3" />
                      {selectedHospital.emergencyPhone}
                    </a>
                    <a
                      href={`https://www.google.com/maps/dir/?api=1&destination=${selectedHospital.location.lat},${selectedHospital.location.lng}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-2.5 py-1 rounded-md flex items-center gap-1 transition-colors"
                    >
                      <Navigation className="w-3 h-3" />
                      Navigate
                    </a>
                  </div>
                </div>
              </InfoWindow>
            )}

            {/* Bus Stop InfoWindow */}
            {selectedRouteStop && (
              <InfoWindow
                position={{ lat: selectedRouteStop.stop.lat, lng: selectedRouteStop.stop.lng }}
                onCloseClick={() => setSelectedRouteStop(null)}
              >
                <div className="p-1 min-w-[220px] text-slate-900">
                  <span className="text-[10px] bg-sky-100 text-sky-800 font-bold px-2 py-0.5 rounded-full">
                    Route {selectedRouteStop.route.routeNumber}
                  </span>
                  <h4 className="font-bold text-sm text-slate-900 mt-1.5">
                    {selectedRouteStop.stop.name}
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Stop #{selectedRouteStop.stop.order} on {selectedRouteStop.route.name}
                  </p>
                  <div className="mt-2 text-xs text-slate-600 space-y-1 bg-slate-50 p-2 rounded border border-slate-200">
                    <div><strong>Type:</strong> {selectedRouteStop.route.type}</div>
                    <div><strong>Frequency:</strong> Every {selectedRouteStop.route.frequencyMinutes} mins</div>
                    <div><strong>Hours:</strong> {selectedRouteStop.route.firstBus} - {selectedRouteStop.route.lastBus}</div>
                  </div>
                  <a
                    href={`https://www.google.com/maps/dir/?api=1&destination=${selectedRouteStop.stop.lat},${selectedRouteStop.stop.lng}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2.5 text-xs text-sky-600 hover:text-sky-700 font-semibold flex items-center gap-1"
                  >
                    <Navigation className="w-3 h-3" />
                    Open Stop in Google Maps
                  </a>
                </div>
              </InfoWindow>
            )}
          </Map>
        </APIProvider>
        )}

        {/* Floating Quick Legend */}
        <div className="absolute bottom-4 left-4 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-md text-xs space-y-2 z-10 pointer-events-auto">
          <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-emerald-600" />
            Infrastructure Legend
          </div>
          <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
            <span className="w-3 h-3 rounded-full bg-emerald-600 border border-white"></span>
            <span>Tertiary Hospital (Green Pin)</span>
          </div>
          <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
            <span className="w-3 h-3 rounded-full bg-sky-600 border border-white"></span>
            <span>Transit Bus Stop (Blue Pin)</span>
          </div>
          <div className="pt-1 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400">
            Powered by Google Maps Platform & Gemini Grounding
          </div>
        </div>
      </div>
    </div>
  );
};
