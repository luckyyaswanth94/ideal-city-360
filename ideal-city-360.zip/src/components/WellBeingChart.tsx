import React, { useState } from 'react';
import { CityWellBeingMetric } from '../types';
import { calculateCityWellBeingIndex } from '../utils/verification';
import { TrendingUp, ShieldCheck, Heart, Sparkles, Award, ArrowUpRight, Info } from 'lucide-react';

interface Props {
  metrics: CityWellBeingMetric[];
}

export const WellBeingChart: React.FC<Props> = ({ metrics }) => {
  const summary = calculateCityWellBeingIndex(metrics);
  const [hoveredBarIndex, setHoveredBarIndex] = useState<number | null>(null);
  const [hoveredTrendMonth, setHoveredTrendMonth] = useState<string | null>(null);

  // Bar Chart Dimensions
  const chartHeight = 220;
  const chartWidth = 500;
  const barWidth = 36;
  const gap = 46;

  // 6 Months trajectory points for Area Chart
  const months = ['Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'];
  const avgScoresByMonth = months.map(m => {
    const scores = metrics.map(metric => {
      const found = metric.historicalData.find(h => h.month === m);
      return found ? found.value : metric.score;
    });
    const avg = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
    return { month: m, avg };
  });

  // Calculate SVG coordinates for trend line
  const minVal = 70;
  const maxVal = 100;
  const trendSvgPoints = avgScoresByMonth.map((pt, i) => {
    const x = 40 + i * ((chartWidth - 80) / (months.length - 1));
    const y = chartHeight - 30 - ((pt.avg - minVal) / (maxVal - minVal)) * (chartHeight - 60);
    return { ...pt, x, y };
  });

  const pathD = trendSvgPoints.reduce((acc, curr, i) => {
    return i === 0 ? `M ${curr.x} ${curr.y}` : `${acc} L ${curr.x} ${curr.y}`;
  }, '');

  const areaD = `${pathD} L ${trendSvgPoints[trendSvgPoints.length - 1].x} ${chartHeight - 30} L ${trendSvgPoints[0].x} ${chartHeight - 30} Z`;

  return (
    <div className="space-y-6">
      
      {/* Top Banner Notice */}
      <div className="bg-gradient-to-r from-navy-900 via-slate-900 to-navy-950 text-white rounded-3xl p-6 sm:p-8 shadow-md relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-teal-500/20 text-teal-300 border border-teal-500/30">
                Live City Index
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Demo / Simulation Data
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              City Well-Being & Quality of Life Index
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
              Composite urban intelligence monitoring healthcare access, transit punctuality, clean air, public safety, and citizen happiness.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md border border-white/20 p-5 rounded-2xl flex items-center gap-5 min-w-[240px]">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-300 font-black text-2xl shadow-inner">
              {summary.overallScore}%
            </div>
            <div>
              <div className="text-xs text-slate-300 uppercase tracking-wider font-semibold">City Performance</div>
              <div className="text-xl font-bold text-white flex items-center gap-1.5">
                Grade {summary.grade}
                <Award className="w-5 h-5 text-amber-400" />
              </div>
              <div className="text-[11px] text-emerald-400 mt-0.5 flex items-center gap-1 font-semibold">
                <TrendingUp className="w-3.5 h-3.5" /> +4.2% YoY Improvement
              </div>
            </div>
          </div>
        </div>

        {/* Quick Highlights Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-white/10">
          <div className="bg-white/5 rounded-xl p-3 border border-white/5">
            <span className="text-xs text-slate-400 block">Monitored Domains</span>
            <span className="text-lg font-bold text-white">{summary.totalMonitored} Core Sectors</span>
          </div>
          <div className="bg-white/5 rounded-xl p-3 border border-white/5">
            <span className="text-xs text-emerald-400 block">Excellent Standing</span>
            <span className="text-lg font-bold text-white">{summary.statusSummary.excellent} Sectors</span>
          </div>
          <div className="bg-white/5 rounded-xl p-3 border border-white/5">
            <span className="text-xs text-sky-400 block">Good Standing</span>
            <span className="text-lg font-bold text-white">{summary.statusSummary.good} Sectors</span>
          </div>
          <div className="bg-white/5 rounded-xl p-3 border border-white/5">
            <span className="text-xs text-amber-400 block">Target Threshold</span>
            <span className="text-lg font-bold text-white">95% Benchmark</span>
          </div>
        </div>
      </div>

      {/* Visual Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Chart 1: Sector Performance vs Target */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">Sector Performance vs Municipal Target</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Benchmark comparison of domain ratings against 2026 masterplan targets</p>
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-teal-600 inline-block"></span> Score</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-slate-200 dark:bg-slate-700 inline-block"></span> Target</span>
            </div>
          </div>

          <div className="relative w-full overflow-x-auto">
            <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-56 font-sans">
              {/* Background grid lines */}
              {[25, 50, 75, 100].map(val => {
                const y = chartHeight - 30 - (val / 100) * (chartHeight - 60);
                return (
                  <g key={val}>
                    <line x1="30" y1={y} x2={chartWidth - 10} y2={y} stroke="currentColor" className="text-slate-100 dark:text-slate-800" strokeDasharray="3 3" />
                    <text x="24" y={y + 3} textAnchor="end" fontSize="10" fill="#94a3b8">{val}%</text>
                  </g>
                );
              })}

              {/* Bars */}
              {metrics.map((m, idx) => {
                const x = 45 + idx * (chartWidth - 60) / metrics.length;
                const scoreH = (m.score / 100) * (chartHeight - 60);
                const targetH = (m.target / 100) * (chartHeight - 60);
                const isHovered = hoveredBarIndex === idx;

                return (
                  <g 
                    key={m.id} 
                    onMouseEnter={() => setHoveredBarIndex(idx)}
                    onMouseLeave={() => setHoveredBarIndex(null)}
                    className="cursor-pointer transition-opacity"
                  >
                    {/* Target Bar (background) */}
                    <rect
                      x={x + 16}
                      y={chartHeight - 30 - targetH}
                      width={12}
                      height={targetH}
                      fill="currentColor"
                      className="text-slate-200 dark:text-slate-700"
                      rx="3"
                    />

                    {/* Score Bar (foreground) */}
                    <rect
                      x={x}
                      y={chartHeight - 30 - scoreH}
                      width={14}
                      height={scoreH}
                      fill={isHovered ? '#0f766e' : '#0d9488'}
                      rx="3"
                    />

                    {/* Label below bar */}
                    <text
                      x={x + 14}
                      y={chartHeight - 12}
                      textAnchor="middle"
                      fontSize="9"
                      fontWeight="bold"
                      fill="#64748b"
                    >
                      {m.category.split(' ')[0]}
                    </text>

                    {/* Tooltip on hover */}
                    {isHovered && (
                      <g>
                        <rect
                          x={x - 20}
                          y={chartHeight - 30 - scoreH - 30}
                          width="72"
                          height="22"
                          rx="4"
                          fill="#0f172a"
                        />
                        <text
                          x={x + 16}
                          y={chartHeight - 30 - scoreH - 16}
                          textAnchor="middle"
                          fontSize="10"
                          fontWeight="bold"
                          fill="#ffffff"
                        >
                          {m.score}% (T: {m.target}%)
                        </text>
                      </g>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Chart 2: 6-Month Indicator Trajectory */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">6-Month Urban Trajectory</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Continuous aggregate index across health, safety, transit & environment</p>
            </div>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 flex items-center gap-1">
              <TrendingUp className="w-3 h-3 text-emerald-600 dark:text-emerald-400" /> +6 pts Growth
            </span>
          </div>

          <div className="relative w-full overflow-x-auto">
            <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-56 font-sans">
              <defs>
                <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#0d9488" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="#0d9488" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Grid lines */}
              {[70, 80, 90, 100].map(val => {
                const y = chartHeight - 30 - ((val - minVal) / (maxVal - minVal)) * (chartHeight - 60);
                return (
                  <g key={val}>
                    <line x1="30" y1={y} x2={chartWidth - 10} y2={y} stroke="currentColor" className="text-slate-100 dark:text-slate-800" strokeDasharray="3 3" />
                    <text x="24" y={y + 3} textAnchor="end" fontSize="10" fill="#94a3b8">{val}%</text>
                  </g>
                );
              })}

              {/* Shaded Area */}
              <path d={areaD} fill="url(#areaGradient)" />

              {/* Smooth Line */}
              <path d={pathD} fill="none" stroke="#0d9488" strokeWidth="3" />

              {/* Points */}
              {trendSvgPoints.map(pt => {
                const isHovered = hoveredTrendMonth === pt.month;
                return (
                  <g 
                    key={pt.month}
                    onMouseEnter={() => setHoveredTrendMonth(pt.month)}
                    onMouseLeave={() => setHoveredTrendMonth(null)}
                    className="cursor-pointer"
                  >
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r={isHovered ? 6 : 4}
                      fill="#0d9488"
                      stroke="#ffffff"
                      strokeWidth="2"
                    />
                    <text
                      x={pt.x}
                      y={chartHeight - 12}
                      textAnchor="middle"
                      fontSize="10"
                      fill="#64748b"
                      fontWeight="600"
                    >
                      {pt.month}
                    </text>

                    {isHovered && (
                      <g>
                        <rect
                          x={pt.x - 24}
                          y={pt.y - 28}
                          width="48"
                          height="20"
                          rx="4"
                          fill="#0f172a"
                        />
                        <text
                          x={pt.x}
                          y={pt.y - 15}
                          textAnchor="middle"
                          fontSize="10"
                          fontWeight="bold"
                          fill="#ffffff"
                        >
                          {pt.avg}%
                        </text>
                      </g>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

      </div>

      {/* Domain Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {metrics.map(metric => (
          <div 
            key={metric.id}
            className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs hover:border-teal-500 dark:hover:border-teal-500 transition-all flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">{metric.category}</span>
                <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                  metric.status === 'Excellent' 
                    ? 'bg-emerald-50 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800' 
                    : 'bg-sky-50 dark:bg-sky-950/70 text-sky-800 dark:text-sky-300 border border-sky-200 dark:border-sky-800'
                }`}>
                  {metric.status}
                </span>
              </div>

              <h4 className="font-bold text-slate-900 dark:text-white text-sm">{metric.name}</h4>

              {/* Progress Bar */}
              <div className="space-y-1 my-3">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-700 dark:text-slate-300">Index Score: {metric.score}%</span>
                  <span className="text-slate-400 dark:text-slate-500">Target: {metric.target}%</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2.5 overflow-hidden">
                  <div 
                    className="bg-teal-600 h-2.5 rounded-full transition-all duration-500"
                    style={{ width: `${metric.score}%` }}
                  />
                </div>
              </div>

              {/* Key Highlights */}
              <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                {metric.keyHighlights.map((hl, i) => (
                  <div key={i} className="flex items-start gap-1.5">
                    <span className="text-teal-600 dark:text-teal-400 font-bold">•</span>
                    <span>{hl}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-medium">6-Month Trajectory:</span>
              <span className="font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" /> +{metric.score - (metric.historicalData[0]?.value || metric.score)}% since Jun
              </span>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
