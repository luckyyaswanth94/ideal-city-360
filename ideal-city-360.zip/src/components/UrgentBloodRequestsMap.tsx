import React, { useEffect, useMemo, useRef, useState } from 'react';
import L from 'leaflet';
import type { BloodBank, BloodGroup, BloodRequest, Hospital, User } from '../types';
import {
  DEFAULT_USER_LOCATION,
  GeoReferencePoint,
  UrgencyMapFilter,
  UrgentBloodRequestPin,
  ZONE_REFERENCE_POINTS,
  getActiveUrgentBloodRequestPins
} from '../utils/urgentBloodMap';
import {
  AlertTriangle,
  Crosshair,
  Droplet,
  ExternalLink,
  HeartHandshake,
  MapPin,
  Navigation,
  Phone,
  RotateCcw,
  ShieldCheck
} from 'lucide-react';

interface Props {
  bloodRequests: BloodRequest[];
  bloodBanks: BloodBank[];
  hospitals: Hospital[];
  currentUser: User;
  selectedGroup: BloodGroup | 'all';
  selectedZone: string;
  onDonateForRequest: (request: BloodRequest, resolvedBankId?: string) => void;
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export const UrgentBloodRequestsMap: React.FC<Props> = ({
  bloodRequests,
  bloodBanks,
  hospitals,
  currentUser,
  selectedGroup,
  selectedZone,
  onDonateForRequest
}) => {
  const [urgencyFilter, setUrgencyFilter] = useState<UrgencyMapFilter>('all_urgent');
  const [compatibleOnly, setCompatibleOnly] = useState<boolean>(false);
  const [showBloodBanks, setShowBloodBanks] = useState<boolean>(true);
  const [selectedRequestId, setSelectedRequestId] = useState<string | null>(null);
  const [referenceLocation, setReferenceLocation] = useState<GeoReferencePoint>(() => {
    if (currentUser.zone && ZONE_REFERENCE_POINTS[currentUser.zone]) {
      return ZONE_REFERENCE_POINTS[currentUser.zone];
    }
    return DEFAULT_USER_LOCATION;
  });
  const [geoStatus, setGeoStatus] = useState<string | null>(null);

  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const requestMarkersRef = useRef<Record<string, L.Marker>>({});

  const urgentPins = useMemo(
    () =>
      getActiveUrgentBloodRequestPins(bloodRequests, bloodBanks, hospitals, {
        urgencyFilter,
        bloodGroup: selectedGroup,
        zone: selectedZone,
        referenceLocation,
        donorBloodGroup: currentUser.bloodGroup,
        compatibleOnly
      }),
    [
      bloodRequests,
      bloodBanks,
      hospitals,
      urgencyFilter,
      selectedGroup,
      selectedZone,
      referenceLocation,
      currentUser.bloodGroup,
      compatibleOnly
    ]
  );

  const allUrgentCount = useMemo(
    () =>
      getActiveUrgentBloodRequestPins(bloodRequests, bloodBanks, hospitals, {
        urgencyFilter: 'all_urgent',
        bloodGroup: selectedGroup,
        zone: selectedZone,
        referenceLocation,
        donorBloodGroup: currentUser.bloodGroup,
        compatibleOnly
      }).length,
    [
      bloodRequests,
      bloodBanks,
      hospitals,
      selectedGroup,
      selectedZone,
      referenceLocation,
      currentUser.bloodGroup,
      compatibleOnly
    ]
  );

  // Initialize Leaflet map once
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: [referenceLocation.lat, referenceLocation.lng],
      zoom: 12,
      zoomControl: true,
      scrollWheelZoom: false
    });

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19
    }).addTo(map);

    markersLayerRef.current = L.layerGroup().addTo(map);
    mapInstanceRef.current = map;

    // Ensure accurate sizing once container finishes layout
    const timer = window.setTimeout(() => {
      map.invalidateSize();
    }, 150);

    return () => {
      window.clearTimeout(timer);
      map.remove();
      mapInstanceRef.current = null;
      markersLayerRef.current = null;
    };
  }, []);

  // Re-render markers whenever urgentPins, referenceLocation, or bank overlay changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    const layerGroup = markersLayerRef.current;
    if (!map || !layerGroup) return;

    layerGroup.clearLayers();
    requestMarkersRef.current = {};

    const boundsCoords: [number, number][] = [];

    // 1. Reference / Donor Location Pin
    const refIcon = L.divIcon({
      className: 'user-loc-pin-icon',
      html: `
        <div class="relative flex flex-col items-center" style="transform: translate(-50%, -50%);">
          <div class="w-4 h-4 rounded-full bg-sky-600 border-2 border-white shadow-md ring-4 ring-sky-400/35"></div>
          <div class="mt-1 bg-sky-900/90 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-xs whitespace-nowrap">
            ${escapeHtml(referenceLocation.label)}
          </div>
        </div>
      `,
      iconSize: [24, 24],
      iconAnchor: [12, 12]
    });

    L.marker([referenceLocation.lat, referenceLocation.lng], {
      icon: refIcon,
      zIndexOffset: 200
    })
      .bindPopup(
        `<div style="font-family: inherit; padding: 2px;">
          <div style="font-size: 10px; font-weight: 800; color: #0284c7; text-transform: uppercase;">Reference Location</div>
          <div style="font-size: 12px; font-weight: 700; color: #0f172a; margin-top: 2px;">${escapeHtml(referenceLocation.label)}</div>
          <div style="font-size: 10px; color: #64748b; margin-top: 2px;">Distances to nearby urgent blood requests are calculated from here.</div>
        </div>`
      )
      .addTo(layerGroup);
    boundsCoords.push([referenceLocation.lat, referenceLocation.lng]);

    // 2. Optional Blood Bank Center Context Pins
    if (showBloodBanks) {
      bloodBanks.forEach(bank => {
        if (typeof bank.lat !== 'number' || typeof bank.lng !== 'number') return;
        const bankIcon = L.divIcon({
          className: 'blood-bank-pin-icon',
          html: `
            <div class="flex items-center justify-center" style="transform: translate(-50%, -50%);">
              <div class="w-6 h-6 rounded-lg bg-teal-700/90 text-white border-2 border-white shadow-sm flex items-center justify-center text-[10px] font-black" title="${escapeHtml(bank.name)}">
                +
              </div>
            </div>
          `,
          iconSize: [24, 24],
          iconAnchor: [12, 12]
        });

        L.marker([bank.lat, bank.lng], { icon: bankIcon, zIndexOffset: 100 })
          .bindPopup(
            `<div style="font-family: inherit; min-width: 190px; padding: 4px;">
              <div style="font-size: 10px; font-weight: 800; color: #0f766e; text-transform: uppercase;">Verified Blood Bank • ${escapeHtml(bank.zone)}</div>
              <div style="font-size: 12px; font-weight: 700; color: #0f172a; margin: 2px 0 4px 0;">${escapeHtml(bank.name)}</div>
              <div style="font-size: 11px; color: #475569;">Emergency: <strong>${escapeHtml(bank.emergencyPhone)}</strong></div>
            </div>`
          )
          .addTo(layerGroup);
      });
    }

    // 3. Active Urgent & Emergency Blood Request Pins
    urgentPins.forEach(pin => {
      const { request } = pin;
      const isEmergency = request.urgency === 'Emergency';

      const pinBg = isEmergency
        ? 'bg-rose-600 border-white text-white ring-4 ring-rose-500/35'
        : 'bg-amber-600 border-white text-white ring-4 ring-amber-400/35';

      const pinIcon = L.divIcon({
        className: 'urgent-blood-pin-icon',
        html: `
          <div class="relative flex flex-col items-center cursor-pointer" style="transform: translate(-50%, -50%);">
            <div class="${pinBg} px-2 py-1 rounded-full border-2 shadow-lg flex items-center gap-1 font-black text-[11px] whitespace-nowrap transition-transform hover:scale-110">
              <span>${escapeHtml(request.bloodGroup)}</span>
              <span class="bg-black/25 px-1 rounded text-[9px] font-bold">${request.unitsNeeded}u</span>
            </div>
            <div class="mt-0.5 bg-slate-900/90 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-xs whitespace-nowrap max-w-[140px] truncate">
              ${isEmergency ? 'EMERGENCY' : 'URGENT'} • ${pin.distanceKm} km
            </div>
          </div>
        `,
        iconSize: [74, 42],
        iconAnchor: [37, 21]
      });

      const marker = L.marker([pin.lat, pin.lng], {
        icon: pinIcon,
        zIndexOffset: isEmergency ? 600 : 500
      });

      const popupHtml = `
        <div style="font-family: inherit; min-width: 225px; padding: 4px;">
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 6px; margin-bottom: 6px;">
            <span style="font-size: 10px; font-weight: 800; text-transform: uppercase; padding: 2px 7px; border-radius: 999px; ${
              isEmergency
                ? 'background: #ffe4e6; color: #be123c; border: 1px solid #fda4af;'
                : 'background: #fef3c7; color: #b45309; border: 1px solid #fcd34d;'
            }">
              ${escapeHtml(request.urgency)} • ${request.unitsNeeded} ${request.unitsNeeded === 1 ? 'Unit' : 'Units'}
            </span>
            <span style="font-size: 12px; font-weight: 900; color: #ffffff; background: #e11d48; padding: 2px 7px; border-radius: 6px;">
              ${escapeHtml(request.bloodGroup)}
            </span>
          </div>
          <div style="font-size: 13px; font-weight: 700; color: #0f172a; margin-bottom: 2px;">
            ${escapeHtml(request.hospitalName)}
          </div>
          <div style="font-size: 11px; color: #475569; margin-bottom: 4px;">
            Patient: <strong>${escapeHtml(request.patientName)}</strong> (${escapeHtml(request.requestCode)})
          </div>
          <div style="font-size: 11px; color: #0f766e; font-weight: 600; margin-bottom: 4px;">
            ${pin.distanceKm} km away • ${escapeHtml(pin.zone)}
          </div>
          <div style="font-size: 10px; color: #64748b; margin-bottom: 6px;">
            Compatible Donors: <strong>${escapeHtml(pin.compatibleDonorGroups.join(', '))}</strong>
          </div>
          ${
            request.notes
              ? `<div style="font-size: 10px; color: #64748b; font-style: italic; margin-bottom: 6px;">${escapeHtml(request.notes)}</div>`
              : ''
          }
          <div style="display: flex; align-items: center; justify-content: space-between; font-size: 10px; border-top: 1px solid #e2e8f0; padding-top: 6px;">
            <span style="color: #334155; font-weight: 600;">${escapeHtml(request.contactPhone)}</span>
            <a
              href="https://www.google.com/maps/search/?api=1&query=${pin.lat},${pin.lng}"
              target="_blank"
              rel="noopener noreferrer"
              style="color: #0284c7; font-weight: 700; text-decoration: underline;"
            >
              Directions ➔
            </a>
          </div>
        </div>
      `;

      marker.bindPopup(popupHtml);
      marker.on('click', () => {
        setSelectedRequestId(request.id);
      });

      marker.addTo(layerGroup);
      requestMarkersRef.current[request.id] = marker;
      boundsCoords.push([pin.lat, pin.lng]);
    });

    if (boundsCoords.length >= 2) {
      try {
        map.fitBounds(L.latLngBounds(boundsCoords), { padding: [45, 45], maxZoom: 13 });
      } catch {
        map.setView([referenceLocation.lat, referenceLocation.lng], 12);
      }
    } else if (boundsCoords.length === 1) {
      map.setView(boundsCoords[0], 13);
    }
  }, [urgentPins, bloodBanks, referenceLocation, showBloodBanks]);

  const handleFocusPin = (pin: UrgentBloodRequestPin) => {
    setSelectedRequestId(pin.request.id);
    const map = mapInstanceRef.current;
    if (map) {
      map.flyTo([pin.lat, pin.lng], 14, { duration: 0.6 });
      const marker = requestMarkersRef.current[pin.request.id];
      if (marker) {
        marker.openPopup();
      }
    }
  };

  const handleFitAll = () => {
    const map = mapInstanceRef.current;
    if (!map) return;
    const coords: [number, number][] = [
      [referenceLocation.lat, referenceLocation.lng],
      ...urgentPins.map(p => [p.lat, p.lng] as [number, number])
    ];
    if (coords.length >= 2) {
      map.fitBounds(L.latLngBounds(coords), { padding: [45, 45], maxZoom: 13 });
    } else {
      map.setView([referenceLocation.lat, referenceLocation.lng], 12);
    }
  };

  const handleUseMyLocation = () => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setGeoStatus('Browser GPS unavailable — choose a city zone hub to calculate nearby distances.');
      return;
    }
    setGeoStatus('Locating your position...');
    navigator.geolocation.getCurrentPosition(
      pos => {
        setReferenceLocation({
          lat: Number(pos.coords.latitude.toFixed(4)),
          lng: Number(pos.coords.longitude.toFixed(4)),
          label: 'Your GPS Location'
        });
        setGeoStatus('Updated distances using your live GPS coordinates.');
      },
      () => {
        setGeoStatus('Location permission unavailable — using city hub coordinates.');
      },
      { timeout: 6000 }
    );
  };

  const emergencyCount = urgentPins.filter(p => p.request.urgency === 'Emergency').length;
  const urgentCount = urgentPins.filter(p => p.request.urgency === 'Urgent').length;

  return (
    <div
      className="bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-900/60 shadow-xs overflow-hidden"
      data-testid="urgent-blood-map-section"
    >
      {/* Map Header */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-rose-950 to-slate-900 text-white space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-200 border border-rose-400/40">
                <span className="w-2 h-2 rounded-full bg-rose-400" />
                Live Emergency &amp; Urgent Donor Dispatch Map
              </span>
              <span
                className="text-[11px] font-bold text-amber-300"
                data-testid="urgent-map-count"
              >
                {urgentPins.length} Active {urgentPins.length === 1 ? 'Location' : 'Locations'} Needing Donation
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-extrabold text-white">
              Nearby Active Urgent Blood Requests
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              Inspect hospitals requiring immediate blood donations near {referenceLocation.label} and pledge a slot directly.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <select
              aria-label="Select reference area for nearby blood requests"
              value={
                Object.entries(ZONE_REFERENCE_POINTS).find(
                  ([, pt]) => pt.label === referenceLocation.label
                )?.[0] || 'center'
              }
              onChange={e => {
                const val = e.target.value;
                setGeoStatus(null);
                if (val === 'center') {
                  setReferenceLocation(DEFAULT_USER_LOCATION);
                } else if (ZONE_REFERENCE_POINTS[val]) {
                  setReferenceLocation(ZONE_REFERENCE_POINTS[val]);
                }
              }}
              className="bg-slate-800 border border-slate-700 text-white rounded-xl px-2.5 py-1.5 text-xs font-medium cursor-pointer"
            >
              <option value="center">Near: Ideal City Center</option>
              <option value="Central Zone">Near: Central Zone</option>
              <option value="Cyber Zone">Near: Cyber Zone</option>
              <option value="North Zone">Near: North Zone</option>
              <option value="South Zone">Near: South Zone</option>
            </select>

            <button
              type="button"
              onClick={handleUseMyLocation}
              className="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-100 px-2.5 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Crosshair className="w-3.5 h-3.5 text-sky-400" />
              <span>Use GPS</span>
            </button>

            <button
              type="button"
              onClick={handleFitAll}
              className="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-100 px-2.5 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5 text-teal-400" />
              <span>Fit All</span>
            </button>
          </div>
        </div>

        {/* Urgency & Compatibility Filter Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/10 text-xs">
          <div className="flex flex-wrap items-center gap-1.5">
            {(
              [
                { id: 'all_urgent', label: `All Urgent & Emergency (${allUrgentCount})` },
                { id: 'Urgent', label: `Urgent Only` },
                { id: 'Emergency', label: `Emergency Only` }
              ] as const
            ).map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setUrgencyFilter(tab.id)}
                className={`px-3 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                  urgencyFilter === tab.id
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-white/10 text-slate-200 hover:bg-white/15'
                }`}
              >
                {tab.label}
              </button>
            ))}

            {currentUser.bloodGroup && (
              <button
                type="button"
                onClick={() => setCompatibleOnly(prev => !prev)}
                className={`px-3 py-1 rounded-lg font-bold transition-colors flex items-center gap-1.5 cursor-pointer border ${
                  compatibleOnly
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                    : 'bg-white/10 text-emerald-200 border-emerald-400/30 hover:bg-white/15'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Compatible with My Type ({currentUser.bloodGroup})</span>
              </button>
            )}
          </div>

          <label className="inline-flex items-center gap-1.5 text-[11px] text-slate-300 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showBloodBanks}
              onChange={e => setShowBloodBanks(e.target.checked)}
              className="rounded accent-teal-500"
            />
            <span>Show Verified Blood Banks</span>
          </label>
        </div>

        {geoStatus && (
          <div className="text-[11px] text-sky-200 bg-sky-950/60 border border-sky-800/70 rounded-lg px-3 py-1.5">
            {geoStatus}
          </div>
        )}
      </div>

      {/* Map + Nearby Urgent Locations Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3">
        {/* Interactive Leaflet Map */}
        <div className="lg:col-span-2 flex flex-col bg-slate-100 dark:bg-slate-950">
          <div className="relative h-[340px] sm:h-[400px]">
            <div
              ref={mapContainerRef}
              className="w-full h-full z-10"
              data-testid="urgent-blood-leaflet-map"
            />
          </div>

          {/* Dedicated Map Legend Bar (never obscures pins or popups) */}
          <div className="px-4 py-2 bg-slate-900 text-white text-[11px] font-semibold border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-3">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600 inline-block" />
                Emergency ({emergencyCount})
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />
                Urgent ({urgentCount})
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-teal-600 inline-block" />
                Verified Blood Bank
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-500 inline-block" />
                Reference Hub
              </span>
            </div>
            <span className="text-[10px] text-slate-400">
              Click any pin for patient details &amp; directions
            </span>
          </div>
        </div>

        {/* Nearest Urgent Locations List */}
        <div className="lg:col-span-1 bg-slate-50 dark:bg-slate-950 border-t lg:border-t-0 lg:border-l border-slate-200 dark:border-slate-800 p-4 flex flex-col max-h-[430px]">
          <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h4 className="font-bold text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
                <Navigation className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                <span>Nearest Urgent Requests ({urgentPins.length})</span>
              </h4>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Click any location to zoom in &amp; view directions
              </p>
            </div>
          </div>

          {urgentPins.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-4 space-y-2">
              <AlertTriangle className="w-7 h-7 text-amber-500" />
              <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                No active urgent requests match these filters
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Try switching back to &ldquo;All Urgent &amp; Emergency&rdquo; or clearing the blood group / compatibility filter.
              </p>
            </div>
          ) : (
            <div
              className="flex-1 overflow-y-auto space-y-2.5 pr-0.5"
              data-testid="urgent-blood-pin-list"
            >
              {urgentPins.map(pin => {
                const { request } = pin;
                const isEmergency = request.urgency === 'Emergency';
                const isSelected = selectedRequestId === request.id;

                return (
                  <article
                    key={request.id}
                    className={`p-3 rounded-xl border transition-all space-y-2 ${
                      isSelected
                        ? 'bg-rose-50/90 dark:bg-rose-950/50 border-rose-400 dark:border-rose-600 shadow-xs'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-rose-300 dark:hover:border-rose-700'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => handleFocusPin(pin)}
                      aria-label={`Locate ${request.hospitalName} (${request.bloodGroup} ${request.urgency}) on map`}
                      className="w-full text-left space-y-2 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 rounded-lg"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <span
                            className={`px-2 py-1 rounded-lg text-xs font-black text-white shrink-0 ${
                              isEmergency ? 'bg-rose-600' : 'bg-amber-600'
                            }`}
                          >
                            {request.bloodGroup}
                          </span>
                          <div className="min-w-0">
                            <div className="font-bold text-xs text-slate-900 dark:text-white truncate">
                              {request.hospitalName}
                            </div>
                            <div className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-rose-500 shrink-0" />
                              <span>
                                {pin.distanceKm} km away • {pin.zone}
                              </span>
                            </div>
                          </div>
                        </div>
                        <span
                          className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full shrink-0 ${
                            isEmergency
                              ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
                              : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                          }`}
                        >
                          {request.urgency}
                        </span>
                      </div>

                      <div className="text-[11px] text-slate-600 dark:text-slate-300 flex flex-wrap items-center justify-between gap-1">
                        <span>
                          <Droplet className="w-3 h-3 inline text-rose-500 mr-0.5" />
                          <strong>
                            {request.unitsNeeded} {request.unitsNeeded === 1 ? 'Unit' : 'Units'}
                          </strong>{' '}
                          • {request.patientName}
                        </span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-0.5">
                          <Phone className="w-3 h-3" /> {request.contactPhone}
                        </span>
                      </div>

                      {pin.isCompatibleWithCurrentDonor && currentUser.bloodGroup && (
                        <div className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/70 rounded-lg px-2 py-1 flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3 shrink-0" />
                          <span>Your {currentUser.bloodGroup} blood type can donate here!</span>
                        </div>
                      )}
                    </button>

                    <div className="flex items-center gap-1.5 pt-1">
                      <button
                        type="button"
                        data-testid="urgent-card-donate-btn"
                        onClick={() => onDonateForRequest(request, pin.resolvedBankId)}
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold py-1.5 px-2.5 rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <HeartHandshake className="w-3.5 h-3.5" />
                        <span>Donate Now</span>
                      </button>
                      <a
                        href={`https://www.google.com/maps/search/?api=1&query=${pin.lat},${pin.lng}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1"
                        title="Open Google Maps Directions"
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>Route</span>
                      </a>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
