import React, { useState } from 'react';
import type { AccidentReport } from '../types';
import {
  buildGoogleMapsDirectionsUrl,
  buildScopedMediaUrl,
} from '../utils/accidentEmergency';
import { DEMO_TRACKING_CREDENTIALS } from '../data/seedData';
import { AccidentLocationMap } from './AccidentLocationMap';
import {
  Activity,
  Ambulance,
  Building2,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  ExternalLink,
  EyeOff,
  KeyRound,
  Lock,
  Navigation,
  PhoneCall,
  RefreshCw,
  Search,
  Shield,
  ShieldCheck,
} from 'lucide-react';

export interface TrackedAccidentEntry {
  report: AccidentReport;
  trackingToken: string;
}

interface Props {
  trackedEntry: TrackedAccidentEntry | null;
  recentSubmissions: TrackedAccidentEntry[];
  justSubmittedCode: string | null;
  onLookupReport: (
    incidentCode: string,
    trackingToken: string
  ) => Promise<{ ok: boolean; error?: string }>;
  onSelectRecent: (entry: TrackedAccidentEntry) => void;
  onRefreshTracked: () => Promise<void>;
  onNewReport: () => void;
  isRefreshing: boolean;
}

function getOverallStatusStyle(status: AccidentReport['overallStatus']) {
  if (status === 'Resolved') {
    return 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800';
  }
  if (status === 'Response Dispatched') {
    return 'bg-orange-50 dark:bg-orange-950/40 text-orange-800 dark:text-orange-300 border-orange-200 dark:border-orange-800';
  }
  return 'bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-300 border-red-200 dark:border-red-800';
}

function getSeverityStyle(sev: AccidentReport['severity']) {
  if (sev === 'Critical') {
    return 'bg-red-600 text-white';
  }
  if (sev === 'Medium') {
    return 'bg-orange-500 text-white';
  }
  return 'bg-emerald-600 text-white';
}

export const AccidentTrackingView: React.FC<Props> = ({
  trackedEntry,
  recentSubmissions,
  justSubmittedCode,
  onLookupReport,
  onSelectRecent,
  onRefreshTracked,
  onNewReport,
  isRefreshing,
}) => {
  const [reportIdInput, setReportIdInput] = useState<string>(
    trackedEntry?.report.incidentCode || ''
  );
  const [tokenInput, setTokenInput] = useState<string>(
    trackedEntry?.trackingToken || ''
  );
  const [lookupLoading, setLookupLoading] = useState(false);
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [copiedField, setCopiedField] = useState<'id' | 'token' | null>(null);

  const handleCopy = async (text: string, field: 'id' | 'token') => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      window.setTimeout(() => setCopiedField(null), 2000);
    } catch {
      // ignore clipboard errors in restricted frames
    }
  };

  const handleLookupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLookupError(null);
    if (!reportIdInput.trim() || !tokenInput.trim()) {
      setLookupError('Enter both your unique Accident Report ID and Secure Tracking Token.');
      return;
    }
    setLookupLoading(true);
    try {
      const result = await onLookupReport(reportIdInput.trim(), tokenInput.trim());
      if (!result.ok) {
        setLookupError(result.error || 'Unable to verify report credentials.');
      }
    } finally {
      setLookupLoading(false);
    }
  };

  const handleQuickLookup = async (incidentCode: string, trackingToken: string) => {
    setReportIdInput(incidentCode);
    setTokenInput(trackingToken);
    setLookupError(null);
    setLookupLoading(true);
    try {
      const result = await onLookupReport(incidentCode, trackingToken);
      if (!result.ok) {
        setLookupError(result.error || 'Unable to load report.');
      }
    } finally {
      setLookupLoading(false);
    }
  };

  const activeReport = trackedEntry?.report || null;
  const activeToken = trackedEntry?.trackingToken || '';
  const scopedPhotoUrl = activeReport
    ? buildScopedMediaUrl(activeReport.securePhotoUrl, activeReport.incidentCode, activeToken)
    : '';

  return (
    <div className="space-y-6" data-testid="accident-tracking-view">
      {/* Anonymous Token-Based Lookup Bar (No Login Required) */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 inline-flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5" />
              <span>Anonymous Report Tracking · No Personal Login Required</span>
            </div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
              Track Emergency Response Using Report ID &amp; Secure Token
            </h2>
          </div>
          <button
            type="button"
            onClick={onNewReport}
            className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer self-start sm:self-auto"
          >
            + New Anonymous Report
          </button>
        </div>

        <form onSubmit={handleLookupSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          <div className="md:col-span-4">
            <label
              htmlFor="track-report-id-input"
              className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1"
            >
              Accident Report ID
            </label>
            <input
              id="track-report-id-input"
              data-testid="track-report-id-input"
              type="text"
              value={reportIdInput}
              onChange={(e) => setReportIdInput(e.target.value)}
              placeholder="e.g., ACC-2026-84102"
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-mono uppercase"
            />
          </div>
          <div className="md:col-span-5">
            <label
              htmlFor="track-token-input"
              className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1"
            >
              Secure Tracking Token
            </label>
            <input
              id="track-token-input"
              data-testid="track-token-input"
              type="text"
              value={tokenInput}
              onChange={(e) => setTokenInput(e.target.value)}
              placeholder="e.g., TRK-XXXX-XXXX-XXXX-XXXX"
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-xs font-mono uppercase"
            />
          </div>
          <div className="md:col-span-3">
            <button
              type="submit"
              disabled={lookupLoading}
              data-testid="track-submit-btn"
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-teal-600 hover:bg-slate-800 dark:hover:bg-teal-700 text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
            >
              <Search className="w-3.5 h-3.5" />
              <span>{lookupLoading ? 'Verifying...' : 'Track Anonymously'}</span>
            </button>
          </div>
        </form>

        {lookupError && (
          <div
            data-testid="track-lookup-error"
            className="text-xs text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-xl px-3.5 py-2.5 font-semibold"
          >
            {lookupError}
          </div>
        )}

        {/* Recent session submissions + Demo tracking shortcuts */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-2 text-[11px]">
          {recentSubmissions.length > 0 && (
            <>
              <span className="font-bold text-slate-500 dark:text-slate-400">Your Session Reports:</span>
              {recentSubmissions.map((item) => (
                <button
                  key={item.report.incidentCode}
                  type="button"
                  onClick={() => {
                    onSelectRecent(item);
                    setReportIdInput(item.report.incidentCode);
                    setTokenInput(item.trackingToken);
                    setLookupError(null);
                  }}
                  className={`px-2.5 py-1 rounded-lg font-mono font-bold border transition-colors cursor-pointer ${
                    activeReport?.incidentCode === item.report.incidentCode
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                  }`}
                >
                  {item.report.incidentCode}
                </button>
              ))}
            </>
          )}

          <span className="font-bold text-slate-500 dark:text-slate-400">Demo Tracking Tokens:</span>
          {DEMO_TRACKING_CREDENTIALS.map((cred) => (
            <button
              key={cred.incidentCode}
              type="button"
              data-testid={`demo-track-${cred.incidentCode}`}
              onClick={() => handleQuickLookup(cred.incidentCode, cred.trackingToken)}
              className="px-2.5 py-1 rounded-lg font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 cursor-pointer"
            >
              {cred.incidentCode} ({cred.label})
            </button>
          ))}
        </div>
      </section>

      {!activeReport ? (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-10 text-center space-y-3">
          <Lock className="w-10 h-10 text-emerald-600 mx-auto" />
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Protected Anonymous Tracking
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-lg mx-auto leading-relaxed">
              For citizen safety and privacy, other people&apos;s accident reports and photographs are never listed publicly. Enter your unique <strong>Accident Report ID</strong> and <strong>Secure Tracking Token</strong> above — or select a Demo Tracking Token to test live response tracking.
            </p>
          </div>
        </div>
      ) : (
        <>
          {/* Anonymous Tracking Receipt & Token Box */}
          <div
            data-testid="anonymous-tracking-receipt"
            className={`rounded-2xl border p-5 space-y-3 ${
              justSubmittedCode === activeReport.incidentCode
                ? 'bg-emerald-50 dark:bg-emerald-950/35 border-emerald-300 dark:border-emerald-800'
                : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800'
            }`}
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-extrabold text-emerald-800 dark:text-emerald-300">
                <EyeOff className="w-4 h-4 shrink-0" />
                <span>
                  {justSubmittedCode === activeReport.incidentCode
                    ? 'Anonymous Report Submitted — Save Your Private Tracking Credentials'
                    : 'Verified Anonymous Tracking Session · Reporter Identity Protected'}
                </span>
              </div>
              <button
                type="button"
                onClick={onRefreshTracked}
                disabled={isRefreshing}
                data-testid="refresh-tracked-report-btn"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                <span>Refresh Live Updates</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-[10px] font-bold uppercase text-slate-400">
                    Unique Accident Report ID
                  </div>
                  <div
                    data-testid="tracked-report-id-value"
                    className="font-mono text-sm font-black text-slate-900 dark:text-white truncate"
                  >
                    {activeReport.incidentCode}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(activeReport.incidentCode, 'id')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-bold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  {copiedField === 'id' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedField === 'id' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="p-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-[10px] font-bold uppercase text-slate-400">
                    Secure Tracking Token (Keep Private)
                  </div>
                  <div
                    data-testid="tracked-token-value"
                    className="font-mono text-sm font-black text-emerald-700 dark:text-emerald-400 truncate"
                  >
                    {activeToken}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(activeToken, 'token')}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-bold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  {copiedField === 'token' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedField === 'token' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Submission Status Banner */}
          <div
            className={`rounded-2xl border p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${getOverallStatusStyle(
              activeReport.overallStatus
            )}`}
          >
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span className="font-extrabold text-sm sm:text-base">
                  Emergency Alert Active · <span className="font-mono">{activeReport.incidentCode}</span>
                </span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${getSeverityStyle(activeReport.severity)}`}>
                  {activeReport.severity} Severity
                </span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-emerald-700 text-white">
                  Reporter Identity: {activeReport.reporterIdentityLabel}
                </span>
              </div>
              <p className="text-xs opacity-90">
                {activeReport.accidentType} at <strong>{activeReport.locationLabel}</strong> · Reported{' '}
                <span className="font-mono tabular-nums">
                  {activeReport.incidentDate} {activeReport.incidentTime}
                </span>
              </p>
              {activeReport.demoMode && (
                <p className="text-[11px] opacity-85">
                  Demo Dispatch Mode active: Backend confirmed simulated anonymous notifications to nearby Hospitals, 108 Ambulance, and Police. For life-threatening emergencies, always call 108 / 112.
                </p>
              )}
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="px-3 py-1.5 rounded-xl bg-white/80 dark:bg-slate-900/80 text-xs font-extrabold border border-current/20">
                {activeReport.overallStatus}
              </span>
              <a
                href={activeReport.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Map Link</span>
              </a>
            </div>
          </div>

          {/* 3 Authority Status Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* A. Hospital Notification Status */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-400 flex items-center justify-center border border-teal-200 dark:border-teal-800">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[11px] font-bold uppercase text-slate-400">Nearby Hospitals</div>
                    <div className="text-xs font-extrabold text-slate-900 dark:text-white">
                      {activeReport.notifiedHospitals[0]?.status || 'Pending'}
                    </div>
                  </div>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                  {activeReport.notifiedHospitals[0]?.deliveryConfirmed ? 'Confirmed (Demo)' : 'Awaiting'}
                </span>
              </div>

              <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
                {activeReport.notifiedHospitals.map((h) => (
                  <div
                    key={h.hospitalId}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-700/70"
                  >
                    <div className="font-bold text-slate-900 dark:text-white leading-snug">
                      {h.hospitalName}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 flex items-center justify-between font-mono tabular-nums">
                      <span>{h.distanceKm} km away</span>
                      <span className="font-sans font-bold text-teal-700 dark:text-teal-400">{h.status}</span>
                    </div>
                    {h.notes && (
                      <div className="text-[11px] text-slate-600 dark:text-slate-300 mt-1">
                        {h.notes}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* B. Ambulance Notification & Dispatch Status */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-xl bg-orange-50 dark:bg-orange-950/60 text-orange-700 dark:text-orange-400 flex items-center justify-center border border-orange-200 dark:border-orange-800">
                    <Ambulance className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[11px] font-bold uppercase text-slate-400">Ambulance 108</div>
                    <div className="text-xs font-extrabold text-slate-900 dark:text-white" data-testid="tracker-ambulance-status">
                      {activeReport.ambulanceDispatch.status}
                    </div>
                  </div>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                  Confirmed (Demo)
                </span>
              </div>

              <div className="p-3 rounded-xl bg-orange-50/70 dark:bg-orange-950/30 border border-orange-200 dark:border-orange-900 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-orange-800 dark:text-orange-300 font-semibold">
                    Estimated Arrival Time
                  </div>
                  <div className="text-lg font-black text-orange-700 dark:text-orange-300 font-mono tabular-nums" data-testid="tracker-ambulance-eta">
                    {activeReport.ambulanceDispatch.etaMinutes !== null
                      ? activeReport.ambulanceDispatch.etaMinutes === 0
                        ? 'On Scene / Done'
                        : `${activeReport.ambulanceDispatch.etaMinutes} min`
                      : 'Pending EMS'}
                  </div>
                </div>
                <div className="text-right text-[11px] font-mono tabular-nums text-slate-600 dark:text-slate-300">
                  <div>{activeReport.ambulanceDispatch.distanceKm} km route</div>
                  <div className="font-bold">{activeReport.ambulanceDispatch.vehicleNumber}</div>
                </div>
              </div>

              <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1">
                <div>
                  Unit: <strong className="text-slate-900 dark:text-white">{activeReport.ambulanceDispatch.callSign}</strong>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  {activeReport.ambulanceDispatch.stationName}
                </div>
                {activeReport.ambulanceDispatch.notes && (
                  <div className="text-[11px] pt-1">{activeReport.ambulanceDispatch.notes}</div>
                )}
              </div>

              <div className="flex items-center gap-2 pt-1">
                <a
                  href={buildGoogleMapsDirectionsUrl(
                    activeReport.ambulanceDispatch.originLat,
                    activeReport.ambulanceDispatch.originLng,
                    activeReport.latitude,
                    activeReport.longitude
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center gap-1 py-1.5 px-2.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
                >
                  <Navigation className="w-3.5 h-3.5 text-orange-600" />
                  <span>Shortest Route</span>
                </a>
                <a
                  href={`tel:${activeReport.ambulanceDispatch.phone}`}
                  className="inline-flex items-center gap-1 py-1.5 px-3 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-bold"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>108</span>
                </a>
              </div>
            </div>

            {/* C. Police Notification & Investigation Status */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 flex items-center justify-center border border-blue-200 dark:border-blue-800">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[11px] font-bold uppercase text-slate-400">Police Department</div>
                    <div className="text-xs font-extrabold text-slate-900 dark:text-white" data-testid="tracker-police-status">
                      {activeReport.policeDispatch.status}
                    </div>
                  </div>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                  Confirmed (Demo)
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-700/70 text-xs space-y-1">
                <div className="font-bold text-slate-900 dark:text-white">
                  {activeReport.policeDispatch.stationName}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                  {activeReport.policeDispatch.zone} · {activeReport.policeDispatch.distanceKm} km away · {activeReport.policeDispatch.phone}
                </div>
                {activeReport.policeDispatch.officerNotes && (
                  <div className="text-[11px] text-slate-700 dark:text-slate-300 pt-1">
                    {activeReport.policeDispatch.officerNotes}
                  </div>
                )}
              </div>

              <a
                href="tel:112"
                className="w-full inline-flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Call Police Control (100 / 112)</span>
              </a>
            </div>
          </div>

          {/* Live Route Map, Protected Photo, Standardized Anonymous Alert & Timeline */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-7 space-y-4">
              <AccidentLocationMap
                mode="command"
                reports={[activeReport]}
                selectedReportId={activeReport.id}
                heightClass="h-80"
              />

              {/* Scoped Encrypted Photo & AI Summary */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
                <div className="space-y-1">
                  <img
                    src={scopedPhotoUrl}
                    alt="Protected accident scene evidence"
                    draggable={false}
                    onContextMenu={(e) => e.preventDefault()}
                    data-testid="tracker-protected-photo"
                    className="w-full h-36 object-cover rounded-xl border border-slate-200 dark:border-slate-700 select-none"
                  />
                  <div className="text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold flex items-center gap-1">
                    <Lock className="w-3 h-3 shrink-0" />
                    <span>EXIF Stripped · Encrypted Vault</span>
                  </div>
                </div>
                <div className="sm:col-span-2 space-y-2 text-xs">
                  <div className="font-bold text-slate-900 dark:text-white text-sm">
                    Incident Assessment Summary
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {activeReport.aiAnalysis.shortDescription}
                  </p>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                    {activeReport.aiAnalysis.disclaimer}
                  </div>
                </div>
              </div>

              {/* Standardized Anonymous Emergency Notification Dispatched */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="text-xs font-extrabold text-slate-900 dark:text-white inline-flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Standardized Anonymous Alert Sent to Authorities</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">
                    Auto-purge: {activeReport.retentionExpiresAt.split('T')[0]}
                  </span>
                </div>
                <pre
                  data-testid="tracker-authority-alert-text"
                  className="text-[11px] font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 overflow-x-auto whitespace-pre-wrap text-slate-700 dark:text-slate-300 leading-relaxed"
                >
                  {activeReport.authorityAlertText}
                </pre>
              </div>
            </div>

            <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-red-600" />
                  <span>Live Response Timeline</span>
                </h3>
                <span className="text-[11px] text-slate-400 font-mono tabular-nums">
                  {activeReport.responseHistory.length} Events
                </span>
              </div>

              <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
                {activeReport.responseHistory.map((evt) => (
                  <div
                    key={evt.id}
                    className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/80 dark:border-slate-700/70 space-y-1"
                  >
                    <div className="flex items-center justify-between gap-2 text-[11px]">
                      <span className="font-bold text-slate-900 dark:text-white">
                        {evt.agency} · {evt.actor}
                      </span>
                      <span className="font-mono text-slate-400 tabular-nums inline-flex items-center gap-1 shrink-0">
                        <Clock className="w-3 h-3" />
                        {new Date(evt.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {evt.message}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
