import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, Sparkles, X, ShieldCheck, Volume2, VolumeX, Copy, Check, RefreshCw, ExternalLink } from 'lucide-react';

export interface GroundedPlace {
  title: string;
  uri: string;
  placeId: string;
  address: string;
  snippets?: string[];
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  isAiGenerated?: boolean;
  source?: string;
  groundingPlaces?: GroundedPlace[];
  mapsGroundingUsed?: boolean;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  initialQuestion?: string;
}

export const IdealAiChatModal: React.FC<Props> = ({ isOpen, onClose, initialQuestion = '' }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm-welcome',
      sender: 'assistant',
      text: `Hello! I am **IDEAL AI**, your verified Smart Citizen Information Assistant for **IDEAL CITY 360**.\n\nI answer queries strictly grounded in the city's verified municipal registry:\n- **Specialist doctor visits & hospital beds**\n- **Live smart bus tracking & schedules**\n- **Government rules, certificates & welfare schemes**\n- **Hospital recruitment & job openings**\n\n*All responses include verified source citations and official links.* How can I assist you today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      source: 'IDEAL CITY 360 Official Knowledge Base'
    }
  ]);
  const [input, setInput] = useState(initialQuestion);
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const sampleQuestions = [
    'Find top trauma hospitals on Google Maps',
    'Where is the nearest 24x7 pharmacy?',
    'When will the cardiologist visit?',
    'Which hospitals have nurse vacancies?',
    'When is the next bus on Route 100E?',
    'What documents are needed for a birth certificate?',
    'Which government schemes am I eligible to explore?',
    'Where can I find free health services?'
  ];

  useEffect(() => {
    if (initialQuestion) {
      setInput(initialQuestion);
      handleSend(initialQuestion);
    }
  }, [initialQuestion]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSend = async (questionToSend?: string) => {
    const query = questionToSend || input;
    if (!query.trim() || loading) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/gemini/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          question: query,
          lat: 17.4150,
          lng: 78.4600
        })
      });
      const data = await res.json();

      const assistantMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: data.answer || 'I could not retrieve an answer at this moment.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isAiGenerated: data.isAiGenerated,
        source: data.source || 'IDEAL CITY 360 Verified Registry',
        groundingPlaces: data.groundingPlaces || [],
        mapsGroundingUsed: Boolean(data.mapsGroundingUsed)
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err) {
      const errorMsg: Message = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        text: 'An error occurred while querying the verified database. Please check your network and retry.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const copyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleSpeech = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingMessageId === id) {
      window.speechSynthesis.cancel();
      setSpeakingMessageId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Strip markdown formatting for cleaner speech
    const cleanText = text.replace(/[*#_`[\]]/g, '').replace(/https?:\/\/\S+/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.onend = () => setSpeakingMessageId(null);
    utterance.onerror = () => setSpeakingMessageId(null);

    setSpeakingMessageId(id);
    window.speechSynthesis.speak(utterance);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-2xl h-[90vh] max-h-[720px] flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        
        {/* Modal Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-navy-900 via-slate-900 to-navy-950 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-300">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-white text-base">IDEAL AI Assistant</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-teal-400" /> Grounded RAG
                </span>
              </div>
              <p className="text-xs text-slate-400">Strictly grounded in verified municipal data. Never fabricates.</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Suggested Quick Prompt Chips */}
        <div className="px-4 py-2.5 bg-slate-50 dark:bg-slate-950/80 border-b border-slate-200 dark:border-slate-800 overflow-x-auto flex items-center gap-2 no-scrollbar">
          <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider shrink-0 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-teal-600 dark:text-teal-400" /> Prompts:
          </span>
          {sampleQuestions.map((sq, i) => (
            <button
              key={i}
              type="button"
              onClick={() => handleSend(sq)}
              className="text-xs bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-teal-50 dark:hover:bg-slate-700 hover:text-teal-800 dark:hover:text-teal-300 hover:border-teal-300 dark:hover:border-slate-600 border border-slate-200 dark:border-slate-700 px-3 py-1 rounded-full whitespace-nowrap transition-colors shadow-2xs font-medium cursor-pointer"
            >
              {sq}
            </button>
          ))}
        </div>

        {/* Chat Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 bg-slate-50/50 dark:bg-slate-950/40">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'assistant' && (
                <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div className={`max-w-[85%] rounded-2xl p-4 shadow-xs text-xs sm:text-sm leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-slate-900 dark:bg-teal-700 text-white rounded-tr-none'
                  : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-tl-none'
              }`}>
                {/* Message Body with clean formatting */}
                <div className="whitespace-pre-wrap space-y-2">
                  {msg.text.split('\n\n').map((block, bIdx) => {
                    // Render simple markdown headers & bullet lists cleanly
                    if (block.startsWith('### ')) {
                      return <h4 key={bIdx} className="font-bold text-slate-900 dark:text-white text-sm mt-1">{block.replace('### ', '')}</h4>;
                    }
                    if (block.startsWith('- ')) {
                      const lines = block.split('\n');
                      return (
                        <ul key={bIdx} className="space-y-1 list-disc list-inside">
                          {lines.map((line, lIdx) => (
                            <li key={lIdx} dangerouslySetInnerHTML={{ 
                              __html: line.replace(/^- /, '')
                                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                                .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" class="text-teal-600 dark:text-teal-400 underline font-medium">$1</a>')
                            }} />
                          ))}
                        </ul>
                      );
                    }
                    return (
                      <p key={bIdx} dangerouslySetInnerHTML={{
                        __html: block
                          .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                          .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" class="text-teal-600 dark:text-teal-400 underline font-medium">$1</a>')
                      }} />
                    );
                  })}
                </div>

                {/* Google Maps Grounded Places */}
                {msg.groundingPlaces && msg.groundingPlaces.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700/80 space-y-2">
                    <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-700 dark:text-emerald-400">
                      <Sparkles className="w-3.5 h-3.5 text-yellow-500" />
                      <span>Google Maps Grounded Locations ({msg.groundingPlaces.length}):</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {msg.groundingPlaces.map((place, pIdx) => (
                        <a
                          key={pIdx}
                          href={place.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-500 transition-all flex flex-col justify-between group text-left"
                        >
                          <div>
                            <div className="font-semibold text-xs text-slate-900 dark:text-slate-100 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 flex items-start justify-between gap-1">
                              <span>{place.title}</span>
                              <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-emerald-600 shrink-0 mt-0.5" />
                            </div>
                            {place.address && (
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                                📍 {place.address}
                              </p>
                            )}
                            {place.snippets && place.snippets.length > 0 && (
                              <p className="text-[10px] text-slate-400 italic mt-1 line-clamp-2">
                                "{place.snippets[0]}"
                              </p>
                            )}
                          </div>
                          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold mt-2 inline-flex items-center gap-1">
                            Open in Google Maps →
                          </span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {/* Footer Toolbar for Assistant Messages */}
                {msg.sender === 'assistant' && (
                  <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-400">
                    <span className="flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400">
                      <ShieldCheck className="w-3.5 h-3.5" /> Verified Municipal Output
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => toggleSpeech(msg.id, msg.text)}
                        title={speakingMessageId === msg.id ? 'Stop audio' : 'Listen with Voice'}
                        className="hover:text-slate-700 dark:hover:text-slate-200 p-1 rounded cursor-pointer"
                      >
                        {speakingMessageId === msg.id ? <VolumeX className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 animate-pulse" /> : <Volume2 className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        type="button"
                        onClick={() => copyText(msg.id, msg.text)}
                        title="Copy text"
                        className="hover:text-slate-700 dark:hover:text-slate-200 p-1 rounded cursor-pointer"
                      >
                        {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                      <span>{msg.timestamp}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 items-center">
              <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center shadow-xs">
                <RefreshCw className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-3.5 text-xs text-slate-500 dark:text-slate-400 shadow-xs flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-teal-500 animate-ping"></span>
                Searching verified databases and indexing government records...
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
          <form
            onSubmit={e => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="Ask IDEAL AI about doctors, buses, jobs, schemes or emergency help..."
              className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 text-xs sm:text-sm text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-hidden focus:ring-2 focus:ring-teal-500 focus:bg-white dark:focus:bg-slate-800"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="bg-teal-600 text-white p-3 rounded-xl hover:bg-teal-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-xs cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
          <div className="mt-2 text-center text-[10px] text-slate-400 dark:text-slate-500">
            IDEAL AI responds strictly with verified citations. Always verify emergency medical needs via 108.
          </div>
        </div>

      </div>
    </div>
  );
};
