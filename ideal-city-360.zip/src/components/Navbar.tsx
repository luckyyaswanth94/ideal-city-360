import React, { useState } from 'react';
import { User, NotificationItem } from '../types';
import { Language, TRANSLATIONS } from '../utils/translations';
import { 
  Building2, 
  HeartPulse, 
  Bus, 
  FileText, 
  Briefcase, 
  GraduationCap, 
  Users, 
  BarChart3, 
  UserCheck, 
  ShieldAlert, 
  Bot, 
  Bell, 
  Globe, 
  ChevronDown, 
  Check, 
  Search,
  Menu,
  X,
  Sun,
  Moon,
  Siren
} from 'lucide-react';

interface Props {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: User;
  onSwitchUserRole: (role: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  onOpenAiAssistant: (initialQ?: string) => void;
  notifications: NotificationItem[];
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

export const Navbar: React.FC<Props> = ({
  activeTab,
  setActiveTab,
  currentUser,
  onSwitchUserRole,
  language,
  setLanguage,
  onOpenAiAssistant,
  notifications,
  theme,
  onToggleTheme
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);
  const [notifMenuOpen, setNotifMenuOpen] = useState(false);

  const t = TRANSLATIONS[language];

  const roleOptions = [
    { role: 'citizen', label: 'Citizen', name: 'Srinivas Rao', email: 'citizen@idealcity360.gov.in', color: 'bg-emerald-100 text-emerald-800' },
    { role: 'super_admin', label: 'Super Admin', name: 'Dr. Aruna Devi (IAS)', email: 'admin@idealcity360.gov.in', color: 'bg-purple-100 text-purple-800' },
    { role: 'hospital_admin', label: 'Hospital Admin', name: 'Dr. Vikramaditya Reddy', email: 'hospital.admin@idealcity360.gov.in', color: 'bg-rose-100 text-rose-800' },
    { role: 'transport_admin', label: 'Transport Admin', name: 'Ramesh Chandra (RTO)', email: 'transport.admin@idealcity360.gov.in', color: 'bg-sky-100 text-sky-800' },
    { role: 'gov_admin', label: 'Gov Dept Admin', name: 'Sunita Sharma (Joint Director)', email: 'gov.admin@idealcity360.gov.in', color: 'bg-amber-100 text-amber-800' },
    { role: 'verifier', label: 'General Verifier', name: 'K. Mahender (Audit Cell)', email: 'verifier@idealcity360.gov.in', color: 'bg-blue-100 text-blue-800' },
    { role: 'ambulance_service', label: '108 Ambulance EMS', name: 'S. Narayana (108 EMS Lead)', email: 'ambulance.ems@idealcity360.gov.in', color: 'bg-orange-100 text-orange-800' },
    { role: 'police_officer', label: 'Traffic Police', name: 'Insp. M. Anitha (Traffic Police)', email: 'police.traffic@idealcity360.gov.in', color: 'bg-indigo-100 text-indigo-800' }
  ];

  const currentRoleObj = roleOptions.find(r => r.role === currentUser.role) || roleOptions[0];
  const unreadCount = notifications.filter(n => !n.read).length;

  const navItems = [
    { id: 'home', label: t.home, shortLabel: language === 'en' ? 'Home' : t.home, icon: Building2 },
    { id: 'healthcare', label: t.healthcare, shortLabel: language === 'en' ? 'Health' : t.healthcare, icon: HeartPulse },
    { id: 'transport', label: t.transport, shortLabel: language === 'en' ? 'Transport' : t.transport, icon: Bus },
    { id: 'government', label: t.government, shortLabel: language === 'en' ? 'Schemes' : t.government, icon: FileText },
    { id: 'employment', label: t.employment, shortLabel: language === 'en' ? 'Careers' : t.employment, icon: Briefcase },
    { id: 'education', label: t.education, shortLabel: language === 'en' ? 'Education' : t.education, icon: GraduationCap },
    { id: 'socialWelfare', label: t.socialWelfare, shortLabel: language === 'en' ? 'Welfare' : t.socialWelfare, icon: Users },
    { id: 'wellbeing', label: t.wellbeing, shortLabel: language === 'en' ? 'Well-Being' : t.wellbeing, icon: BarChart3 },
    { id: 'citizenPortal', label: t.citizenPortal, shortLabel: language === 'en' ? 'Citizen Portal' : t.citizenPortal, icon: UserCheck },
    { id: 'adminPortal', label: t.adminPortal, shortLabel: language === 'en' ? 'Admin Hub' : t.adminPortal, icon: ShieldAlert, badge: 'Role Access' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      {/* Top Advisory Bar */}
      <div className="bg-slate-900 dark:bg-slate-950 text-white text-xs px-4 py-1.5 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="bg-emerald-500 text-slate-950 font-bold px-1.5 py-0.5 rounded text-[10px] uppercase tracking-wider shrink-0">
            OFFICIAL PORTAL
          </span>
          <span className="text-slate-300 truncate text-[11px]">
            {t.demoNotice}
          </span>
        </div>

        <div className="flex items-center gap-3 sm:gap-4 shrink-0 text-slate-300 text-[11px]">
          <span className="hidden sm:inline">24x7 Emergency: <strong>108 / 100</strong></span>
          
          {/* Quick Theme Toggle (Top bar) */}
          <button
            type="button"
            onClick={onToggleTheme}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 px-2 py-0.5 rounded border border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title={theme === 'dark' ? t.lightMode : t.darkMode}
            aria-label={theme === 'dark' ? t.lightMode : t.darkMode}
          >
            {theme === 'dark' ? (
              <>
                <Sun className="w-3 h-3 text-amber-400" />
                <span className="text-[11px] font-medium hidden md:inline">{t.lightMode}</span>
              </>
            ) : (
              <>
                <Moon className="w-3 h-3 text-teal-300" />
                <span className="text-[11px] font-medium hidden md:inline">{t.darkMode}</span>
              </>
            )}
          </button>

          {/* Language Switcher */}
          <div className="flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
            <Globe className="w-3 h-3 text-teal-400" />
            <button
              type="button"
              onClick={() => setLanguage('en')}
              className={`hover:text-white ${language === 'en' ? 'font-bold text-teal-300' : 'text-slate-400'}`}
            >
              EN
            </button>
            <span className="text-slate-600">|</span>
            <button
              type="button"
              onClick={() => setLanguage('te')}
              className={`hover:text-white ${language === 'te' ? 'font-bold text-teal-300' : 'text-slate-400'}`}
            >
              తెలుగు
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-5">
        <div className="flex items-center justify-between gap-2 h-16">
          
          {/* Brand Logo & Tagline */}
          <div 
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-2 cursor-pointer group shrink-0"
          >
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-white border border-slate-200 dark:border-slate-700 flex items-center justify-center shadow-sm overflow-hidden group-hover:scale-105 transition-transform shrink-0">
              <img
                src="/assets/aistudio/ideal_d2f8ccb0.jpeg"
                alt="IDEAL CITY 360 Logo"
                data-testid="app-logo-navbar"
                className="w-full h-full object-contain scale-110"
              />
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="font-extrabold text-slate-900 dark:text-white text-sm sm:text-lg tracking-tight whitespace-nowrap">
                  IDEAL CITY
                </span>
                <span className="bg-emerald-600 text-white text-[10px] sm:text-[11px] font-black px-1.5 py-0.5 rounded tracking-wide">360</span>
              </div>
              <p className="hidden sm:block text-[9px] font-semibold text-teal-700 dark:text-teal-400 tracking-wide uppercase whitespace-nowrap">
                {t.tagline}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-0.5 min-w-0">
            {navItems.slice(0, 7).map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  title={item.label}
                  onClick={() => setActiveTab(item.id)}
                  className={`px-1.5 py-1.5 rounded-lg text-[11.5px] font-semibold flex items-center gap-1 whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
                    isActive
                      ? 'bg-teal-50 dark:bg-teal-950/70 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-teal-600 dark:text-teal-400' : 'text-slate-400 dark:text-slate-500'}`} />
                  <span>{item.shortLabel}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Toolbar */}
          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            
            {/* Ask IDEAL AI Button */}
            <button
              type="button"
              onClick={() => onOpenAiAssistant()}
              className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white text-xs font-bold px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl shadow-xs flex items-center gap-1.5 transition-all hover:shadow-md cursor-pointer whitespace-nowrap"
            >
              <Bot className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">{t.assistantBtn}</span>
              <span className="sm:hidden">AI</span>
            </button>

            {/* Dark / Light Mode Theme Toggle Button */}
            <button
              type="button"
              onClick={onToggleTheme}
              className="p-1.5 sm:p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl relative transition-colors cursor-pointer border border-transparent dark:border-slate-800"
              title={theme === 'dark' ? t.lightMode : t.darkMode}
              aria-label={theme === 'dark' ? t.lightMode : t.darkMode}
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5 text-amber-400 hover:rotate-45 transition-transform" />
              ) : (
                <Moon className="w-5 h-5 text-slate-600 hover:-rotate-12 transition-transform" />
              )}
            </button>

            {/* Notifications Menu */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setNotifMenuOpen(!notifMenuOpen)}
                className="p-1.5 sm:p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl relative transition-colors cursor-pointer border border-transparent dark:border-slate-800"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-rose-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              {notifMenuOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 p-3 z-50 animate-in fade-in zoom-in-95">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                    <span className="font-bold text-xs text-slate-900 dark:text-white">City Announcements & Updates</span>
                    <span className="text-[10px] text-teal-700 dark:text-teal-400 font-semibold">{unreadCount} New</span>
                  </div>
                  <div className="mt-2 space-y-2 max-h-64 overflow-y-auto">
                    {notifications.map(n => (
                      <div key={n.id} className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/80 hover:bg-teal-50/50 dark:hover:bg-slate-700/60 text-xs border border-slate-100 dark:border-slate-700/60 transition-colors">
                        <div className="font-semibold text-slate-800 dark:text-slate-200">{n.title}</div>
                        <div className="text-slate-500 dark:text-slate-400 text-[11px] mt-0.5">{n.message}</div>
                        <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">{new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Role Switcher Pill */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setRoleMenuOpen(!roleMenuOpen)}
                className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-xs cursor-pointer shrink-0"
              >
                <div className="w-6 h-6 rounded-full bg-slate-900 dark:bg-teal-700 text-white flex items-center justify-center font-bold text-[10px]">
                  {currentUser.name.charAt(0)}
                </div>
                <div className="hidden md:block text-left">
                  <div className="font-bold text-slate-800 dark:text-slate-200 text-[11px] leading-tight flex items-center gap-1">
                    <span className="max-w-[115px] truncate">{currentUser.name}</span>
                    <ChevronDown className="w-3 h-3 text-slate-400 shrink-0" />
                  </div>
                  <div className="text-[10px] text-teal-700 dark:text-teal-400 font-medium capitalize truncate max-w-[125px]">
                    {currentRoleObj.label}
                  </div>
                </div>
              </button>

              {roleMenuOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 p-3 z-50 animate-in fade-in zoom-in-95">
                  <div className="pb-2 border-b border-slate-100 dark:border-slate-800">
                    <span className="font-bold text-xs text-slate-900 dark:text-white block">Switch Demo Persona / Role</span>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500">Test platform permissions and admin workflows</span>
                  </div>
                  <div className="mt-2 space-y-1">
                    {roleOptions.map(opt => (
                      <button
                        key={opt.role}
                        type="button"
                        onClick={() => {
                          onSwitchUserRole(opt.role);
                          setRoleMenuOpen(false);
                        }}
                        className={`w-full text-left p-2 rounded-lg text-xs flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors ${
                          currentUser.role === opt.role ? 'bg-teal-50 dark:bg-teal-950/70 font-bold text-teal-900 dark:text-teal-300' : 'text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <div>
                          <div className="font-semibold">{opt.name}</div>
                          <div className="text-[10px] text-slate-400 dark:text-slate-500">{opt.label} • {opt.email}</div>
                        </div>
                        {currentUser.role === opt.role && <Check className="w-4 h-4 text-teal-600 dark:text-teal-400" />}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Mobile Menu Trigger */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

          </div>

        </div>
      </div>

      {/* Secondary Quick Nav Bar for Portals & Well-Being */}
      <div className="hidden xl:block bg-slate-50 dark:bg-slate-900/90 border-t border-slate-200 dark:border-slate-800 px-6 py-1.5 text-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4 text-slate-600 dark:text-slate-400">
            <span className="font-bold text-slate-400 dark:text-slate-500 uppercase text-[10px] tracking-wider">Fast Navigation:</span>
            <button
              type="button"
              data-testid="navbar-report-accident-btn"
              onClick={() => setActiveTab('accidentAlert')}
              className={`px-2.5 py-1 rounded-lg font-extrabold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'accidentAlert'
                  ? 'bg-red-700 text-white shadow-xs'
                  : 'bg-red-600 hover:bg-red-700 text-white'
              }`}
            >
              <Siren className="w-3.5 h-3.5 shrink-0" />
              <span>REPORT ACCIDENT (ANONYMOUS)</span>
            </button>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <button 
              type="button"
              onClick={() => setActiveTab('wellbeing')} 
              className={`hover:text-teal-800 dark:hover:text-teal-300 flex items-center gap-1 ${activeTab === 'wellbeing' ? 'font-bold text-teal-700 dark:text-teal-400' : ''}`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" /> City Well-Being Index (88%)
            </button>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <button 
              type="button"
              onClick={() => setActiveTab('citizenPortal')} 
              className={`hover:text-teal-800 dark:hover:text-teal-300 flex items-center gap-1 ${activeTab === 'citizenPortal' ? 'font-bold text-teal-700 dark:text-teal-400' : ''}`}
            >
              <UserCheck className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" /> Citizen Portal & Complaints
            </button>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <button 
              type="button"
              onClick={() => setActiveTab('adminPortal')} 
              className={`hover:text-teal-800 dark:hover:text-teal-300 flex items-center gap-1 ${activeTab === 'adminPortal' ? 'font-bold text-teal-700 dark:text-teal-400' : ''}`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" /> Administration Hub (Role Controls)
            </button>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Central Information Hub: <strong className="text-slate-700 dark:text-slate-300">Online & Audited</strong></span>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 pt-2 pb-6 space-y-1">
          <button
            type="button"
            data-testid="mobile-report-accident-btn"
            onClick={() => {
              setActiveTab('accidentAlert');
              setMobileMenuOpen(false);
            }}
            className="w-full mb-2 px-3 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-extrabold flex items-center justify-center gap-2 shadow-xs cursor-pointer"
          >
            <Siren className="w-4 h-4" />
            <span>REPORT ACCIDENT ANONYMOUSLY (SOS)</span>
          </button>
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-between ${
                  isActive
                    ? 'bg-teal-50 dark:bg-teal-950/70 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-teal-600 dark:text-teal-400' : 'text-slate-400 dark:text-slate-500'}`} />
                  {item.label}
                </div>
                {item.badge && (
                  <span className="text-[10px] bg-purple-100 dark:bg-purple-950/80 text-purple-800 dark:text-purple-300 font-bold px-2 py-0.5 rounded">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          {/* Mobile Theme Switcher Bar */}
          <div className="pt-3 mt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between px-3">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Theme</span>
            <button
              type="button"
              onClick={onToggleTheme}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span>{t.lightMode}</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-slate-600" />
                  <span>{t.darkMode}</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
