import React, { useEffect, useState } from 'react';
import {
  BloodBank,
  BloodDonationPledge,
  BloodGroup,
  BloodRequest,
  DonorLeaderboardEntry,
  Hospital,
  User
} from '../types';
import { VerificationBadge } from './VerificationBadge';
import { StarDonorLeaderboard } from './StarDonorPanel';
import { UrgentBloodRequestsMap } from './UrgentBloodRequestsMap';
import {
  BLOOD_GROUPS,
  filterBloodBanks,
  getCompatibleDonorGroups,
  getStockLevelStatus,
  getTotalCityUnits,
  getTotalUnitsByGroup,
  validateBloodDonation,
  validateBloodRequest
} from '../utils/bloodBank';
import {
  Droplet,
  HeartHandshake,
  Phone,
  MapPin,
  Clock,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  X,
  Calendar,
  Building2,
  Activity,
  Info,
  Trophy
} from 'lucide-react';

interface Props {
  bloodBanks: BloodBank[];
  bloodRequests: BloodRequest[];
  bloodDonations: BloodDonationPledge[];
  donorLeaderboard: DonorLeaderboardEntry[];
  hospitals: Hospital[];
  currentUser: User;
  searchQuery: string;
  selectedZone: string;
  onSubmitBloodRequest: (req: Omit<BloodRequest, 'id' | 'requestCode' | 'status' | 'createdAt'>) => Promise<void> | void;
  onSubmitBloodDonation: (don: Omit<BloodDonationPledge, 'id' | 'pledgeCode' | 'status' | 'createdAt'>) => Promise<void> | void;
  onCompleteDonation: (donationId: string) => void;
  openModalSignal?: 'request' | 'donate' | null;
  onClearModalSignal?: () => void;
}

export const BloodBankSection: React.FC<Props> = ({
  bloodBanks,
  bloodRequests,
  bloodDonations,
  donorLeaderboard,
  hospitals,
  currentUser,
  searchQuery,
  selectedZone,
  onSubmitBloodRequest,
  onSubmitBloodDonation,
  onCompleteDonation,
  openModalSignal,
  onClearModalSignal
}) => {
  const [selectedGroup, setSelectedGroup] = useState<BloodGroup | 'all'>('all');
  const [activityTab, setActivityTab] = useState<'requests' | 'donations' | 'leaderboard'>('requests');
  const [activeModal, setActiveModal] = useState<'request' | 'donate' | null>(null);

  // Request Blood form state
  const [reqForm, setReqForm] = useState({
    patientName: '',
    bloodGroup: 'O-' as BloodGroup,
    unitsNeeded: 1,
    urgency: 'Emergency' as 'Emergency' | 'Urgent' | 'Scheduled',
    hospitalName: hospitals[0]?.name || '',
    bloodBankId: bloodBanks[0]?.id || '',
    contactName: currentUser.name || '',
    contactPhone: currentUser.phone || '',
    notes: ''
  });
  const [reqErrors, setReqErrors] = useState<Record<string, string>>({});
  const [reqSubmitting, setReqSubmitting] = useState(false);

  // Donate Blood form state
  const [donForm, setDonForm] = useState({
    donorName: currentUser.name || '',
    bloodGroup: 'O+' as BloodGroup,
    age: 26,
    weightKg: 62,
    phone: currentUser.phone || '',
    email: currentUser.email || '',
    preferredBankId: bloodBanks[0]?.id || '',
    preferredDate: '2026-11-22',
    preferredSlot: '10:00 AM - 12:00 PM',
    monthsSinceLastDonation: 6
  });
  const [donErrors, setDonErrors] = useState<Record<string, string>>({});
  const [donSubmitting, setDonSubmitting] = useState(false);

  useEffect(() => {
    if (openModalSignal) {
      setActiveModal(openModalSignal);
      onClearModalSignal?.();
    }
  }, [openModalSignal, onClearModalSignal]);

  const totalsByGroup = getTotalUnitsByGroup(bloodBanks);
  const totalCityUnits = getTotalCityUnits(bloodBanks);
  const filteredBanks = filterBloodBanks(bloodBanks, searchQuery, selectedGroup, selectedZone);
  const compatibleDonors = getCompatibleDonorGroups(reqForm.bloodGroup);

  const openRequestForBank = (bank?: BloodBank) => {
    setReqErrors({});
    setReqForm(prev => ({
      ...prev,
      bloodBankId: bank?.id || prev.bloodBankId || bloodBanks[0]?.id || '',
      hospitalName: bank
        ? (hospitals.find(h => h.id === bank.hospitalId)?.name || bank.name)
        : (prev.hospitalName || hospitals[0]?.name || '')
    }));
    setActiveModal('request');
  };

  const openDonateForBank = (bank?: BloodBank) => {
    setDonErrors({});
    setDonForm(prev => ({
      ...prev,
      preferredBankId: bank?.id || prev.preferredBankId || bloodBanks[0]?.id || ''
    }));
    setActiveModal('donate');
  };

  const openDonateForUrgentRequest = (request: BloodRequest, resolvedBankId?: string) => {
    setDonErrors({});
    const targetBankId =
      resolvedBankId ||
      request.bloodBankId ||
      bloodBanks[0]?.id ||
      '';
    setDonForm(prev => ({
      ...prev,
      preferredBankId: targetBankId,
      bloodGroup: currentUser.bloodGroup || prev.bloodGroup
    }));
    setActiveModal('donate');
  };

  const handleRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateBloodRequest({
      patientName: reqForm.patientName,
      bloodGroup: reqForm.bloodGroup,
      unitsNeeded: Number(reqForm.unitsNeeded),
      urgency: reqForm.urgency,
      hospitalName: reqForm.hospitalName,
      contactName: reqForm.contactName,
      contactPhone: reqForm.contactPhone,
      notes: reqForm.notes
    });
    if (!validation.valid) {
      setReqErrors(validation.errors);
      return;
    }

    setReqErrors({});
    setReqSubmitting(true);
    try {
      await onSubmitBloodRequest({
        patientName: reqForm.patientName.trim(),
        bloodGroup: reqForm.bloodGroup,
        unitsNeeded: Number(reqForm.unitsNeeded),
        urgency: reqForm.urgency,
        hospitalName: reqForm.hospitalName.trim(),
        bloodBankId: reqForm.bloodBankId || undefined,
        contactName: reqForm.contactName.trim(),
        contactPhone: reqForm.contactPhone.trim(),
        notes: reqForm.notes.trim() || undefined
      });
      setReqForm(prev => ({
        ...prev,
        patientName: '',
        unitsNeeded: 1,
        notes: ''
      }));
      setActivityTab('requests');
      setActiveModal(null);
    } finally {
      setReqSubmitting(false);
    }
  };

  const handleDonationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateBloodDonation({
      donorName: donForm.donorName,
      bloodGroup: donForm.bloodGroup,
      age: Number(donForm.age),
      weightKg: Number(donForm.weightKg),
      phone: donForm.phone,
      email: donForm.email,
      preferredBankId: donForm.preferredBankId,
      preferredDate: donForm.preferredDate,
      preferredSlot: donForm.preferredSlot,
      monthsSinceLastDonation: Number(donForm.monthsSinceLastDonation)
    });
    if (!validation.valid) {
      setDonErrors(validation.errors);
      return;
    }

    setDonErrors({});
    setDonSubmitting(true);
    try {
      const selectedBank = bloodBanks.find(b => b.id === donForm.preferredBankId);
      await onSubmitBloodDonation({
        donorName: donForm.donorName.trim(),
        bloodGroup: donForm.bloodGroup,
        age: Number(donForm.age),
        weightKg: Number(donForm.weightKg),
        phone: donForm.phone.trim(),
        email: donForm.email.trim() || undefined,
        preferredBankId: donForm.preferredBankId,
        preferredBankName: selectedBank?.name || 'City Verified Blood Bank',
        preferredDate: donForm.preferredDate,
        preferredSlot: donForm.preferredSlot
      });
      setActivityTab('donations');
      setActiveModal(null);
    } finally {
      setDonSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Action & Citywide Inventory Overview */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                <Droplet className="w-3.5 h-3.5 fill-current" />
                Live City Blood Bank Registry
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {totalCityUnits} Verified Units Across {bloodBanks.length} Centers
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
              Real-Time Blood Availability, Emergency Requests & Voluntary Donation
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Select a blood group below to filter banks with available stock, submit an urgent blood request, or pledge a donation slot.
            </p>
          </div>

          {/* Primary CTAs: Request Blood & Donate Blood */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => openRequestForBank()}
              className="flex-1 sm:flex-none bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl shadow-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Droplet className="w-4 h-4 fill-current" />
              <span>Request Blood</span>
            </button>
            <button
              type="button"
              onClick={() => openDonateForBank()}
              className="flex-1 sm:flex-none bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl shadow-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <HeartHandshake className="w-4 h-4" />
              <span>Donate Blood</span>
            </button>
          </div>
        </div>

        {/* Blood Group Filter Strip */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300">Filter by Blood Group Stock</span>
            {selectedGroup !== 'all' && (
              <button
                type="button"
                onClick={() => setSelectedGroup('all')}
                className="text-teal-700 dark:text-teal-400 font-semibold hover:underline cursor-pointer"
              >
                Show All Blood Groups
              </button>
            )}
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-9 gap-2">
            <button
              type="button"
              onClick={() => setSelectedGroup('all')}
              className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                selectedGroup === 'all'
                  ? 'bg-slate-900 dark:bg-teal-600 text-white border-slate-900 dark:border-teal-500 shadow-xs'
                  : 'bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
              }`}
            >
              <div className="text-xs font-extrabold">ALL</div>
              <div className={`text-[10px] mt-0.5 ${selectedGroup === 'all' ? 'text-slate-200' : 'text-slate-500 dark:text-slate-400'}`}>
                {totalCityUnits} u
              </div>
            </button>
            {BLOOD_GROUPS.map(group => {
              const units = totalsByGroup[group];
              const status = getStockLevelStatus(units);
              const isSelected = selectedGroup === group;
              return (
                <button
                  key={group}
                  type="button"
                  onClick={() => setSelectedGroup(isSelected ? 'all' : group)}
                  aria-label={`Filter blood group ${group}, ${units} units available`}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                      : 'bg-slate-50 dark:bg-slate-800/80 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:border-rose-400'
                  }`}
                >
                  <div className="text-xs font-extrabold">{group}</div>
                  <div
                    className={`text-[10px] font-bold mt-0.5 ${
                      isSelected
                        ? 'text-rose-100'
                        : status === 'Critical'
                        ? 'text-rose-600 dark:text-rose-400'
                        : status === 'Low'
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-emerald-600 dark:text-emerald-400'
                    }`}
                  >
                    {units} units
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Nearby Urgent Blood Requests Map Visualization */}
      <UrgentBloodRequestsMap
        bloodRequests={bloodRequests}
        bloodBanks={bloodBanks}
        hospitals={hospitals}
        currentUser={currentUser}
        selectedGroup={selectedGroup}
        selectedZone={selectedZone}
        onDonateForRequest={openDonateForUrgentRequest}
      />

      {/* Verified Blood Banks Directory */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Building2 className="w-5 h-5 text-rose-600 dark:text-rose-400" />
            <span>Verified Municipal & Hospital Blood Banks ({filteredBanks.length})</span>
          </h3>
          <div className="flex items-center gap-3 text-[11px] text-slate-500 dark:text-slate-400">
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500" /> Available (&gt;10)</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-500" /> Low (4–10)</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-rose-500" /> Critical (0–3)</span>
          </div>
        </div>

        {filteredBanks.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 text-center space-y-2">
            <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto" />
            <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
              No blood banks match your current search or blood group filter.
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Try clearing the filter or submit an emergency Blood Request so city dispatch can alert registered donors.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredBanks.map(bank => (
              <div
                key={bank.id}
                className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4 hover:border-rose-400 dark:hover:border-rose-500 transition-all"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex flex-wrap items-center gap-1.5 mb-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                          {bank.zone}
                        </span>
                        {bank.is24x7 && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                            24x7 Emergency
                          </span>
                        )}
                        {bank.componentSeparation && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-50 dark:bg-sky-950/70 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800">
                            PRBC / Platelets / Plasma
                          </span>
                        )}
                      </div>
                      <h4 className="font-bold text-slate-900 dark:text-white text-base leading-snug">
                        {bank.name}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 flex items-start gap-1 mt-1">
                        <MapPin className="w-3.5 h-3.5 shrink-0 mt-0.5 text-slate-400" />
                        <span>{bank.address}</span>
                      </p>
                    </div>
                  </div>

                  {/* 8-Blood-Group Stock Matrix */}
                  <div className="grid grid-cols-4 gap-2 bg-slate-50 dark:bg-slate-800/70 p-3 rounded-xl border border-slate-100 dark:border-slate-700/80">
                    {BLOOD_GROUPS.map(group => {
                      const units = bank.inventory[group];
                      const status = getStockLevelStatus(units);
                      const isHighlighted = selectedGroup === group;
                      return (
                        <div
                          key={group}
                          className={`rounded-lg p-2 text-center border ${
                            isHighlighted
                              ? 'bg-rose-600 text-white border-rose-600'
                              : status === 'Critical'
                              ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-200 dark:border-rose-800/80'
                              : status === 'Low'
                              ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800/70'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          <div className={`text-xs font-extrabold ${isHighlighted ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                            {group}
                          </div>
                          <div
                            className={`text-[11px] font-bold ${
                              isHighlighted
                                ? 'text-rose-100'
                                : status === 'Critical'
                                ? 'text-rose-700 dark:text-rose-300'
                                : status === 'Low'
                                ? 'text-amber-700 dark:text-amber-300'
                                : 'text-emerald-700 dark:text-emerald-400'
                            }`}
                          >
                            {units} u
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{bank.openHours}</span>
                    </div>
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-rose-700 dark:text-rose-400 font-semibold flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 shrink-0" /> Emergency: {bank.emergencyPhone}
                      </span>
                      <span className="text-[11px] text-slate-400 dark:text-slate-500">
                        License: {bank.licenseNumber}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <VerificationBadge verification={bank.verification} showDetails={false} />
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => openRequestForBank(bank)}
                      className="bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-600 text-rose-700 dark:text-rose-300 hover:text-white border border-rose-200 dark:border-rose-800 text-xs font-bold py-2 px-3 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Droplet className="w-3.5 h-3.5" />
                      <span>Request Here</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => openDonateForBank(bank)}
                      className="bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-600 text-emerald-700 dark:text-emerald-300 hover:text-white border border-emerald-200 dark:border-emerald-800 text-xs font-bold py-2 px-3 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <HeartHandshake className="w-3.5 h-3.5" />
                      <span>Donate Here</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Live Citizen Activity Tracker: Active Requests & Scheduled Donor Pledges */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>Blood Dispatch Requests & Donor Pledges</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Live status of active hospital blood requests and confirmed voluntary donor appointments
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl self-start sm:self-auto">
            <button
              type="button"
              onClick={() => setActivityTab('requests')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                activityTab === 'requests'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Active Requests ({bloodRequests.length})
            </button>
            <button
              type="button"
              onClick={() => setActivityTab('donations')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                activityTab === 'donations'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Donor Pledges ({bloodDonations.length})
            </button>
            <button
              type="button"
              onClick={() => setActivityTab('leaderboard')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer ${
                activityTab === 'leaderboard'
                  ? 'bg-amber-500 text-slate-950 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>Star Donor Leaderboard</span>
            </button>
          </div>
        </div>

        {activityTab === 'requests' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3" data-testid="blood-requests-list">
            {bloodRequests.map(req => (
              <div
                key={req.id}
                className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-lg bg-rose-600 text-white text-xs font-black">
                      {req.bloodGroup}
                    </span>
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white text-sm">{req.patientName}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {req.requestCode} • {req.unitsNeeded} {req.unitsNeeded === 1 ? 'Unit' : 'Units'} Needed
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        req.urgency === 'Emergency'
                          ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300'
                          : req.urgency === 'Urgent'
                          ? 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                          : 'bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300'
                      }`}
                    >
                      {req.urgency}
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        req.status === 'Matched' || req.status === 'Fulfilled'
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {req.status}
                    </span>
                  </div>
                </div>

                <div className="text-xs text-slate-600 dark:text-slate-300 space-y-0.5 pt-1">
                  <div><strong>Hospital:</strong> {req.hospitalName}</div>
                  <div><strong>Attendant:</strong> {req.contactName} ({req.contactPhone})</div>
                  {req.notes && <div className="text-slate-500 dark:text-slate-400 italic">{req.notes}</div>}
                </div>
              </div>
            ))}
          </div>
        ) : activityTab === 'donations' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3" data-testid="blood-donations-list">
            {bloodDonations.map(don => (
              <div
                key={don.id}
                className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex flex-col justify-between gap-2"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-xs font-black">
                        {don.bloodGroup}
                      </span>
                      <div>
                        <div className="font-bold text-slate-900 dark:text-white text-sm">{don.donorName}</div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">
                          {don.pledgeCode} • Age {don.age} • {don.weightKg} kg
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                      {don.status}
                    </span>
                  </div>

                  <div className="text-xs text-slate-600 dark:text-slate-300 space-y-0.5 pt-1">
                    <div><strong>Center:</strong> {don.preferredBankName}</div>
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                      <span>{don.preferredDate} • {don.preferredSlot}</span>
                    </div>
                  </div>
                </div>

                {don.status === 'Scheduled' && (
                  <button
                    type="button"
                    onClick={() => onCompleteDonation(don.id)}
                    className="mt-1 w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-1.5 px-3 rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Mark Completed (+1 Star Donor Credit)</span>
                  </button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <StarDonorLeaderboard
            donorLeaderboard={donorLeaderboard}
            bloodDonations={bloodDonations}
            currentUser={currentUser}
          />
        )}
      </div>

      {/* REQUEST BLOOD MODAL */}
      {activeModal === 'request' && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-labelledby="request-blood-title"
        >
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full p-5 sm:p-6 border border-slate-200 dark:border-slate-800 my-auto max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 flex items-center justify-center">
                  <Droplet className="w-4 h-4 fill-current" />
                </div>
                <div>
                  <h3 id="request-blood-title" className="font-bold text-slate-900 dark:text-white text-base">
                    Request Blood Units
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Dispatched to verified municipal blood banks & emergency desk
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                aria-label="Close Request Blood dialog"
                className="text-slate-400 hover:text-slate-700 dark:hover:text-white p-1.5 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRequestSubmit} noValidate className="mt-4 space-y-3 text-xs">
              <div>
                <label htmlFor="req-patient-name" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Patient Full Name *
                </label>
                <input
                  id="req-patient-name"
                  type="text"
                  value={reqForm.patientName}
                  onChange={e => setReqForm({ ...reqForm, patientName: e.target.value })}
                  placeholder="e.g. Ramesh Naidu"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-rose-500"
                />
                {reqErrors.patientName && (
                  <p role="alert" className="text-rose-600 dark:text-rose-400 mt-1 text-[11px] font-medium">
                    {reqErrors.patientName}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="req-blood-group" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Blood Group *
                  </label>
                  <select
                    id="req-blood-group"
                    value={reqForm.bloodGroup}
                    onChange={e => setReqForm({ ...reqForm, bloodGroup: e.target.value as BloodGroup })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  >
                    {BLOOD_GROUPS.map(g => (
                      <option key={g} value={g}>{g} ({totalsByGroup[g]} u in city)</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="req-units" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Units Needed *
                  </label>
                  <input
                    id="req-units"
                    type="number"
                    min={1}
                    max={10}
                    value={reqForm.unitsNeeded}
                    onChange={e => setReqForm({ ...reqForm, unitsNeeded: parseInt(e.target.value, 10) || 0 })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  />
                  {reqErrors.unitsNeeded && (
                    <p role="alert" className="text-rose-600 dark:text-rose-400 mt-1 text-[11px] font-medium">
                      {reqErrors.unitsNeeded}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="req-urgency" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Urgency Level *
                  </label>
                  <select
                    id="req-urgency"
                    value={reqForm.urgency}
                    onChange={e => setReqForm({ ...reqForm, urgency: e.target.value as 'Emergency' | 'Urgent' | 'Scheduled' })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  >
                    <option value="Emergency">Emergency (Immediate)</option>
                    <option value="Urgent">Urgent (Within 24h)</option>
                    <option value="Scheduled">Scheduled Surgery</option>
                  </select>
                </div>
              </div>

              {/* Compatible Donor Groups Info */}
              <div className="bg-rose-50/70 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/70 rounded-xl p-2.5 flex items-start gap-2">
                <Info className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
                <div className="text-[11px] text-rose-900 dark:text-rose-200">
                  <strong>Compatible Donor Groups for {reqForm.bloodGroup}:</strong>{' '}
                  {compatibleDonors.join(', ')}
                </div>
              </div>

              <div>
                <label htmlFor="req-hospital" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Hospital / Treatment Facility *
                </label>
                <input
                  id="req-hospital"
                  type="text"
                  value={reqForm.hospitalName}
                  onChange={e => setReqForm({ ...reqForm, hospitalName: e.target.value })}
                  placeholder="Enter hospital name and ward"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                />
                {reqErrors.hospitalName && (
                  <p role="alert" className="text-rose-600 dark:text-rose-400 mt-1 text-[11px] font-medium">
                    {reqErrors.hospitalName}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="req-contact-name" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Attendant / Contact Name *
                  </label>
                  <input
                    id="req-contact-name"
                    type="text"
                    value={reqForm.contactName}
                    onChange={e => setReqForm({ ...reqForm, contactName: e.target.value })}
                    placeholder="Contact person name"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  />
                  {reqErrors.contactName && (
                    <p role="alert" className="text-rose-600 dark:text-rose-400 mt-1 text-[11px] font-medium">
                      {reqErrors.contactName}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="req-contact-phone" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Contact Phone *
                  </label>
                  <input
                    id="req-contact-phone"
                    type="tel"
                    value={reqForm.contactPhone}
                    onChange={e => setReqForm({ ...reqForm, contactPhone: e.target.value })}
                    placeholder="+91 98480 11223"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  />
                  {reqErrors.contactPhone && (
                    <p role="alert" className="text-rose-600 dark:text-rose-400 mt-1 text-[11px] font-medium">
                      {reqErrors.contactPhone}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label htmlFor="req-notes" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Clinical Notes / Ward Info (Optional)
                </label>
                <textarea
                  id="req-notes"
                  rows={2}
                  value={reqForm.notes}
                  onChange={e => setReqForm({ ...reqForm, notes: e.target.value })}
                  placeholder="Component type (Whole Blood / PRBC / Platelets), ICU ward, or requisition slip number"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded-xl font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={reqSubmitting}
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-60 text-white rounded-xl font-bold shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{reqSubmitting ? 'Submitting...' : 'Submit Blood Request'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DONATE BLOOD MODAL */}
      {activeModal === 'donate' && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-labelledby="donate-blood-title"
        >
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full p-5 sm:p-6 border border-slate-200 dark:border-slate-800 my-auto max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <HeartHandshake className="w-4 h-4" />
                </div>
                <div>
                  <h3 id="donate-blood-title" className="font-bold text-slate-900 dark:text-white text-base">
                    Donate Blood — Schedule Appointment
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Voluntary blood donation at licensed municipal & Red Cross centers
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                aria-label="Close Donate Blood dialog"
                className="text-slate-400 hover:text-slate-700 dark:hover:text-white p-1.5 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleDonationSubmit} noValidate className="mt-4 space-y-3 text-xs">
              <div className="bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/70 rounded-xl p-2.5 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-[11px] text-emerald-900 dark:text-emerald-200">
                  <strong>Eligibility Guidelines:</strong> Healthy citizens aged 18–65 years, minimum weight 50 kg, and at least 3 months since last donation.
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="don-name" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Donor Full Name *
                  </label>
                  <input
                    id="don-name"
                    type="text"
                    value={donForm.donorName}
                    onChange={e => setDonForm({ ...donForm, donorName: e.target.value })}
                    placeholder="e.g. Kavitha Reddy"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  />
                  {donErrors.donorName && (
                    <p role="alert" className="text-rose-600 dark:text-rose-400 mt-1 text-[11px] font-medium">
                      {donErrors.donorName}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="don-blood-group" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Blood Group *
                  </label>
                  <select
                    id="don-blood-group"
                    value={donForm.bloodGroup}
                    onChange={e => setDonForm({ ...donForm, bloodGroup: e.target.value as BloodGroup })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  >
                    {BLOOD_GROUPS.map(g => (
                      <option key={g} value={g}>{g}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label htmlFor="don-age" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Age (18–65) *
                  </label>
                  <input
                    id="don-age"
                    type="number"
                    value={donForm.age}
                    onChange={e => setDonForm({ ...donForm, age: parseInt(e.target.value, 10) || 0 })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  />
                  {donErrors.age && (
                    <p role="alert" className="text-rose-600 dark:text-rose-400 mt-1 text-[11px] font-medium">
                      {donErrors.age}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="don-weight" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Weight (kg) *
                  </label>
                  <input
                    id="don-weight"
                    type="number"
                    value={donForm.weightKg}
                    onChange={e => setDonForm({ ...donForm, weightKg: parseInt(e.target.value, 10) || 0 })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  />
                  {donErrors.weightKg && (
                    <p role="alert" className="text-rose-600 dark:text-rose-400 mt-1 text-[11px] font-medium">
                      {donErrors.weightKg}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="don-months" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Months Since Last
                  </label>
                  <input
                    id="don-months"
                    type="number"
                    min={0}
                    value={donForm.monthsSinceLastDonation}
                    onChange={e => setDonForm({ ...donForm, monthsSinceLastDonation: parseInt(e.target.value, 10) || 0 })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  />
                  {donErrors.monthsSinceLastDonation && (
                    <p role="alert" className="text-rose-600 dark:text-rose-400 mt-1 text-[11px] font-medium">
                      {donErrors.monthsSinceLastDonation}
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="don-phone" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Mobile Phone *
                  </label>
                  <input
                    id="don-phone"
                    type="tel"
                    value={donForm.phone}
                    onChange={e => setDonForm({ ...donForm, phone: e.target.value })}
                    placeholder="+91 98480 55667"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  />
                  {donErrors.phone && (
                    <p role="alert" className="text-rose-600 dark:text-rose-400 mt-1 text-[11px] font-medium">
                      {donErrors.phone}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="don-bank" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Preferred Blood Bank *
                  </label>
                  <select
                    id="don-bank"
                    value={donForm.preferredBankId}
                    onChange={e => setDonForm({ ...donForm, preferredBankId: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  >
                    {bloodBanks.map(b => (
                      <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="don-date" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Preferred Date *
                  </label>
                  <input
                    id="don-date"
                    type="date"
                    value={donForm.preferredDate}
                    onChange={e => setDonForm({ ...donForm, preferredDate: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  />
                  {donErrors.preferredDate && (
                    <p role="alert" className="text-rose-600 dark:text-rose-400 mt-1 text-[11px] font-medium">
                      {donErrors.preferredDate}
                    </p>
                  )}
                </div>

                <div>
                  <label htmlFor="don-slot" className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Time Slot *
                  </label>
                  <select
                    id="don-slot"
                    value={donForm.preferredSlot}
                    onChange={e => setDonForm({ ...donForm, preferredSlot: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-900 dark:text-white"
                  >
                    <option value="09:00 AM - 11:00 AM">09:00 AM - 11:00 AM</option>
                    <option value="10:00 AM - 12:00 PM">10:00 AM - 12:00 PM</option>
                    <option value="02:00 PM - 04:00 PM">02:00 PM - 04:00 PM</option>
                    <option value="04:00 PM - 06:00 PM">04:00 PM - 06:00 PM</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal(null)}
                  className="px-4 py-2 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded-xl font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={donSubmitting}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white rounded-xl font-bold shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <HeartHandshake className="w-4 h-4" />
                  <span>{donSubmitting ? 'Scheduling...' : 'Confirm Donation Pledge'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
