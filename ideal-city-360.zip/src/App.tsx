import React, { useState, useEffect } from 'react';
import { 
  User, 
  Hospital, 
  Doctor, 
  DoctorVisit, 
  HospitalVacancy, 
  HealthCamp,
  BloodBank,
  BloodRequest,
  BloodDonationPledge,
  DonorLeaderboardEntry,
  BusRoute, 
  BusSchedule, 
  TransportAlert, 
  GovernmentRule, 
  JobListing, 
  EducationService, 
  SocialWelfareService, 
  EmergencyContact, 
  Announcement, 
  Complaint, 
  CityWellBeingMetric, 
  NotificationItem,
  PoliceStation,
  AmbulanceUnit,
  AccidentReport,
  AccidentOverallStatus
} from './types';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { IdealAiChatModal } from './components/IdealAiChatModal';
import { HomePage } from './modules/HomePage';
import { HealthcareModule } from './modules/HealthcareModule';
import { TransportModule } from './modules/TransportModule';
import { GovernmentModule } from './modules/GovernmentModule';
import { EmploymentModule } from './modules/EmploymentModule';
import { EducationModule } from './modules/EducationModule';
import { SocialWelfareModule } from './modules/SocialWelfareModule';
import { CitizenPortal } from './modules/CitizenPortal';
import { AdminPortal } from './modules/AdminPortal';
import { AccidentEmergencyModule } from './modules/AccidentEmergencyModule';
import { WellBeingChart } from './components/WellBeingChart';
import { Language } from './utils/translations';
import { canRoleAccessAuthorityDashboard } from './utils/accidentEmergency';
import { CheckCircle2, AlertCircle, Bot, X } from 'lucide-react';

import {
  SEED_USERS,
  SEED_HOSPITALS,
  SEED_DOCTORS,
  SEED_DOCTOR_VISITS,
  SEED_VACANCIES,
  SEED_HEALTH_CAMPS,
  SEED_BLOOD_BANKS,
  SEED_BLOOD_REQUESTS,
  SEED_BLOOD_DONATIONS,
  SEED_DONOR_LEADERBOARD,
  SEED_BUS_ROUTES,
  SEED_BUS_SCHEDULES,
  SEED_TRANSPORT_ALERTS,
  SEED_GOVERNMENT_RULES,
  SEED_JOBS,
  SEED_EDUCATION,
  SEED_SOCIAL_WELFARE,
  SEED_EMERGENCY_CONTACTS,
  SEED_ANNOUNCEMENTS,
  SEED_COMPLAINTS,
  SEED_WELLBEING_METRICS,
  SEED_POLICE_STATIONS,
  SEED_AMBULANCE_UNITS
} from './data/seedData';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [language, setLanguage] = useState<Language>('en');
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('ideal_city_theme');
      if (saved === 'dark' || saved === 'light') return saved;
      if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        return 'dark';
      }
    }
    return 'light';
  });

  // Sync dark class on documentElement
  useEffect(() => {
    if (typeof document !== 'undefined') {
      if (theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('ideal_city_theme', theme);
    }
  }, [theme]);

  // Google Maps Platform quota defense listener
  const [gmpQuotaExceeded, setGmpQuotaExceeded] = useState(false);
  useEffect(() => {
    const handleQuota = () => setGmpQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handleQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', handleQuota);
  }, []);

  // Core Data Stores (initialized with realistic seeds, synced with backend APIs)
  const [currentUser, setCurrentUser] = useState<User>(SEED_USERS[0]);
  const [hospitals, setHospitals] = useState<Hospital[]>(SEED_HOSPITALS);
  const [doctors, setDoctors] = useState<Doctor[]>(SEED_DOCTORS);
  const [doctorVisits, setDoctorVisits] = useState<DoctorVisit[]>(SEED_DOCTOR_VISITS);
  const [vacancies, setVacancies] = useState<HospitalVacancy[]>(SEED_VACANCIES);
  const [healthCamps, setHealthCamps] = useState<HealthCamp[]>(SEED_HEALTH_CAMPS);
  const [bloodBanks, setBloodBanks] = useState<BloodBank[]>(SEED_BLOOD_BANKS);
  const [bloodRequests, setBloodRequests] = useState<BloodRequest[]>(SEED_BLOOD_REQUESTS);
  const [bloodDonations, setBloodDonations] = useState<BloodDonationPledge[]>(SEED_BLOOD_DONATIONS);
  const [donorLeaderboard, setDonorLeaderboard] = useState<DonorLeaderboardEntry[]>(SEED_DONOR_LEADERBOARD);
  const [healthcareSubTab, setHealthcareSubTab] = useState<'hospitals' | 'bloodBank' | undefined>(undefined);
  const [busRoutes, setBusRoutes] = useState<BusRoute[]>(SEED_BUS_ROUTES);
  const [busSchedules, setBusSchedules] = useState<BusSchedule[]>(SEED_BUS_SCHEDULES);
  const [transportAlerts, setTransportAlerts] = useState<TransportAlert[]>(SEED_TRANSPORT_ALERTS);
  const [governmentRules, setGovernmentRules] = useState<GovernmentRule[]>(SEED_GOVERNMENT_RULES);
  const [jobs, setJobs] = useState<JobListing[]>(SEED_JOBS);
  const [education, setEducation] = useState<EducationService[]>(SEED_EDUCATION);
  const [socialWelfare, setSocialWelfare] = useState<SocialWelfareService[]>(SEED_SOCIAL_WELFARE);
  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>(SEED_EMERGENCY_CONTACTS);
  const [announcements, setAnnouncements] = useState<Announcement[]>(SEED_ANNOUNCEMENTS);
  const [complaints, setComplaints] = useState<Complaint[]>(SEED_COMPLAINTS);
  const [wellbeingMetrics, setWellbeingMetrics] = useState<CityWellBeingMetric[]>(SEED_WELLBEING_METRICS);
  const [policeStations, setPoliceStations] = useState<PoliceStation[]>(SEED_POLICE_STATIONS);
  const [ambulanceUnits, setAmbulanceUnits] = useState<AmbulanceUnit[]>(SEED_AMBULANCE_UNITS);
  // Populated ONLY when signed in as an authorized emergency responder (zero unauthorized citizen exposure)
  const [accidentReports, setAccidentReports] = useState<AccidentReport[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([
    {
      id: 'log-1',
      timestamp: '2026-11-12T05:30:00Z',
      entityType: 'Hospital',
      entityId: 'hosp-1',
      action: 'Verification Audit',
      adminEmail: 'hospital.admin@idealcity360.gov.in',
      previousStatus: 'Pending',
      newStatus: 'Verified',
      notes: 'Bed counts and emergency equipment inspected and validated'
    }
  ]);

  // Notifications
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-1',
      userId: 'all',
      title: 'Water Supply Schedule Notice',
      message: 'Pipeline interconnection on Central Spine Nov 14. Dial 155313 for free water tanker dispatch.',
      type: 'alert',
      timestamp: new Date().toISOString(),
      read: false
    },
    {
      id: 'notif-2',
      userId: 'all',
      title: 'Visiting Cardiologist Confirmed',
      message: 'Dr. Anand Kumar Swaminathan consultation roster published for Nov 14 at Central Super-Specialty Hospital.',
      type: 'update',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      read: false
    }
  ]);

  // AI Assistant Modal
  const [aiModalOpen, setAiModalOpen] = useState(false);
  const [aiInitialQuestion, setAiInitialQuestion] = useState('');

  // Toast feedback state
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Sync with backend on startup
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [
          hospRes,
          visitsRes,
          vacRes,
          routesRes,
          schedRes,
          rulesRes,
          jobsRes,
          cmpRes,
          logsRes,
          bloodRes
        ] = await Promise.allSettled([
          fetch('/api/hospitals').then(r => r.json()),
          fetch('/api/doctor-visits').then(r => r.json()),
          fetch('/api/vacancies').then(r => r.json()),
          fetch('/api/transport/routes').then(r => r.json()),
          fetch('/api/transport/schedules').then(r => r.json()),
          fetch('/api/government/rules').then(r => r.json()),
          fetch('/api/jobs').then(r => r.json()),
          fetch('/api/complaints').then(r => r.json()),
          fetch('/api/verification/audit-logs').then(r => r.json()),
          fetch('/api/blood-banks').then(r => r.json())
        ]);

        if (hospRes.status === 'fulfilled' && hospRes.value.hospitals) setHospitals(hospRes.value.hospitals);
        if (visitsRes.status === 'fulfilled' && visitsRes.value.visits) setDoctorVisits(visitsRes.value.visits);
        if (vacRes.status === 'fulfilled' && vacRes.value.vacancies) setVacancies(vacRes.value.vacancies);
        if (routesRes.status === 'fulfilled' && routesRes.value.routes) setBusRoutes(routesRes.value.routes);
        if (schedRes.status === 'fulfilled' && schedRes.value.schedules) setBusSchedules(schedRes.value.schedules);
        if (rulesRes.status === 'fulfilled' && rulesRes.value.rules) setGovernmentRules(rulesRes.value.rules);
        if (jobsRes.status === 'fulfilled' && jobsRes.value.jobs) setJobs(jobsRes.value.jobs);
        if (cmpRes.status === 'fulfilled' && cmpRes.value.complaints) setComplaints(cmpRes.value.complaints);
        if (logsRes.status === 'fulfilled' && logsRes.value.auditLogs) setAuditLogs(logsRes.value.auditLogs);
        if (bloodRes.status === 'fulfilled') {
          if (bloodRes.value.bloodBanks) setBloodBanks(bloodRes.value.bloodBanks);
          if (bloodRes.value.requests) setBloodRequests(bloodRes.value.requests);
          if (bloodRes.value.donations) setBloodDonations(bloodRes.value.donations);
          if (bloodRes.value.leaderboard) setDonorLeaderboard(bloodRes.value.leaderboard);
        }
      } catch (e) {
        console.warn('Initial backend fetch fallback to local seed data');
      }
    };
    fetchData();
  }, []);

  const handleRefreshAccidents = async (overrideRole?: User['role']) => {
    const roleToCheck = overrideRole || currentUser.role;
    if (!canRoleAccessAuthorityDashboard(roleToCheck)) {
      setAccidentReports([]);
      return;
    }
    try {
      const res = await fetch('/api/accidents');
      if (!res.ok) {
        setAccidentReports([]);
        return;
      }
      const data = await res.json();
      if (data.reports) setAccidentReports(data.reports);
      if (data.policeStations) setPoliceStations(data.policeStations);
      if (data.ambulanceUnits) setAmbulanceUnits(data.ambulanceUnits);
    } catch {
      // keep existing state
    }
  };

  // Handlers
  const handleSwitchUserRole = async (role: string) => {
    try {
      const res = await fetch('/api/auth/switch-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role })
      });
      const data = await res.json();
      if (data.user) {
        setCurrentUser(data.user);
        showToast(`Switched active persona to ${data.user.name} (${data.user.role})`, 'info');
        if (canRoleAccessAuthorityDashboard(data.user.role)) {
          handleRefreshAccidents(data.user.role);
        } else {
          setAccidentReports([]);
        }
      }
    } catch {
      const found = SEED_USERS.find(u => u.role === role);
      if (found) {
        setCurrentUser(found);
        showToast(`Switched active persona to ${found.name}`, 'info');
        if (!canRoleAccessAuthorityDashboard(found.role)) {
          setAccidentReports([]);
        }
      }
    }
  };

  const handleAccidentSubmitted = (report: AccidentReport, _trackingToken: string) => {
    if (canRoleAccessAuthorityDashboard(currentUser.role)) {
      setAccidentReports(prev => [report, ...prev.filter(r => r.id !== report.id)]);
    }
    showToast(
      `Anonymous report ${report.incidentCode} confirmed! Save your secure tracking token to monitor live emergency response.`
    );
  };

  const handleUpdateAccidentResponse = async (
    reportId: string,
    payload: {
      agency: 'hospital' | 'ambulance' | 'police' | 'overall';
      status?: string;
      hospitalId?: string;
      etaMinutes?: number | null;
      bedsReserved?: number;
      notes?: string;
      overallStatus?: AccidentOverallStatus;
    }
  ) => {
    try {
      const res = await fetch(`/api/accidents/${reportId}/response`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok || !data.report) {
        showToast(data.error || 'Not authorized to update response status', 'error');
        return;
      }
      setAccidentReports(prev => prev.map(r => (r.id === reportId ? data.report : r)));
      showToast(`Emergency response updated (${payload.agency.toUpperCase()}) for ${data.report.incidentCode}.`);
    } catch {
      showToast('Failed to sync emergency response update with server', 'error');
    }
  };

  const handleBookToken = async (visitId: string) => {
    try {
      const res = await fetch(`/api/doctor-visits/${visitId}/book-token`, {
        method: 'POST'
      });
      const data = await res.json();
      if (data.success) {
        setDoctorVisits(prev => prev.map(v => v.id === visitId ? { ...v, bookedTokens: v.bookedTokens + 1 } : v));
        showToast(data.message || `Consultation token #${data.tokenNumber} reserved! Check citizen dashboard.`);
      } else {
        showToast(data.error || 'Unable to book token', 'error');
      }
    } catch {
      // Local fallback
      setDoctorVisits(prev => prev.map(v => v.id === visitId ? { ...v, bookedTokens: v.bookedTokens + 1 } : v));
      showToast('Consultation token confirmed! Please arrive 15 minutes before slot.');
    }
  };

  const handleSubmitBloodRequest = async (req: Omit<BloodRequest, 'id' | 'requestCode' | 'status' | 'createdAt'>) => {
    try {
      const res = await fetch('/api/blood-banks/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req)
      });
      const data = await res.json();
      if (data.success && data.request) {
        setBloodRequests(prev => [data.request, ...prev]);
        showToast(`Blood request ${data.request.requestCode} (${data.request.bloodGroup}) logged with municipal blood dispatch!`);
        return;
      }
      showToast(data.error || 'Unable to submit blood request', 'error');
    } catch {
      const localReq: BloodRequest = {
        ...req,
        id: `breq-${Date.now()}`,
        requestCode: `BLD-REQ-${Math.floor(10000 + Math.random() * 90000)}`,
        status: 'Pending',
        createdAt: new Date().toISOString()
      };
      setBloodRequests(prev => [localReq, ...prev]);
      showToast(`Blood request ${localReq.requestCode} (${localReq.bloodGroup}) logged!`);
    }
  };

  const handleSubmitBloodDonation = async (don: Omit<BloodDonationPledge, 'id' | 'pledgeCode' | 'status' | 'createdAt'>) => {
    try {
      const res = await fetch('/api/blood-banks/donations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(don)
      });
      const data = await res.json();
      if (data.success && data.donation) {
        setBloodDonations(prev => [data.donation, ...prev]);
        showToast(`Thank you! Donation pledge ${data.donation.pledgeCode} scheduled for ${data.donation.preferredDate}.`);
        return;
      }
      showToast(data.error || 'Unable to schedule blood donation', 'error');
    } catch {
      const localDon: BloodDonationPledge = {
        ...don,
        id: `bdon-${Date.now()}`,
        pledgeCode: `BLD-DON-${Math.floor(10000 + Math.random() * 90000)}`,
        status: 'Scheduled',
        createdAt: new Date().toISOString()
      };
      setBloodDonations(prev => [localDon, ...prev]);
      showToast(`Thank you! Donation pledge ${localDon.pledgeCode} scheduled.`);
    }
  };

  const handleCompleteDonation = async (donationId: string) => {
    try {
      const res = await fetch(`/api/blood-banks/donations/${donationId}/complete`, {
        method: 'POST'
      });
      const data = await res.json();
      if (data.success) {
        setBloodDonations(prev => prev.map(d => d.id === donationId ? { ...d, status: 'Completed' } : d));
        showToast('Donation verified as Completed! +1 added to Star Donor total & leaderboard.');
        return;
      }
      showToast(data.error || 'Could not update donation status', 'error');
    } catch {
      setBloodDonations(prev => prev.map(d => d.id === donationId ? { ...d, status: 'Completed' } : d));
      showToast('Donation marked Completed! Star Donor total & leaderboard updated.');
    }
  };

  const handleGoToBloodBank = () => {
    setHealthcareSubTab('bloodBank');
    setActiveTab('healthcare');
  };

  const handleSubmitComplaint = async (cmp: Partial<Complaint>) => {
    try {
      const res = await fetch('/api/complaints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cmp)
      });
      const data = await res.json();
      if (data.complaint) {
        setComplaints(prev => [data.complaint, ...prev]);
        showToast(`Grievance ticket #${data.complaint.ticketNumber} registered in municipal dispatch!`);
      }
    } catch {
      const localCmp: Complaint = {
        id: `cmp-${Date.now()}`,
        ticketNumber: `IDC-2026-${Math.floor(10000 + Math.random() * 90000)}`,
        citizenId: currentUser.id,
        citizenName: currentUser.name,
        citizenEmail: currentUser.email,
        title: cmp.title || 'Civic Issue',
        category: cmp.category || 'Sanitation & Roads',
        description: cmp.description || '',
        location: cmp.location || '',
        imageUrl: cmp.imageUrl,
        status: 'Submitted',
        priority: cmp.priority || 'Medium',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      setComplaints(prev => [localCmp, ...prev]);
      showToast(`Grievance ticket #${localCmp.ticketNumber} registered!`);
    }
  };

  const handleUpdateComplaintStatus = async (id: string, status: Complaint['status'], adminNotes: string) => {
    try {
      const res = await fetch(`/api/complaints/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, adminNotes })
      });
      const data = await res.json();
      if (data.complaint) {
        setComplaints(prev => prev.map(c => c.id === id ? data.complaint : c));
        showToast(`Ticket #${data.complaint.ticketNumber} status updated to ${status}!`);
      }
    } catch {
      setComplaints(prev => prev.map(c => c.id === id ? { ...c, status, adminNotes } : c));
      showToast(`Grievance status updated to ${status}!`);
    }
  };

  const handleVerifyRecord = async (entityType: string, entityId: string, newStatus: string, notes: string) => {
    try {
      const res = await fetch('/api/verification/verify-record', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ entityType, entityId, newStatus, notes })
      });
      const data = await res.json();
      if (data.success) {
        // update local state
        if (entityType === 'hospital') setHospitals(prev => prev.map(h => h.id === entityId ? data.record : h));
        if (entityType === 'doctorVisit') setDoctorVisits(prev => prev.map(v => v.id === entityId ? data.record : v));
        if (entityType === 'vacancy') setVacancies(prev => prev.map(v => v.id === entityId ? data.record : v));
        if (entityType === 'rule') setGovernmentRules(prev => prev.map(r => r.id === entityId ? data.record : r));
        if (entityType === 'route') setBusRoutes(prev => prev.map(r => r.id === entityId ? data.record : r));
        setAuditLogs(prev => [data.logEntry, ...prev]);
        showToast(`Record status updated to ${newStatus} and recorded in audit log.`);
      }
    } catch {
      showToast(`Record status updated to ${newStatus}.`);
    }
  };

  const handleToggleSave = async (itemId: string) => {
    let currentSaved = [...currentUser.savedItemIds];
    const idx = currentSaved.indexOf(itemId);
    if (idx > -1) {
      currentSaved.splice(idx, 1);
      showToast('Removed from saved items', 'info');
    } else {
      currentSaved.push(itemId);
      showToast('Saved to your citizen dashboard!');
    }
    setCurrentUser({ ...currentUser, savedItemIds: currentSaved });
    try {
      await fetch('/api/citizen/toggle-save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ itemId })
      });
    } catch {}
  };

  const handleUpdateSubscriptions = async (cats: string[]) => {
    setCurrentUser({ ...currentUser, subscribedCategories: cats });
    showToast('Notification categories updated!');
    try {
      await fetch('/api/citizen/update-subscriptions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ categories: cats })
      });
    } catch {}
  };

  const handleOpenAiAssistant = (initialQ: string = '') => {
    setAiInitialQuestion(initialQ);
    setAiModalOpen(true);
  };

  const handleToggleTheme = () => {
    setTheme(prev => {
      const next = prev === 'dark' ? 'light' : 'dark';
      showToast(next === 'dark' ? 'Switched to Dark Mode' : 'Switched to Light Mode', 'info');
      return next;
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-teal-500 selection:text-white transition-colors duration-200">
      
      {/* Toast Notification Popup */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-5 fade-in">
          <div className={`flex items-center gap-2.5 px-4 py-3 rounded-2xl shadow-xl text-xs sm:text-sm font-semibold border ${
            toast.type === 'success' ? 'bg-emerald-900 text-white border-emerald-700' :
            toast.type === 'error' ? 'bg-rose-900 text-white border-rose-700' :
            'bg-slate-900 text-white border-slate-700'
          }`}>
            {toast.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />}
            <span>{toast.message}</span>
            <button
              type="button"
              onClick={() => setToast(null)}
              className="text-slate-400 hover:text-white ml-2 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Google Maps Platform Quota Defense Banner */}
      {gmpQuotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm flex items-center justify-center gap-2">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
          <button 
            type="button" 
            onClick={() => setGmpQuotaExceeded(false)}
            className="text-amber-800 hover:text-amber-950 ml-2 cursor-pointer"
            aria-label="Dismiss banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onSwitchUserRole={handleSwitchUserRole}
        language={language}
        setLanguage={setLanguage}
        onOpenAiAssistant={handleOpenAiAssistant}
        notifications={notifications}
        theme={theme}
        onToggleTheme={handleToggleTheme}
      />

      {/* Page Content Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-16">
        
        {activeTab === 'home' && (
          <HomePage
            hospitals={hospitals}
            doctorVisits={doctorVisits}
            vacancies={vacancies}
            busRoutes={busRoutes}
            busSchedules={busSchedules}
            governmentRules={governmentRules}
            announcements={announcements}
            wellbeingMetrics={wellbeingMetrics}
            setActiveTab={setActiveTab}
            onOpenAiAssistant={handleOpenAiAssistant}
            onBookToken={handleBookToken}
            language={language}
          />
        )}

        {activeTab === 'healthcare' && (
          <HealthcareModule
            hospitals={hospitals}
            doctors={doctors}
            visits={doctorVisits}
            vacancies={vacancies}
            camps={healthCamps}
            bloodBanks={bloodBanks}
            bloodRequests={bloodRequests}
            bloodDonations={bloodDonations}
            donorLeaderboard={donorLeaderboard}
            currentUser={currentUser}
            onBookToken={handleBookToken}
            onToggleSave={handleToggleSave}
            onAddVisit={async (v) => {
              const res = await fetch('/api/doctor-visits', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(v)
              });
              const data = await res.json();
              if (data.visit) {
                setDoctorVisits(prev => [data.visit, ...prev]);
                showToast('Specialist doctor visit scheduled and published!');
              }
            }}
            onAddHospital={() => {}}
            onSubmitBloodRequest={handleSubmitBloodRequest}
            onSubmitBloodDonation={handleSubmitBloodDonation}
            onCompleteDonation={handleCompleteDonation}
            initialSubTab={healthcareSubTab}
            onClearInitialSubTab={() => setHealthcareSubTab(undefined)}
          />
        )}

        {activeTab === 'transport' && (
          <TransportModule
            routes={busRoutes}
            schedules={busSchedules}
            alerts={transportAlerts}
            hospitals={hospitals}
            currentUser={currentUser}
            onAddAlert={async (a) => {
              const res = await fetch('/api/transport/alerts', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(a)
              });
              const data = await res.json();
              if (data.alert) {
                setTransportAlerts(prev => [data.alert, ...prev]);
                showToast('Transit operational alert broadcasted to commuters!');
              }
            }}
          />
        )}

        {activeTab === 'government' && (
          <GovernmentModule
            rules={governmentRules}
            currentUser={currentUser}
            language={language}
            onAddRule={async (r) => {
              const res = await fetch('/api/government/rules', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(r)
              });
              const data = await res.json();
              if (data.rule) {
                setGovernmentRules(prev => [data.rule, ...prev]);
                showToast('Government regulation/scheme gazetted!');
              }
            }}
          />
        )}

        {activeTab === 'employment' && (
          <EmploymentModule
            jobs={jobs}
            currentUser={currentUser}
            onAddJob={() => {}}
          />
        )}

        {activeTab === 'education' && (
          <EducationModule services={education} />
        )}

        {activeTab === 'socialWelfare' && (
          <SocialWelfareModule
            services={socialWelfare}
            emergencyContacts={emergencyContacts}
          />
        )}

        {activeTab === 'wellbeing' && (
          <div className="space-y-6">
            <WellBeingChart metrics={wellbeingMetrics} />
          </div>
        )}

        {activeTab === 'citizenPortal' && (
          <CitizenPortal
            currentUser={currentUser}
            complaints={complaints}
            hospitals={hospitals}
            jobs={jobs}
            governmentRules={governmentRules}
            bloodDonations={bloodDonations}
            donorLeaderboard={donorLeaderboard}
            onSubmitComplaint={handleSubmitComplaint}
            onUpdateSubscriptions={handleUpdateSubscriptions}
            onToggleSave={handleToggleSave}
            onCompleteDonation={handleCompleteDonation}
            onGoToBloodBank={handleGoToBloodBank}
            setActiveTab={setActiveTab}
            theme={theme}
            onToggleTheme={handleToggleTheme}
          />
        )}

        {activeTab === 'adminPortal' && (
          <AdminPortal
            currentUser={currentUser}
            complaints={complaints}
            hospitals={hospitals}
            visits={doctorVisits}
            vacancies={vacancies}
            routes={busRoutes}
            rules={governmentRules}
            auditLogs={auditLogs}
            onUpdateComplaintStatus={handleUpdateComplaintStatus}
            onVerifyRecord={handleVerifyRecord}
          />
        )}

        {activeTab === 'accidentAlert' && (
          <AccidentEmergencyModule
            currentUser={currentUser}
            hospitals={hospitals}
            policeStations={policeStations}
            ambulanceUnits={ambulanceUnits}
            accidentReports={accidentReports}
            onSwitchUserRole={handleSwitchUserRole}
            onAccidentSubmitted={handleAccidentSubmitted}
            onRefreshAccidents={handleRefreshAccidents}
            onUpdateAccidentResponse={handleUpdateAccidentResponse}
          />
        )}

      </main>

      {/* Floating AI Citizen Assistant Trigger Button */}
      <button
        type="button"
        onClick={() => handleOpenAiAssistant()}
        className={`fixed z-40 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white shadow-xl flex items-center gap-2.5 transition-all hover:scale-105 cursor-pointer group border-2 border-white/20 ${
          activeTab === 'accidentAlert'
            ? 'bottom-4 right-4 rounded-full p-2.5'
            : 'bottom-4 left-4 sm:bottom-6 sm:left-6 rounded-2xl p-2.5 sm:p-3.5'
        }`}
        title="Open IDEAL AI Citizen Assistant"
        aria-label="Open IDEAL AI Citizen Assistant"
      >
        <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
          <Bot className="w-5 h-5 text-white animate-pulse" />
        </div>
        {activeTab !== 'accidentAlert' && (
          <div className="text-left hidden sm:block pr-1">
            <div className="text-xs font-black tracking-wide leading-tight">IDEAL AI</div>
            <div className="text-[10px] text-teal-100 font-medium">Verified Assistant</div>
          </div>
        )}
      </button>

      {/* AI Assistant Chat Modal */}
      <IdealAiChatModal
        isOpen={aiModalOpen}
        onClose={() => setAiModalOpen(false)}
        initialQuestion={aiInitialQuestion}
      />

      {/* Footer */}
      <Footer setActiveTab={setActiveTab} />

    </div>
  );
}
